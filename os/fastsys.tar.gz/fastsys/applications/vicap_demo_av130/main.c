#include "cmsis_os2.h"
#include <stdio.h>
#include <string.h>
#include "ak_param.h"
#include "ak_pinctrl.h"
#include "fastae_daemon.h"
#include "ak_saradc.h"

static T_FASTAE_HOOK s_hook[HOOK_MAX_NUM];

/* 与cloud平台 os/driver/include/isp_quick_ioctl.h 实现一致 */
typedef enum{
    NIGHT_MODE_IRFEED_LIGHT,
    NIGHT_MODE_WHITE_LIGHT,
    DAY_MODE_FORCE_NO_LIGHT,
    NIGHT_MODE_FORCE_IRFEED_LIGHT,
    DAY_MODE_IRFEED_LIGHT,
}T_NIGHT_MODE_LIGHT_SELECT;
/* 与cloud平台 os/driver/ak_quick_start/quick_start.h 实现一致 */
typedef enum {
    ISP_MODE_DAY_OUTDOOR,
    ISP_MODE_NIGHTTIME,
    ISP_MODE_USER1,
}ISP_DAT_NIGHT_MODE;

struct demo_context {
    int white_led_mode;
    int dayninght_mode[DSS_IRCUT_MAX_NUM];

    int ircut_a_curstate[DSS_IRCUT_MAX_NUM];
    int ircut_b_curstate[DSS_IRCUT_MAX_NUM];
    int whiteled_curstate[DSS_LED_MAX_NUM];
    int irled_curstate[DSS_LED_MAX_NUM];

    int ircut_day_night[DSS_IRCUT_MAX_NUM];
};

static void _set_irfeed(struct demo_context *ctx, int dev_id, int white_led_mode, int on_off)
{
    struct ak_qs_dss_info * dss = ak_get_dss_param();
    int led_group_id;
    struct dss_hw_led   *led;

    led_group_id = dss->qs_vi_info[dev_id].qs_vi_dev_info.led_group_id;
    led = led_group_id >= 0 ? &dss->led[led_group_id] : 0;

    if (!led)
        return;

    /* get led configuration */
    if (white_led_mode) {
        /* whiteled_gpio */
        if (on_off)
            ctx->whiteled_curstate[led_group_id] = led->whiteled_gpio.value;
        else
            ctx->whiteled_curstate[led_group_id] = !led->whiteled_gpio.value;
        gpio_set_pin_level(led->whiteled_gpio.nb, ctx->whiteled_curstate[led_group_id]);
    }
    else
    {
        /* irled_gpio */
        if (on_off)
            ctx->irled_curstate[led_group_id] = led->irled_gpio.value;
        else
            ctx->irled_curstate[led_group_id] = !led->irled_gpio.value;
        gpio_set_pin_level(led->irled_gpio.nb, ctx->irled_curstate[led_group_id]);
    }

    printf("dev[%d] led_id[%d] white[%d] gpio[%d] on_off(%d)\n", dev_id, led_group_id, white_led_mode, \
                white_led_mode ? led->whiteled_gpio.nb : led->irled_gpio.nb, on_off);
}

static void _set_ircut(struct demo_context *ctx, int dev_id, int day_night_mode)
{
    struct ak_qs_dss_info * dss = ak_get_dss_param();
    int ircut_group_id;
    struct dss_hw_ircut *ircut;

    ircut_group_id = dss->qs_vi_info[dev_id].qs_vi_dev_info.ircut_group_id;
    ircut = ircut_group_id >= 0 ? &dss->ircut[ircut_group_id] : 0;

    /* gpio invaild */
    if(!ircut || (ircut->ircut_a_gpio.nb < 0 && ircut->ircut_b_gpio.nb < 0))
        return;

    printf("dev[%d] ircut_id[%d] set_ircut mode(%d)\n", dev_id, ircut_group_id, day_night_mode);

    if (ctx->ircut_day_night[ircut_group_id] == day_night_mode)
        return;

    ctx->ircut_day_night[ircut_group_id] = day_night_mode;
    /* day */
    if(!day_night_mode){
        printf("set to day mode %ld %ld \n", ircut->ircut_a_gpio.nb, ircut->ircut_b_gpio.nb);
        if (ircut->ircut_a_gpio.nb >= 0){
            printf("ircut-a(%d) set %d \n", ircut->ircut_a_gpio.nb, !ircut->ircut_a_gpio.value);
            ctx->ircut_a_curstate[ircut_group_id] = !ircut->ircut_a_gpio.value;
            gpio_set_pin_level(ircut->ircut_a_gpio.nb, ctx->ircut_a_curstate[ircut_group_id]);
        }
        if(ircut->ircut_b_gpio.nb >= 0){
            printf("ircut-b(%d) set %d \n", ircut->ircut_b_gpio.nb, !ircut->ircut_b_gpio.value);
            ctx->ircut_b_curstate[ircut_group_id] = !ircut->ircut_b_gpio.value;
            gpio_set_pin_level(ircut->ircut_b_gpio.nb, ctx->ircut_b_curstate[ircut_group_id]);
        }
    }
    /* night */
    else{
        printf("set to night mode %ld %ld \n", ircut->ircut_a_gpio.nb, ircut->ircut_b_gpio.nb);
        if(ircut->ircut_a_gpio.nb >= 0){
            printf("ircut-a(%d) set %d \n", ircut->ircut_a_gpio.nb, ircut->ircut_a_gpio.value);
            ctx->ircut_a_curstate[ircut_group_id] = ircut->ircut_a_gpio.value;
            gpio_set_pin_level(ircut->ircut_a_gpio.nb, ctx->ircut_a_curstate[ircut_group_id]);
        }
        if(ircut->ircut_b_gpio.nb >= 0){
            printf("ircut-b(%d) set %d \n", ircut->ircut_b_gpio.nb, ircut->ircut_b_gpio.value);
            ctx->ircut_b_curstate[ircut_group_id] = ircut->ircut_b_gpio.value;
            gpio_set_pin_level(ircut->ircut_b_gpio.nb, ctx->ircut_b_curstate[ircut_group_id]);
        }
    }
}


static int demo_prev_init(void *user_data, void *param)
{
    struct demo_context *ctx = (struct demo_context *)user_data;
    struct ak_qs_dss_info * dss = ak_get_dss_param();
    int dev_id;
    int ircut_group_id;
    int led_group_id;
    struct dss_hw_ircut *ircut;
    struct dss_hw_led   *led;
    int i;


    //客户根据实际需要配置
    ctx->white_led_mode = 0;

    //初始化状态变量
    for (i = 0; i < DSS_LED_MAX_NUM; ++i) {
        ctx->whiteled_curstate[i] = -1;
        ctx->irled_curstate[i] = -1;
    }

    //初始化状态变量
    for (i = 0; i < DSS_IRCUT_MAX_NUM; ++i) {
        ctx->ircut_a_curstate[i] = -1;
        ctx->ircut_b_curstate[i] = -1;
        ctx->ircut_day_night[i] = -1;
    }

    for (dev_id = 0; dev_id < DSS_VIDEO_MAX_NUM; ++dev_id) {
        if (!dss->qs_vi_info[dev_id].qs_vi_dev_info.enable)
            continue;

        ircut_group_id = dss->qs_vi_info[dev_id].qs_vi_dev_info.ircut_group_id;
        led_group_id = dss->qs_vi_info[dev_id].qs_vi_dev_info.led_group_id;
        ircut = ircut_group_id >= 0 ? &dss->ircut[ircut_group_id] : 0;
        led = led_group_id >= 0 ? &dss->led[led_group_id] : 0;

        //设置 ircut led gpio 默认输出
        if (led && (led->irled_gpio.nb >= 0)) {
            gpio_set_pin_as_gpio(led->irled_gpio.nb);
            gpio_set_pin_dir(led->irled_gpio.nb, 1);
        }

        if (led && (led->whiteled_gpio.nb >= 0)) {
            gpio_set_pin_as_gpio(led->whiteled_gpio.nb);
            gpio_set_pin_dir(led->whiteled_gpio.nb, 1);
        }

        if (ircut && (ircut->ircut_a_gpio.nb >= 0)) {
            gpio_set_pin_as_gpio(ircut->ircut_a_gpio.nb);
            gpio_set_pin_dir(ircut->ircut_a_gpio.nb, 1);
        }
        if (ircut && (ircut->ircut_b_gpio.nb >= 0)) {
            gpio_set_pin_as_gpio(ircut->ircut_b_gpio.nb);
            gpio_set_pin_dir(ircut->ircut_b_gpio.nb, 1);
        }

        _set_irfeed(ctx, dev_id, !ctx->white_led_mode, 0);
        _set_irfeed(ctx, dev_id, ctx->white_led_mode, 0);
        _set_ircut(ctx, dev_id, 0);
    }

    return 0;
}

static int demo_vi_init(void *user_data, void *param)
{
    struct demo_context *ctx = (struct demo_context *)user_data;
    struct fastaed_default_param fastaed_default_param;
    int dev_id = *(int *)param;

    //设置默认参数
    fastaed_default_param.init_ae = 0;
    fastaed_default_param.init_awb = 0;

    if (is_hw_photosensitivity_enable(dev_id)) {
        fastaed_default_param.isp_default_mode = ctx->dayninght_mode[dev_id];
    } else {
        fastaed_default_param.isp_default_mode = 0;
    }
    fastaed_set_default_param(dev_id, &fastaed_default_param);
}

static int get_light_sensor_value(void *user_data, void *param)
{
    struct demo_context *ctx = (struct demo_context *)user_data;
    struct ak_qs_dss_info * dss = ak_get_dss_param();
    int curing_day_night_mode;
    int lumen_group_id;
    int irfeed_on;
    int night_threshold;
    int ain_value[DSS_MAX_AIN_NUM]= {-1,-1} ;
    int ret;
    int i,dev_id;
    int cis_enable_bit;
    int fastae_mode;
    int ain_value_bit; //saradc bit数,暂时可以忽略


    //获取当前应用跑几路
    for (i = 0; i < DSS_VIDEO_MAX_NUM; ++i) {
        dev_id = i;
        fastae_mode = dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.fastae_mode;
        if (fastae_mode != 4) {
            cis_enable_bit |= 0x01UL << i;
        }
    }


    for (i = 0; i < DSS_VIDEO_MAX_NUM; ++i) {
        if (cis_enable_bit & (0x01UL << i)) {
            dev_id = i;

            //判断是否为非硬光敏
            if (!is_hw_photosensitivity_enable(dev_id)) {
                continue;
            }

            lumen_group_id = dss->qs_vi_info[dev_id].qs_vi_dev_info.lumen_group_id;

            //判断硬光敏group_id 是否为正确
            if(lumen_group_id < 0) {
                printf("lumen_group_id is invalid %d\n",lumen_group_id);
                continue;
            }

            //防止多次读同一个AIN的值
            if (ain_value[lumen_group_id] < 0) {
                //回读光敏电阻的值
                ret = ak_saradc_read_channel_raw(dss->hw_lumi_sensor[lumen_group_id].ain_index,&ain_value[lumen_group_id],&ain_value_bit);
                if(ret == -1) {
                    ret = ak_saradc_read_channel_raw(dss->hw_lumi_sensor[lumen_group_id].ain_index,&ain_value[lumen_group_id],&ain_value_bit);
                    if (ret == -1) {
                        printf("%s,%d read ain_value fail\n",__func__,__LINE__);
                        continue;
                    }
                }
            }
            printf("ain_val[%d]=%d mv\n",lumen_group_id,ain_value[lumen_group_id]);
            //设置当前白天或者夜间模式
            night_threshold = dss->hw_lumi_sensor[dev_id].daynight_threshold;
            /*光敏电阻在上
             *      VCC (3.3V)
             *          │
             *          ├── 光敏电阻 (LDR)
             *          │
             *          ├──────────────► ADC 采样点
             *          │
             *          ├── 固定电阻 (R，通常 10K)
             *          │
             *          GND
             *
             *  V_out = VCC × (R_fixed / (R_ldr + R_fixed))               │
             *                                                             │
             *  （LDR 在上）：                                        │
             *  ├── 白天：R_ldr 小 → V_out 高                              │
             *  └── 黑夜：R_ldr 大 → V_out 低
             */
            curing_day_night_mode = ain_value[lumen_group_id] < night_threshold ?
                                         ISP_MODE_NIGHTTIME:ISP_MODE_DAY_OUTDOOR;
            irfeed_on = curing_day_night_mode;


            /* 判断灯光模式 */
            if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
                == NIGHT_MODE_IRFEED_LIGHT){//ISP_MODE_DAY_OUTDOOR
                ctx->white_led_mode = 0;
            }
            else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
                == NIGHT_MODE_WHITE_LIGHT){//ISP_MODE_DAY_OUTDOOR
                ctx->white_led_mode = 1;
            }
            else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
                == DAY_MODE_FORCE_NO_LIGHT){//ISP_MODE_DAY_OUTDOOR
                curing_day_night_mode = ISP_MODE_DAY_OUTDOOR;
            }
            else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
                == NIGHT_MODE_FORCE_IRFEED_LIGHT){//ISP_MODE_NIGHTTIME
                curing_day_night_mode = ISP_MODE_NIGHTTIME;
                ctx->white_led_mode = 0;
                irfeed_on = 1;
            }else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
                == DAY_MODE_IRFEED_LIGHT){//ISP_MODE_DAY_OUTDOOR
                curing_day_night_mode = ISP_MODE_DAY_OUTDOOR;
                ctx->white_led_mode = 0;
                irfeed_on = 1;
            }

            /* 先开补光灯，便于ae快速收敛 */
            _set_irfeed(ctx,dev_id, ctx->white_led_mode, irfeed_on);

            /* set ircut */
            _set_ircut(ctx, dev_id, curing_day_night_mode);

            //recode day night mode
            ctx->dayninght_mode[dev_id] = curing_day_night_mode;
        }
    }

    return 0;
}

static int demo_check_day_night(void *user_data, void *param)
{
    struct demo_context *ctx = (struct demo_context *)user_data;
    struct fastaed_lumi_measured *_measured = (struct fastaed_lumi_measured *)param;
    int pre_mode = fastaed_get_current_isp_mode(_measured->dev_id);
    int night = 0, night_threshold = 0, irfeed_on = 0;
    struct ak_qs_dss_info * dss = ak_get_dss_param();
    int dev_id = _measured->dev_id;
    struct fastae_info *fastae_info = &(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info);
    int ret;
    static int _dayninght_mode[4] = {0,0,0,0};

    printf("%s %d, dev-%d exp_div_lumi %d cur_isp_mode %d\n",
        __func__, __LINE__, _measured->dev_id, _measured->exp_div_lumi, _measured->cur_isp_mode);

    /* check current mode and get night threshold */
    night_threshold = dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.daynight_threshold[pre_mode];

    night = _measured->exp_div_lumi < night_threshold ? 0 : 1;

    if ((fastae_info->daynight_master_id != -1) &&
        (fastae_info->daynight_master_id != _measured->dev_id)) {
        night = _dayninght_mode[fastae_info->daynight_master_id];
        printf("dev-%d daynight_master_id %d\n", _measured->dev_id, fastae_info->daynight_master_id,
                                            _dayninght_mode[fastae_info->daynight_master_id]);
    }
    _dayninght_mode[dev_id] = night;

    irfeed_on = night;

    /* 判断灯光模式 */
    if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
        == NIGHT_MODE_IRFEED_LIGHT){//ISP_MODE_DAY_OUTDOOR
        ctx->white_led_mode = 0;
    }
    else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
        == NIGHT_MODE_WHITE_LIGHT){//ISP_MODE_DAY_OUTDOOR
        ctx->white_led_mode = 1;
    }
    else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
        == DAY_MODE_FORCE_NO_LIGHT){//ISP_MODE_DAY_OUTDOOR
        night = ISP_MODE_DAY_OUTDOOR;
    }
    else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
        == NIGHT_MODE_FORCE_IRFEED_LIGHT){//ISP_MODE_NIGHTTIME
        night = ISP_MODE_NIGHTTIME;
        ctx->white_led_mode = 0;
        irfeed_on = 1;
    }else if(dss->qs_vi_info[dev_id].qs_vi_dev_info.fastae_info.night_mode_light_select
        == DAY_MODE_IRFEED_LIGHT){//ISP_MODE_DAY_OUTDOOR
        night = ISP_MODE_DAY_OUTDOOR;
        ctx->white_led_mode = 0;
        irfeed_on = 1;
    }

    ctx->dayninght_mode[_measured->dev_id] = night;

    printf("curing_day_night_mode:%d, env:%d, threshold:%d, pre_mode:%d\r\n",
        night, _measured->exp_div_lumi, night_threshold, pre_mode);


    //设置isp subfile index
    fastaed_set_isp_mode(_measured->dev_id, night);


    //if (!faseae->light_sensor_enable) { //软光敏才切换，硬光敏提前设置补光灯和ircut。YJH
        /* 先开补光灯，便于ae快速收敛 */
        _set_irfeed(ctx, _measured->dev_id, ctx->white_led_mode, irfeed_on);

        /* set ircut */
        _set_ircut(ctx, _measured->dev_id, night);
    //}

    printf("%s pre_mode:%d, curing_day_night_mode:%d\r\n",
        __func__, pre_mode, night);
    /* switch ispconfig */
    if(pre_mode != night){
        ret = fastaed_update_ispconfig(_measured->dev_id);
        if(ret){
            printf("%s %d, update ispconfig failed\n", __func__, __LINE__);
            return -1;
        }
    }

    return fastaed_get_current_isp_mode(_measured->dev_id);
}

static int _get_ircut_led_status(void *user_data, void *param)
{
    struct demo_context *ctx = (struct demo_context *)user_data;
    struct fastaed_ircut_led_status *ircut_led_status = (struct fastaed_ircut_led_status *)param;
    struct ak_qs_dss_info * dss = ak_get_dss_param();
    int i;

    for (i = 0; i < DSS_IRCUT_MAX_NUM; ++i) {
        ircut_led_status->ircut[i].ircut_a_gpio.nb = dss->ircut[i].ircut_a_gpio.nb;
        ircut_led_status->ircut[i].ircut_a_gpio.value = dss->ircut[i].ircut_a_gpio.value;
        ircut_led_status->ircut[i].ircut_b_gpio.nb = dss->ircut[i].ircut_b_gpio.nb;
        ircut_led_status->ircut[i].ircut_b_gpio.value = dss->ircut[i].ircut_b_gpio.value;

        ircut_led_status->ircut_a_curstate[i] = ctx->ircut_a_curstate[i];
        ircut_led_status->ircut_b_curstate[i] = ctx->ircut_b_curstate[i];
    }

    for (i = 0; i < DSS_LED_MAX_NUM; ++i) {
        ircut_led_status->led[i].ircut_led_type = dss->led[i].ircut_led_type;
        ircut_led_status->led[i].whiteled_type = dss->led[i].whiteled_type;
        ircut_led_status->led[i].irled_gpio.nb = dss->led[i].irled_gpio.nb;
        ircut_led_status->led[i].irled_gpio.value = dss->led[i].irled_gpio.value;
        ircut_led_status->led[i].whiteled_gpio.nb = dss->led[i].whiteled_gpio.nb;
        ircut_led_status->led[i].whiteled_gpio.value = dss->led[i].whiteled_gpio.value;

        ircut_led_status->whiteled_curstate[i] = ctx->whiteled_curstate[i];
        ircut_led_status->irled_curstate[i] = ctx->irled_curstate[i];
    }

}

/**
 * main
 */
int main(void)
{
    printf("Build by %s\n", __USER__);
    printf("On %s %s\n", __DATE__, __TIME__);
    printf("Anyka rtthread vicap-main startup!!!\n");

    struct demo_context *_ctx = osMemoryAlloc(sizeof(struct demo_context));
    memset(_ctx, 0, sizeof(struct demo_context));

    s_hook[HOOK_PREV_INIT_F] = demo_prev_init;
    s_hook[HOOK_BEFORE_VI_INIT] = demo_vi_init;
    s_hook[HOOK_FASTAE_LUMI_MEASURED] = demo_check_day_night;
    s_hook[HOOK_GET_IRCUT_LED_STATUS] = _get_ircut_led_status;
    s_hook[HOOK_AFTER_ADC_PROBE] = get_light_sensor_value;//硬光敏,读saradc值

    fastae_daemon_init(s_hook, _ctx, 0);


    fastae_daemon();
    /* loop */
    while(1) {
        osDelay(1000);
//        printf("hello world\n");
    }

    return 0;
}
