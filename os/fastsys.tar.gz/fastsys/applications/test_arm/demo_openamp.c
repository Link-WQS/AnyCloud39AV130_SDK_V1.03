#include <string.h>
#include "stdio.h"
#include "core_driver.h"
#include "cmsis_os2.h"
#include "openamp.h"
#include "ak_ahbhant.h"

struct rpmsg_demo_private {
	int rpmsg_id;
	struct rpmsg_endpoint *ept;
	int is_unbound;
	int is_ready;
};

static struct rpmsg_demo_private demo = {
	.rpmsg_id = 0,
	.ept = NULL,
	.is_unbound = 0,
};

static osThreadId_t s_thread_openamp_tid = NULL;
static char data_send[256]={0};
static uint32_t cnt;

static int rpmsg_ept_callback(struct rpmsg_endpoint *ept, void *data,
		size_t len, uint32_t src, void *priv)
{
    char *p = data;

    p[len] = '\0';
	printf("resc %d data:%s\n",len,p);
	return 0;
}

static void rpmsg_unbind_callback(struct rpmsg_endpoint *ept)
{
    struct rpmsg_demo_private *demo_priv = ept->priv;
	printf("Remote endpoint is destroyed\n");
	demo_priv->is_unbound = 1;
}

static void thread_openamp_demo(void *argument)
{
    struct remoteproc *rproc;
    int ret = 0;
    uint32_t send_len;

    rproc = openamp_init();
    if (rproc == NULL) {
		printf("Failed to init openamp framework\r\n");
	}

    ak_ahbhant_register_intr(vring_ipi_recv_call_back,rproc);

    demo.ept = openamp_ept_open("anyka,ak3918av130-arm9l", 0, RPMSG_ADDR_ANY, RPMSG_ADDR_ANY,
					&demo, rpmsg_ept_callback, rpmsg_unbind_callback);
	if (demo.ept == NULL) {
		printf("Failed to Create Endpoint\r\n");
	}

    printf("Success to Create Endpoint\r\n");
    os_msleep(500);
    
    while(!demo.is_unbound){
        send_len = sprintf(data_send, "remote send cnt:%d\r\n", cnt++);
        ret = openamp_rpmsg_send(demo.ept, (void *)data_send, send_len);
        if(ret < 0) {
            printf("Failed to send %d data:%d\r\n",send_len,ret);
        }
        os_msleep(500);
        
    }
}

void run_openamp_demo(void)
{
     /*create thread for openamp */
    s_thread_openamp_tid = osThreadNew(thread_openamp_demo, NULL, NULL);

    return ;
}
