#include <string.h>
#include "stdio.h"
#include "core_driver.h"
#include "cmsis_os2.h"
#include "openamp.h"
#include "ak_ahbhant.h"
#include "demo_rpmsg_internal.h"
#include "demo_rpmsg_ctrl.h"
#include "demo_rpmsg_client.h"
#include "sdfilter.h"

#define RPMSG_SERVICE_NAME "anyka,rpmsg_ctrl"

#define SYNC_COMPEN_STATUS   (170) //samples to compensate for far leading near

static const char *ept_name = RPMSG_SERVICE_NAME;
static uint32_t src_addr = RPMSG_ADDR_ANY;
static uint32_t dst_addr = RPMSG_ADDR_ANY;


struct rpmsg_ept_ctrldev {
	struct rpmsg_endpoint *ept;
	int is_init;
	osThreadId_t rpmsg_ctrl_daemon;
    osMessageQueueId_t rxq;
    int is_unbound;
};

static struct rpmsg_ept_ctrldev ctrldev;

static osThreadId_t rpmsg_data_daemon;// 数据处理的线程
static osThreadId_t rpmsg_ahhbant_print_daemon;

static void rpmsg_ctrldev_notify(struct rpmsg_ept_ctrldev *ctrl, int id, uint32_t notify)
{
	struct rpmsg_ctrl_msg_ack ack;

	ack.id = id;
	ack.ack = notify;
	rpmsg_send(ctrl->ept, &ack, sizeof(ack));

	printf("send 0x%lx to rpmsg%d\r\n", notify, id);
}


static int rpmsg_ept_callback(struct rpmsg_endpoint *ept, void *data,
		size_t len, uint32_t src, void *priv)
{
    struct rpmsg_ept_ctrldev *ctrl = (struct rpmsg_ept_ctrldev *)ept->priv;
    printf("ctrl: Rx %d Bytes\n", len);
 
    osMessageQueuePut(ctrl->rxq,data,0,0);
    
	return 0;
}

static void rpmsg_unbind_callback(struct rpmsg_endpoint *ept)
{
    struct rpmsg_ept_ctrldev *ctrldev = ept->priv;
	printf("Remote endpoint is destroyed\n");
	ctrldev->is_unbound = 1;
}


static struct rpmsg_endpoint *rpmsg_ctrl_create_client(struct rpmsg_ept_ctrldev *ctrl,
				struct rpmsg_ctrl_msg *msg, const char *client_name)
{
    struct rpmsg_endpoint *ept = rpmsg_eptdev_create_client(client_name, msg);// "anyka,rpmsg_client0"
    if (!ept) {
        rpmsg_ctrldev_notify(ctrl, msg->id, RPMSG_ACK_NOMEM);
        return NULL;
    }

    /* notify remote create success */
    rpmsg_ctrldev_notify(ctrl, msg->id, RPMSG_ACK_OK);
    return ept;
}

static int SetCallBackFuns(void)
{
    static char u8FlagCbInit = 0;
    int s32Ret = 0;
    T_SDLIB_PLATFORM_DEPENDENT_LIST *sd_cb;

    if( 0 == u8FlagCbInit ) {
        sd_cb = _SD_GetPlatformDependentList();
        if(sd_cb) {
            //ak_print_notice_ex(MODULE_ID_VQE, "Notice: sd_cb->printf = 0x%x\n", sd_cb->printf);

            sd_cb->Malloc   = (MEDIALIB_CALLBACK_FUN_MALLOC)    osMemoryAlloc;
            sd_cb->Free     = (MEDIALIB_CALLBACK_FUN_FREE)      osMemoryFree;
            sd_cb->printf   = (MEDIALIB_CALLBACK_FUN_PRINTF)    printf;

            sd_cb->mutexCreate  = (SDLIB_CALLBACK_FUN_MUTEX_CREATE)     osMutexNew;
            sd_cb->mutexDelete  = (SDLIB_CALLBACK_FUN_MUTEX_DELETE)     osMutexDelete;
            sd_cb->mutexGet     = (SDLIB_CALLBACK_FUN_MUTEX_GET)        osMutexAcquire;
            sd_cb->mutexRelease = (SDLIB_CALLBACK_FUN_MUTEX_RELEASE)    osMutexRelease;

            u8FlagCbInit = 1;
            s32Ret = 0;
        } else {// NULL == sd_cb
            printf("ERROR: sd_cb is null\n");
            s32Ret = -1;
        }
    } else { // u8FlagCbInit != 0
        printf("Info: sd_cb already init\n");
    }

    return s32Ret;
}

// 运行此demo
static void thread_rpmsg_ctrl_daemon(void *argument)
{
    struct remoteproc *rproc;
    int ret = 0;
    uint32_t send_len;
    struct rpmsg_ctrl_msg msg;
    struct rpmsg_endpoint *ept = NULL;

    // 创建消息队列
    ctrldev.rxq = osMessageQueueNew(8, sizeof(struct rpmsg_ctrl_msg), NULL);
    if (ctrldev.rxq == NULL) {
        printf("create message queue failed\r\n");
    }

    // 初始化 openamp
    rproc = openamp_init();
    if (rproc == NULL) {
		printf("Failed to init openamp framework\r\n");
	}

    ak_ahbhant_register_intr(vring_ipi_recv_call_back,rproc);

    ctrldev.ept = openamp_ept_open(ept_name, 0, src_addr, dst_addr,
					&ctrldev, rpmsg_ept_callback, rpmsg_unbind_callback);
	if (ctrldev.ept == NULL) {
		printf("Failed to Create Endpoint\r\n");
	}
    ctrldev.is_init = 1;

    printf("Success to Create Endpoint %s\r\n",ept_name);
    os_msleep(500);

    while (0 == osMessageQueueGet(ctrldev.rxq, &msg, 0, (uint32_t)(-1))) {
        if (msg.cmd == RPMSG_CREATE_CLIENT) {
            printf("###RPMSG_CREATE_CLIENT id=%d, %s\n", msg.id, msg.name);
            if (strcmp(msg.name, "anyka,rpmsg_client0") == 0) {
                ept = rpmsg_ctrl_create_client(&ctrldev, &msg, "anyka,rpmsg_client0");
            } else {
                ept = rpmsg_ctrl_create_client(&ctrldev, &msg, "anyka,rpmsg_client1");
            }
        }
        else if (msg.cmd == RPMSG_CLOSE_CLIENT) {
            printf("@@@ RPMSG_CLOSE_CLIENT id=%d, %s\n", msg.id, msg.name);
            if (strcmp(msg.name, "anyka,rpmsg_client0") == 0) {
                rpmsg_eptdev_release_client(ept, "anyka,rpmsg_client0");
            } else {
                rpmsg_eptdev_release_client(ept, "anyka,rpmsg_client1");
            }
            rpmsg_ctrldev_notify(&ctrldev, msg.id, RPMSG_ACK_OK);
            //ept = NULL;
        } else if (msg.cmd == RPMSG_RELEASE) {
            printf("cmd RPMSG_RELEASE  error\r\n");
        } else {
            printf("cmd unknow: %d\r\n", msg.cmd);
        }

    }
}

void run_rpmsg_ctrl_daemon(void)
{
     /*create thread for openamp */
    ctrldev.rpmsg_ctrl_daemon = osThreadNew(thread_rpmsg_ctrl_daemon, NULL, NULL);
    return ;
}
#if 0
static void vPrintAhhbantCountTask(void *argument)
{
    while (1) {
        printf("AHBHANT IRQ Count: %d\n", ak_get_irq_count());
        os_msleep(1000);  // 每秒打印一次
    }
}

void run_rpmsg_ahhbant_print_daemon(void)
{
     /*create thread for openamp */
    rpmsg_ahhbant_print_daemon = osThreadNew(vPrintAhhbantCountTask, NULL, NULL);

    return ;
}
#endif
