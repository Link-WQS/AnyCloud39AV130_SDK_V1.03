#ifdef RT_USING_NEWLIB
#include <reent.h>

// 使用弱符号声明
__attribute__((weak)) struct _reent *__getreent(void) {
    return _GLOBAL_REENT;  // 您的自定义实现
}
#endif
