#ifndef _AK_VQE_AMP_H_
#define _AK_VQE_AMP_H_

#define AK_FALSE			0
#define AK_TRUE          	1
#define AK_SUCCESS			0
#define AK_FAILED          	(-1)

enum audio_func_status
{
    AUDIO_FUNC_DISABLE = 0x00,
    AUDIO_FUNC_ENABLE,
};

typedef struct akION_DATA_S
{
    unsigned long fill_paddr;
    unsigned long result_paddr;
    unsigned int u32DataLen;
    unsigned long long data_ts;
} ION_DATA_S;

int vqe_amp_set_callBack_funs(void);

void vqe_amp_login(void);

int vqe_amp_open(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_close(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_near_jitter_buf(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_aslc(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_aslc(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_nr(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_agc(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_nr(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_agc(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_aec(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_aec(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_hs(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_hs(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_eq(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_set_eq(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_fill_adc(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_fill_loopback(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_get_version(struct rpmsg_endpoint *ept, unsigned char *data, int size);

int vqe_amp_flush(struct rpmsg_endpoint *ept, unsigned char *data, int size);

#endif