#ifndef __DEMO_RPMSG_CLIENT_H__
#define __DEMO_RPMSG_CLIENT_H__
#include "demo_rpmsg_internal.h"

struct rpmsg_client_msg {
    struct rpmsg_endpoint *ept;
    uint8_t *data;      // ָ�����ݵ�ָ��
    size_t len;         // ���ݳ���
    int status;         // ��ѡ��״̬��
};

//struct rpmsg_endpoint *rpmsg_eptdev_create_client(struct rpmsg_ctrl_msg *msg);
struct rpmsg_endpoint *rpmsg_eptdev_create_client(const char *ept_name_ex, struct rpmsg_ctrl_msg *msg);
struct rpmsg_endpoint *rpmsg_eptdev_create_client1(const char *ept_name_ex, struct rpmsg_ctrl_msg *msg);
void rpmsg_eptdev_release_client(struct rpmsg_endpoint *ept, const char *ept_name_ex);
#endif/*__DEMO_RPMSG_CLIENT_H__*/