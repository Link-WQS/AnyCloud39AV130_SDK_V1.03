#ifndef __DUMP_FILE_H__
#define __DUMP_FILE_H__
#include "ak_amp_cmd_list.h"

#define AUDIO_ITEM_PCM      0x01000000  // pcm's meta is of type (T_ECHO_PCM_META*)

/**
 * DumpFileDataToRb: Dump file callback function
 * @item_id[IN]: Dump item id
 * @size[IN]: write size
 * @data[IN]: write data
 * @meta[IN]: reserve param
 * @cb_param[IN]: Dump item id
 * return: 0 success, other failed
 * notes: Dump file data to ring buffer
 */
void DumpFileDataToRb(T_ECHO_DUMP_ITEM_ID item_id, T_S32 size, T_pCVOID data, T_pCVOID meta, T_HANDLE cb_dump_param, T_U8 pathId);

/**
 * DumpFileUpdateInfo - Update dump configuration based on provided attributes
 * @param[in] dump_attr: pointer to AUDIO_AMP_DUMP_ATTR structure containing dump configuration
 * return: No return value (void)
 * notes: 
 *     - Updates the global dump enable list (s32DumpEnableList) and ring buffer ION list (u8DumpRbIon)
 *     - Iterates through DUMP_LIST_NUM items and copies enable status and ION buffer ID from dump_attr
 *     - Used to dynamically configure which dump items are enabled and their associated ION buffers
 *     - This function is typically called when dump settings are changed or initialized
 */
void DumpFileUpdateInfo(AUDIO_AMP_DUMP_ATTR *dump_attr);

#endif/*__DUMP_FILE_H__*/