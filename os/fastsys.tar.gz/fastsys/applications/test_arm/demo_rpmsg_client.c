#include <string.h>
#include "stdio.h"
#include "core_driver.h"
#include "cmsis_os2.h"
#include "openamp.h"
#include "demo_rpmsg_client.h"
#include "demo_rpmsg_internal.h"
#include "ak_amp_cmd_list.h"
#include "ak_vqe_amp.h"

#define RPMSG_SERVICE_NAME "anyka,rpmsg_client0"
#define MSG_LEN 512

#define AK_FALSE			0
#define AK_TRUE          	1
#define AK_SUCCESS			0
#define AK_FAILED          	(-1)

static const char *ept_name = RPMSG_SERVICE_NAME;
static uint32_t src_addr = RPMSG_ADDR_ANY;
static uint32_t dst_addr = RPMSG_ADDR_ANY;
static osMessageQueueId_t client_rxq;// 全局变量：消息队列
static osThreadId_t thread_id = NULL;
static struct rpmsg_client_status s_sta;

static osMessageQueueId_t client_rxq1;// 全局变量：消息队列
static osThreadId_t thread_id1 = NULL;
static struct rpmsg_client_status s_sta1;

struct rpmsg_client_status {
	osSemaphoreId_t sem;
	uint32_t status;
};

struct rpmsg_demo_private {
	int rpmsg_id;
	struct rpmsg_endpoint *ept;
	int is_unbound;
	int is_ready;
};

static struct rpmsg_demo_private demo = {
	.rpmsg_id = 0,
	.ept = NULL,
	.is_unbound = 0,
};


// adc 客户端的回调函数
static int rpmsg_ept_callback(struct rpmsg_endpoint *ept, void *data,
		size_t len, uint32_t src, void *priv)
{
	struct rpmsg_ctrl_msg_ack *ack = data;
	struct rpmsg_client_status *sta = priv;// 信号量
	if (!priv) {
		printf("%s, Invalid Data.\r\n", __func__);
		return AK_FAILED;
	}

    struct rpmsg_client_msg _msg;
    struct rpmsg_client_msg *msg = &_msg;

    static char msg_buf[MSG_LEN];

    // 复制数据
    if (MSG_LEN < len || 0 >=len) {
        printf("ERROR: %s, len = %d\r\n",  __func__, len);
        // 即使数据长度超过限制，也要释放信号量
        osSemaphoreRelease(sta->sem);
        return AK_FAILED;
    }

    msg->data = msg_buf;

    extern void metal_machine_cache_invalidate(void *addr, unsigned int len);

    metal_machine_cache_invalidate(data, len);

    memcpy(msg->data, data, len);
    msg->len = len;
    msg->status = RPMSG_ACK_OK;  // 可选：设置状态
    msg->ept = ept;

	// 检查是否是 ACK 消息 (长度为 8 或 12 字节，且 ack 字段是已知的 ACK 值)
	if (len == 8 || len == 12) {
		// 检查 ack 字段是否是已知的 ACK 值
		if (ack->ack == RPMSG_ACK_OK || ack->ack == RPMSG_ACK_FAILED ||
		    ack->ack == RPMSG_ACK_NOLISTEN || ack->ack == RPMSG_ACK_BUSY ||
		    ack->ack == RPMSG_ACK_NOMEM || ack->ack == RPMSG_ACK_NOENT) {
			printf("%s, id:0x%x,ack:0x%x\r\n", __func__, ack->id, ack->ack);
			sta->status = ack->ack;
			osSemaphoreRelease(sta->sem);
			return 0;
		}
	}

	// 非 ACK 消息，放入数据消息队列
	if (len >= 4) {
		// 放入消息队列（非阻塞）
		if (osMessageQueuePut(client_rxq, msg, 0, 0) != osOK) {
			printf("WARNING: %s, Message queue full, dropping message!\n", __func__);
			osSemaphoreRelease(sta->sem);
			return AK_FAILED;
		}
		return 0;
	}

	printf("%s, unknown message, len=%d\r\n", __func__, len);
	osSemaphoreRelease(sta->sem);
	return 0;
}

// dac客户端的回调函数
static int rpmsg_ept_callback1(struct rpmsg_endpoint *ept, void *data,
                                      size_t len, uint32_t src, void *priv)
{
	struct rpmsg_ctrl_msg_ack *ack = data;
	struct rpmsg_client_status *sta = priv;
	if (!priv) {
		printf("%s, Invalid Data.\r\n",  __func__);
		return 0;
	}
	struct rpmsg_client_msg msg;

	static char msg_buf1[MSG_LEN];

    // 复制数据
    if (MSG_LEN < len || 0 >=len) {
        printf("ERROR: %s, len = %d\r\n",  __func__, len);
        // 即使数据长度超过限制，也要释放信号量
        osSemaphoreRelease(sta->sem);
        return AK_FAILED;
    }

    msg.data = msg_buf1;

    extern void metal_machine_cache_invalidate(void *addr, unsigned int len);

    metal_machine_cache_invalidate(data, len);

    memcpy(msg.data, data, len);
    msg.len = len;
    msg.status = RPMSG_ACK_OK;  // 可选：设置状态
    msg.ept = ept;

	// 检查是否是 ACK 消息 (长度为 8 或 12 字节，且 ack 字段是已知的 ACK 值)
	if (len == 8 || len == 12) {
		// 检查 ack 字段是否是已知的 ACK 值
		if (ack->ack == RPMSG_ACK_OK || ack->ack == RPMSG_ACK_FAILED ||
		    ack->ack == RPMSG_ACK_NOLISTEN || ack->ack == RPMSG_ACK_BUSY ||
		    ack->ack == RPMSG_ACK_NOMEM || ack->ack == RPMSG_ACK_NOENT) {
			printf("%s, id:0x%x,ack:0x%x\r\n", __func__, ack->id, ack->ack);
			sta->status = ack->ack;
			osSemaphoreRelease(sta->sem);
			return 0;
		}
	}

	// 非 ACK 消息，放入数据消息队列
	if (len >= 4) {
        // 放入消息队列（非阻塞）
        if (osMessageQueuePut(client_rxq1, &msg, 0, 0) != osOK) {
            printf("WARNING: %s, Message queue full, dropping message!\n", __func__);
            osSemaphoreRelease(sta->sem);
            return AK_FAILED;
        }
		return 0;
	}

	printf("%s, unknown message, len=%d\r\n", __func__, len);
	osSemaphoreRelease(sta->sem);
	return 0;
}

static void rpmsg_unbind_callback(struct rpmsg_endpoint *ept)
{
    struct rpmsg_demo_private *demo_priv = ept->priv;
	printf("Remote endpoint is destroyed\n");
	demo_priv->is_unbound = 1;
}
#if 0
static void thread_rpmsg_client_demo(void *argument)
{
    struct remoteproc *rproc;
    uint32_t send_len;

    rproc = openamp_init();
    if (rproc == NULL) {
		printf("Failed to init openamp framework\r\n");
        return;  // 初始化失败，直接返回
	}

    ak_ahbhant_register_intr(vring_ipi_recv_call_back,rproc);

    demo.ept = openamp_ept_open(ept_name, 0, src_addr, dst_addr,
					&demo, rpmsg_ept_callback, rpmsg_unbind_callback);
	if (demo.ept == NULL) {
		printf("Failed to Create Endpoint\r\n");
        return;  // 创建端点失败，直接返回
	}

    printf("Success to Create Endpoint %s\r\n",ept_name);
    os_msleep(500);

    while(!demo.is_unbound){
        os_msleep(500);
    }
}
#endif

// 消息处理线程函数
static void thread_rpmsg_client_handler(void *argument)
{
    struct rpmsg_client_msg _msg;
    struct rpmsg_client_msg *msg = &_msg;

    while (1) {
        // 从消息队列中获取消息
        if (osMessageQueueGet(client_rxq, msg, 0, osWaitForever) == 0) {
            // 1. 获取数据和长度
            unsigned char *data = msg->data;
            int len = msg->len;
			struct rpmsg_endpoint *ept = msg->ept;
            char *msg_buf = msg->data;

            // 2. 处理数据（例如打印、解析、转发等）
            if (len <= 0) {
				printf("WARNING: Received data of length: %d\n", len);
                printf("Received data: %x %x %x %x\n", msg_buf[0], msg_buf[1], msg_buf[2], msg_buf[3]);
				continue;
            }
			if (NULL == data) {
				printf("WARNING: Received data is NULL\n");
				continue;
            }
			//printf("Received data: %x %x %x %x\n", msg_buf[0], msg_buf[1], msg_buf[2], msg_buf[3]);

			int cmd_id = *((int*)data);
			//printf("cmd_id=%d\n ", cmd_id);
			if (AK_AMP_CMD_ECHO_OPEN == cmd_id) {
				vqe_amp_open(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_OPEN command\n");
			} else if (AK_AMP_CMD_ECHO_CLOSE == cmd_id) {
				vqe_amp_close(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_CLOSE command\n");
			} else if (AK_AMP_CMD_MASTER_SEND_DATA == cmd_id) {
				printf("Received AK_RPMSG_CMD_MASTER_SEND_DATA command\n");
			} else if (AK_AMP_CMD_SET_JITTER_BUF == cmd_id) {
				vqe_amp_set_near_jitter_buf(ept, data, len);
				printf("Received AK_RPMSG_CMD_SET_JITTER_BUF command\n");
			} else if (AK_AMP_CMD_ECHO_GET_ASLC_PARAM == cmd_id) {
				vqe_amp_get_aslc(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_ASLC_PARAM command\n");
				//continue;
			} else if (AK_AMP_CMD_ECHO_SET_ASLC_PARAM == cmd_id) {
				vqe_amp_set_aslc(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_SET_ASLC_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_NR_PARAM == cmd_id) {
				vqe_amp_get_nr(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_NR_PARAM command\n");
				//continue;
			} else if (AK_AMP_CMD_ECHO_SET_NR_PARAM == cmd_id) {
				vqe_amp_set_nr(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_SET_NR_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_AGC_PARAM == cmd_id) {
				vqe_amp_get_agc(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_AGC_PARAM command\n");
				//continue;
			} else if (AK_AMP_CMD_ECHO_SET_AGC_PARAM == cmd_id) {
				vqe_amp_set_agc(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_SET_AGC_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_AEC_PARAM == cmd_id) {
				vqe_amp_get_aec(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_AEC_PARAM command\n");
				//continue;
			}  else if (AK_AMP_CMD_ECHO_SET_AEC_PARAM == cmd_id) {
				vqe_amp_set_aec(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_SET_AEC_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_HS_PARAM == cmd_id) {
				vqe_amp_get_hs(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_HS_PARAM command\n");
				//continue;
			}  else if (AK_AMP_CMD_ECHO_SET_HS_PARAM == cmd_id) {
				vqe_amp_set_hs(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_SET_HS_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_EQ_PARAM == cmd_id) {
				vqe_amp_get_eq(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_EQ_PARAM command\n");
				//continue;
			}  else if (AK_AMP_CMD_ECHO_SET_EQ_PARAM == cmd_id) {
				vqe_amp_set_eq(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_SET_EQ_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_FIll_ADC_STREAM == cmd_id) {
				vqe_amp_fill_adc(ept, data, len);
				//printf("Received AK_RPMSG_CMD_ECHO_FIll_ADC_STREAM command\n");
			} else if (AK_AMP_CMD_ECHO_FIll_LOOPBACK_STREAM == cmd_id) {
				vqe_amp_fill_loopback(ept, data, len);
				//printf("Received AK_RPMSG_CMD_ECHO_FIll_LOOPBACK_STREAM command\n");
			}  else if (AK_AMP_CMD_ECHO_ENABLE_DUMP == cmd_id) {
				printf("Received AK_RPMSG_CMD_ECHO_ENABLE_DUMP command\n");
			} else if (AK_AMP_CMD_ECHO_DISABLE_DUMP == cmd_id) {
				printf("Received AK_RPMSG_CMD_ECHO_DISABLE_DUMP command\n");
			} else if (AK_AMP_CMD_ECHO_GET_VERSION == cmd_id) {
				vqe_amp_get_version(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_GET_VERSION command\n");
			} else if (AK_AMP_CMD_ECHO_FLUSH == cmd_id) {
				//vqe_amp_flush(ept, data, len);
				printf("Received AK_RPMSG_CMD_ECHO_FLUSH command\n");
			} else {
				printf("ERROR: Command not found, cmd_id=%d\n ", cmd_id);
				//continue;
			}

            struct rpmsg_ctrl_msg_ack ack_reply = {0};
            ack_reply.id = AK_AMP_CMD_ACK;
            ack_reply.ack = cmd_id;
            // reply
            int ret = rpmsg_send(ept, &ack_reply, sizeof(struct rpmsg_ctrl_msg_ack));
        }

    }
}

// 消息处理线程函数
static void thread_rpmsg_client_handler1(void *argument)
{
    struct rpmsg_client_msg _msg;
    struct rpmsg_client_msg *msg = &_msg;

    while (1) {
        // 从消息队列中获取消息
        if (osMessageQueueGet(client_rxq1, msg, 0, osWaitForever) == 0) {
            // 1. 获取数据和长度
            unsigned char *data = msg->data;
            int len = msg->len;
			struct rpmsg_endpoint *ept = msg->ept;
            char *msg_buf = msg->data;

            // 2. 处理数据（例如打印、解析、转发等）
            if (len <= 0) {
				printf("WARNING: Received data of length: %d\n", len);
                printf("Received data: %x %x %x %x\n", msg_buf[0], msg_buf[1], msg_buf[2], msg_buf[3]);
				continue;
            }
			if (NULL == data) {
				printf("WARNING: Received data is NULL\n");
				continue;
            }
			//printf("Received data: %x %x %x %x\n", msg_buf[0], msg_buf[1], msg_buf[2], msg_buf[3]);

			int cmd_id = *((int*)data);
			//printf("cmd_id=%d\n ", cmd_id);
			if (AK_AMP_CMD_ECHO_GET_ASLC_PARAM == cmd_id) {
				vqe_amp_get_aslc(ept, data, len);
				printf("----------Received AK_RPMSG_CMD_ECHO_GET_ASLC_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_NR_PARAM == cmd_id) {
				vqe_amp_get_nr(ept, data, len);
				printf("---------Received AK_RPMSG_CMD_ECHO_GET_NR_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_AGC_PARAM == cmd_id) {
				vqe_amp_get_agc(ept, data, len);
				printf("--------Received AK_RPMSG_CMD_ECHO_GET_AGC_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_AEC_PARAM == cmd_id) {
				vqe_amp_get_aec(ept, data, len);
				printf("--------Received AK_RPMSG_CMD_ECHO_GET_AEC_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_HS_PARAM == cmd_id) {
				vqe_amp_get_hs(ept, data, len);
				printf("--------Received AK_RPMSG_CMD_ECHO_GET_HS_PARAM command\n");
			} else if (AK_AMP_CMD_ECHO_GET_EQ_PARAM == cmd_id) {
				vqe_amp_get_eq(ept, data, len);
				printf("---------Received AK_RPMSG_CMD_ECHO_GET_EQ_PARAM command\n");
				//continue;
			} else if (AK_AMP_CMD_ECHO_GET_VERSION == cmd_id) {
				vqe_amp_get_version(ept, data, len);
				printf("--------------Received AK_RPMSG_CMD_ECHO_GET_VERSION command\n");
			} else {
				printf("------------ERROR: Command not found, cmd_id=%d\n ", cmd_id);
			}
        }

    }
}

struct rpmsg_endpoint *rpmsg_eptdev_create_client(const char *ept_name_ex, struct rpmsg_ctrl_msg *msg)
{
	struct rpmsg_endpoint *ept;
	//struct rpmsg_endpoint *ept1;

	s_sta.status = RPMSG_ACK_FAILED;
	s_sta.sem = osSemaphoreNew(1, 0, NULL);
    if (s_sta.sem == NULL) {
        printf("Failed to create semaphore\n");
        goto error_exit;
    }

	printf("@@@@ ept_name_ex =%s, msg->id=%d\r\n", ept_name_ex, msg->id);
	if (strcmp(ept_name_ex, "anyka,rpmsg_client0") == 0) {
	#if 1
		// 创建消息队列，增加队列容量以防止消息丢失
		client_rxq = osMessageQueueNew(10, sizeof(struct rpmsg_client_msg), NULL);
		if (client_rxq == NULL) {
			printf("Failed to create client message queue\n");
			goto free_sem;
		}

		// 创建处理线程
		static const osThreadAttr_t thread_attr = {
			.name = "rpmsg_client_handler",
			.priority = osPriorityNormal,  // 显式设置优先级
			.stack_size = 8*1024  // 增加栈大小到4KB
		};
		thread_id = osThreadNew(thread_rpmsg_client_handler, NULL, &thread_attr);
		if (thread_id == NULL) {
			printf("Failed to create thread\n");
			goto free_queue;
		}
	#endif
		// rpmsg_id is 0
		msg->id = 0;
		ept = openamp_ept_open(ept_name_ex, 0, src_addr, dst_addr, &s_sta,
			rpmsg_ept_callback, rpmsg_unbind_callback);
	} else if (strcmp(ept_name_ex, "anyka,rpmsg_client1") == 0) {
		// rpmsg_id is 0
	#if 1
		// 创建消息队列
		client_rxq1 = osMessageQueueNew(8, sizeof(struct rpmsg_client_msg), NULL);
		if (client_rxq1 == NULL) {
			printf("Failed to create client message queue\n");
			goto free_sem;
		}

		// 创建处理线程
		thread_id1 = osThreadNew(thread_rpmsg_client_handler1, NULL, NULL);
		if (thread_id1 == NULL) {
			printf("Failed to create thread\n");
			goto free_queue;
		}
	#endif
		msg->id = 1;
		ept = openamp_ept_open(ept_name_ex, 0, src_addr, dst_addr, &s_sta,
			rpmsg_ept_callback1, rpmsg_unbind_callback);
	} else {
		printf("ERROR: ept_name_ex error!\r\n");
	}

	if(ept == NULL) {
		printf("Failed to Create Endpoint\r\n");
		goto free_thread;
	}

	/* send info to master */
	rpmsg_send(ept, msg, sizeof(struct rpmsg_ctrl_msg));

	osSemaphoreAcquire(s_sta.sem, 5000);

	if (s_sta.status != RPMSG_ACK_OK) {
		printf("Master not ready. status=0x%lx\r\n", s_sta.status);
		goto free_ept;
	}

//	osSemaphoreDelete(s_sta.sem);

	return ept;
free_ept:
	openamp_ept_close(ept);
free_thread:
    osThreadTerminate(thread_id);
	osThreadTerminate(thread_id1);
free_queue:
	osMessageQueueDelete(client_rxq);
	osMessageQueueDelete(client_rxq1);
free_sem:
	osSemaphoreDelete(s_sta.sem);
error_exit:
	return NULL;
}

void rpmsg_eptdev_release_client(struct rpmsg_endpoint *ept, const char *ept_name_ex)
{
	if (strcmp(ept_name_ex, "anyka,rpmsg_client0") == 0) {
		//osThreadTerminate(thread_id);
		//openamp_ept_close(ept);
		// 删除队列
		//osMessageQueueDelete(client_rxq);
		osMessageQueueReset(client_rxq);
	} else if (strcmp(ept_name_ex, "anyka,rpmsg_client1") == 0) {
		//osThreadTerminate(thread_id1);
		//openamp_ept_close(ept);
		// 删除队列
		//osMessageQueueDelete(client_rxq1);
		osMessageQueueReset(client_rxq1);
	} else {
		printf("ERROR: --ept_name_ex error!\r\n");
	}
}
