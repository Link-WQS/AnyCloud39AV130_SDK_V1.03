#include <string.h>
#include "stdio.h"
#include "rtthread.h"
#include "core_driver.h"
#include "demo_openamp.h"
#include "demo_rpmsg_client.h"
#include "demo_rpmsg_ctrl.h"
#include "ak_vqe_amp.h"
/**
 * main
 */
int main(void)
{
    extern void ak_log_init();

    ak_log_init();
    printf("Build by %s\n", __USER__);
    printf("On %s %s\n", __DATE__, __TIME__);
    printf("Anyka rtthread test-main startup!!!\n");

    // run_openamp_demo();
    // run_rpmsg_client_demo();
    vqe_amp_set_callBack_funs();
    vqe_amp_login();
    printf("Start to run rpmsg demo!\n");
    run_rpmsg_ctrl_daemon();

    while(1) {
        os_msleep(10000);
        printf("arm main running\r\n");
    }
    return 0;
}
