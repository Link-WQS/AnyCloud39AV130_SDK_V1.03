#ifndef __DEMO_RPMSG_CTRL_H__
#define __DEMO_RPMSG_CTRL_H__

void run_rpmsg_ctrl_daemon(void);

void run_rpmsg_ahhbant_print_daemon(void);

#endif/*__DEMO_RPMSG_CTRL_H__*/