#ifndef __DEMO_RPMSG_INTERNAL_H__
#define __DEMO_RPMSG_INTERNAL_H__

#include "openamp.h"

#define RPMSG_ACK_OK                0x13131411

#define RPMSG_ACK_FAILED            0x13131412
#define RPMSG_ACK_NOLISTEN          0x13131413
#define RPMSG_ACK_BUSY              0x13131414
#define RPMSG_ACK_NOMEM             0x13131415
#define RPMSG_ACK_NOENT             0x13131416

#define RPMSG_CREATE_CLIENT         0x13141413
#define RPMSG_CLOSE_CLIENT          0x13141414 /* host release */
#define RPMSG_RELEASE_CLIENT        0x13141415 /* client release */
#define RPMSG_RELEASE               0xffffffff


struct rpmsg_ctrl_msg {
	char name[32];
	uint32_t id;
	uint32_t ctrl_id;
	uint32_t cmd;
} __attribute__((__packed__));

struct rpmsg_ctrl_msg_ack {
	uint32_t id;
	uint32_t ack;
	uint32_t ret;// return value
} __attribute__((__packed__));



#endif/*__DEMO_RPMSG_INTERNAL_H__*/
