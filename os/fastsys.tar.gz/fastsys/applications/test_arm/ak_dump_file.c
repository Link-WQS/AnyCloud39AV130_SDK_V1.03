#include <string.h>
#include "stdio.h"
//#include "ak_io.h"
#include "sdfilter.h"
#include "ak_dump_file.h"
#include "sdfilter.h"

typedef enum akAUDIO_DUMP_ITEM_ID_E
{
    // near path
    AUDIO_ITEM_ADC_STREAM        = AUDIO_ITEM_PCM | 0x010,  // input to Echo's near path
    AUDIO_ITEM_DAC_LOOPBACK      = AUDIO_ITEM_PCM | 0x011,  // 2nd input to Echo's near path
    AUDIO_ITEM_NEAR_DENC         = AUDIO_ITEM_PCM | 0x015,  // after D-ENC
    AUDIO_ITEM_NEAR_EQ           = AUDIO_ITEM_PCM | 0x020,  // after near_EQ
    // synchronized inputs to AEC, stereo format. L: synced_far, R: synced_near
    AUDIO_ITEM_SYNCED_PAIR       = AUDIO_ITEM_PCM | 0x030,  
    AUDIO_ITEM_AEC               = AUDIO_ITEM_PCM | 0x040,  // after AEC
    AUDIO_ITEM_NEAR_NR           = AUDIO_ITEM_PCM | 0x050,  // after near_NR
    AUDIO_ITEM_CORE_RESULT       = AUDIO_ITEM_PCM | 0x060,  // after AGC
    AUDIO_ITEM_NEAR_HS           = AUDIO_ITEM_PCM | 0x065,  // after hs
    AUDIO_ITEM_NEAR_VOLUME       = AUDIO_ITEM_PCM | 0x070,  // after near_Volume
    AUDIO_ITEM_RESULT_STREAM     = AUDIO_ITEM_PCM | 0x080,  // output of Echo's near path

    // far path
    AUDIO_ITEM_FAR_STREAM        = AUDIO_ITEM_PCM | 0x110,  // input to Echo's far path
    AUDIO_ITEM_FAR_EQ            = AUDIO_ITEM_PCM | 0x120,  // after far_EQ
    AUDIO_ITEM_FAR_NR            = AUDIO_ITEM_PCM | 0x130,  // after far_NR
    AUDIO_ITEM_FAR_HS            = AUDIO_ITEM_PCM | 0x140,  // after far_HowlingSuppress
    AUDIO_ITEM_FAR_VOLUME        = AUDIO_ITEM_PCM | 0x150,  // after far_Volume
    AUDIO_ITEM_DAC_STREAM        = AUDIO_ITEM_PCM | 0x160  // output of Echo's far path
} AUDIO_DUMP_ITEM_ID_E;


static int DumpIonWrIndex[DUMP_LIST_NUM] = {0};
static int s32DumpEnableList[DUMP_LIST_NUM] = {0};
static unsigned char* u8DumpRbIon[DUMP_LIST_NUM] = {0};
static int s32DumpItemList[DUMP_LIST_NUM] = {AUDIO_ITEM_ADC_STREAM,// 0
                                            AUDIO_ITEM_DAC_LOOPBACK,// 1
                                            AUDIO_ITEM_NEAR_DENC,// 2
                                            AUDIO_ITEM_NEAR_EQ,// 3
                                            AUDIO_ITEM_SYNCED_PAIR,// 4
                                            AUDIO_ITEM_AEC,// 5
                                            AUDIO_ITEM_NEAR_NR,// 6
                                            AUDIO_ITEM_CORE_RESULT,// 7
                                            AUDIO_ITEM_NEAR_HS,// 8
                                            AUDIO_ITEM_NEAR_VOLUME,// 9
                                            AUDIO_ITEM_RESULT_STREAM,// 10
                                            AUDIO_ITEM_FAR_STREAM,// 11
                                            AUDIO_ITEM_FAR_EQ,// 12
                                            AUDIO_ITEM_FAR_NR,// 13
                                            AUDIO_ITEM_FAR_HS,// 14
                                            AUDIO_ITEM_FAR_VOLUME,// 15
                                            AUDIO_ITEM_DAC_STREAM// 16
                                            };

static int WriteRb(unsigned char *DumpRbIon, T_pCVOID data, int size, int dump_ion_w_index)
{
    unsigned long long data_ts;
    int head_size = sizeof(T_U16) + sizeof(unsigned long long) + sizeof(unsigned int);
    T_U16 ion_stat = 0xFF;
    if (dump_ion_w_index + head_size + size > ION_BUF_SIZE) {
        // 超过了buffer末端的长度，返回头部
        dump_ion_w_index = 0;
        // 读取头部状态是否为可写
        //memcpy(ion_data.result_paddr + dump_ion_w_index, &ion_stat, sizeof(T_U16));
    } 
    memcpy((T_U8 *)DumpRbIon + dump_ion_w_index, &ion_stat, sizeof(T_U16));// 置为不可读
    memcpy((T_U8 *)DumpRbIon + dump_ion_w_index + head_size, data, size);

    memcpy((T_U8 *)DumpRbIon + dump_ion_w_index + sizeof(T_U16), &data_ts, sizeof(unsigned long long));
    memcpy((T_U8 *)DumpRbIon + dump_ion_w_index + sizeof(T_U16) + sizeof(unsigned long long), &size, sizeof(unsigned int));

    ion_stat = 0x11;
    memcpy((T_U8 *)DumpRbIon + dump_ion_w_index, &ion_stat, sizeof(T_U16));// 置为可读
    dump_ion_w_index = dump_ion_w_index + head_size + size;
    return 0;
}

/**
 * DumpFileDataToRb: Dump file callback function
 * @item_id[IN]: Dump item id
 * @size[IN]: write size
 * @data[IN]: write data
 * @meta[IN]: reserve param
 * @cb_param[IN]: Dump item id
 * return: 0 success, other failed
 * notes: Dump file data to ring buffer
 */
void DumpFileDataToRb(T_ECHO_DUMP_ITEM_ID item_id, T_S32 size, T_pCVOID data, T_pCVOID meta, T_HANDLE cb_dump_param, T_U8 pathId)
{
    T_ECHO_PCM_META *pstMeta = (T_ECHO_PCM_META*)meta;

    int i = 0;
    int RetLen = 0;

    //AK_BASE_ThreadMutexLock(&dump_mutex);
    for (i = 0; i < DUMP_LIST_NUM; i++) {
        if (item_id == s32DumpItemList[i] && s32DumpEnableList[i]) {
            printf("@@@@@@ i=%d, item=%d", i, item_id);
            WriteRb(u8DumpRbIon[i], data, size, DumpIonWrIndex[i]);

        }

    }
    //AK_BASE_ThreadMutexUnlock(&dump_mutex);
}

/**
 * DumpFileUpdateInfo - Update dump configuration based on provided attributes
 * @param[in] dump_attr: pointer to AUDIO_AMP_DUMP_ATTR structure containing dump configuration
 * return: No return value (void)
 * notes: 
 *     - Updates the global dump enable list (s32DumpEnableList) and ring buffer ION list (u8DumpRbIon)
 *     - Iterates through DUMP_LIST_NUM items and copies enable status and ION buffer ID from dump_attr
 *     - Used to dynamically configure which dump items are enabled and their associated ION buffers
 *     - This function is typically called when dump settings are changed or initialized
 */
void DumpFileUpdateInfo(AUDIO_AMP_DUMP_ATTR *dump_attr)
{
    int i = 0;
    for (i = 0; i < DUMP_LIST_NUM; i++) {
        s32DumpEnableList[i] = dump_attr->s32ItemEnableList[i];
        u8DumpRbIon[i] = dump_attr->s32ItemIonList[i];
    }
}

