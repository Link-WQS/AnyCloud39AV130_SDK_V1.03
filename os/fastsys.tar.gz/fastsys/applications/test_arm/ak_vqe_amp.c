#include <string.h>
#include "stdio.h"
#include "sdfilter.h"
#include "openamp.h"
#include "demo_rpmsg_internal.h"
#include "ak_dump_file.h"
#include "sdfilter.h"
#include "ak_vqe_amp.h"

static 	T_VOID *AdcHandle = NULL;
static 	T_VOID *DacHandle = NULL;
static int adc_ion_w_index = 0;

static int reply_ack(struct rpmsg_endpoint *ept, int cmd_id)
{
    struct rpmsg_ctrl_msg_ack ack_reply = {0};
    ack_reply.id = AK_AMP_CMD_ACK;
    ack_reply.ack = cmd_id;
    // reply, 失败发送ack
    return rpmsg_send(ept, &ack_reply, sizeof(struct rpmsg_ctrl_msg_ack));
}
int vqe_amp_set_callBack_funs(void)
{
    static int FlagCbInit = 0;
    int s32Ret = AK_SUCCESS;
    T_SDLIB_PLATFORM_DEPENDENT_LIST *sd_cb;

    if( 0 == FlagCbInit ) {
        sd_cb = _SD_GetPlatformDependentList();
        if(sd_cb) {
            sd_cb->Malloc   = (MEDIALIB_CALLBACK_FUN_MALLOC)    osMemoryAlloc;
            sd_cb->Free     = (MEDIALIB_CALLBACK_FUN_FREE)      osMemoryFree;
            sd_cb->printf   = (MEDIALIB_CALLBACK_FUN_PRINTF)    printf;

            FlagCbInit = 1;
            s32Ret = AK_SUCCESS;
        } else {// NULL == sd_cb
            printf("ERROR: sd_cb is null\n");
            s32Ret = AK_FAILED;
        }
    } else { // u8FlagCbInit != 0
        printf("Info: sd_cb already init\n");
    }
    return s32Ret;
}

void vqe_amp_login(void)
{
    _SD_AEC_login(NULL);
    _SD_ASLC_login(NULL);
    _SD_EQ_login(NULL);
    _SD_NR_login(NULL);
    _SD_PcmBuf_login(NULL);
    _SD_HowlingSuppression2_login(NULL);
    _SD_Echo_SetDebugZones(SD_ECHO_DEFAULT_DEBUG_ZONES);
}

int vqe_amp_open(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    
    T_ECHO_IN_INFO echo_in = {0};
    memcpy(&echo_in, data + sizeof(int), sizeof(T_ECHO_IN_INFO));

    echo_in.strVersion = AUDIO_FILTER_VERSION_STRING;
    echo_in.cb_fun.Malloc = (MEDIALIB_CALLBACK_FUN_MALLOC)  osMemoryAlloc;
    echo_in.cb_fun.Free   = (MEDIALIB_CALLBACK_FUN_FREE)    osMemoryFree;
    echo_in.cb_fun.Printf = (MEDIALIB_CALLBACK_FUN_PRINTF)  printf;
    echo_in.cb_fun.notify = (ECHO_CALLBACK_FUN_NOTIFY)      NULL;
    //echo_in.cb_fun.dump   = DumpFileDataToRb;
    echo_in.cb_fun.dump   = NULL;	

    if (AdcHandle) {
        _SD_Echo_Close(AdcHandle);
        adc_ion_w_index = 0;
    }
    AdcHandle = _SD_Echo_Open(&echo_in);
    if (NULL == AdcHandle) {
        printf("ERROR: _SD_Echo_Open failed!\n");
        return AK_FAILED;
    }

    return AK_SUCCESS;
}

int vqe_amp_close(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    int s32Ret = AK_SUCCESS;
    if (AdcHandle) {
        s32Ret = _SD_Echo_Close(AdcHandle);
        if (s32Ret != AK_TRUE) {
            printf("ERROR: _SD_Echo_Close, s32Ret = %d\n", s32Ret);
            s32Ret = AK_FAILED;
        } else {
            printf("_SD_Echo_Close success\n");
            s32Ret = AK_SUCCESS;
        }
        AdcHandle = NULL;
    }
    return s32Ret;
}

int vqe_amp_set_near_jitter_buf(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    struct sd_param_pcmbuf st_pcmbuf = {0};
    memcpy(&st_pcmbuf, data + sizeof(int), sizeof(struct sd_param_pcmbuf));
    _SD_Echo_SetNearJitterBufParam(AdcHandle, 1, &st_pcmbuf);

    return AK_SUCCESS;
}

int vqe_amp_get_aslc(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    struct echo_param_volctrl vol_param = {0};
    _SD_Echo_GetNearVolumeParam(AdcHandle, &vol_param);
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), &vol_param, sizeof(struct echo_param_volctrl));
    // reply
    int ret = rpmsg_send(ept, Data, sizeof(struct echo_param_volctrl) + sizeof(int));
    if (ret < 0) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_ASLC_PARAM failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_ASLC_PARAM sucess\n");
    }
    return AK_SUCCESS;
}

int vqe_amp_set_aslc(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    struct echo_param_volctrl vol_param = {0};
    memcpy(&vol_param, data + sizeof(int), sizeof(struct echo_param_volctrl));
    _SD_Echo_SetNearVolumeParam(AdcHandle, AUDIO_FUNC_ENABLE, &vol_param);

    return AK_SUCCESS;
}

int vqe_amp_get_nr(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    struct echo_param_nr nr_param = {0};
    int ret = _SD_Echo_GetNrParam(AdcHandle, &nr_param);
    if (AK_TRUE == ret) {
        ret = AK_SUCCESS;
    } else {
        printf("ERROR: %s _SD_Echo_GetNrParam failed!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), &nr_param, sizeof(struct echo_param_nr));
    // reply
    if (0 > rpmsg_send(ept, Data, sizeof(struct echo_param_nr) + sizeof(int))) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_NR_PARAM failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_NR_PARAM sucess\n");
    }
    return ret;
}

int vqe_amp_set_nr(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    struct echo_param_nr nr_param = {0};
    memcpy(&nr_param, data + sizeof(int), sizeof(struct echo_param_nr));
    _SD_Echo_SetNrParam(AdcHandle, AUDIO_FUNC_ENABLE, &nr_param);
    return AK_SUCCESS;
}

int vqe_amp_get_agc(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    struct echo_param_agc agc_param = {0};
    int ret = _SD_Echo_GetAgcParam(AdcHandle, &agc_param);
    if (AK_TRUE == ret) {
        ret = AK_SUCCESS;
    } else {
        printf("ERROR: _SD_Echo_GetAgcParam failed!\n");
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), &agc_param, sizeof(struct echo_param_agc));
    // reply
    if (0 > rpmsg_send(ept, Data, sizeof(struct echo_param_agc) + sizeof(int))) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_AGC_PARAM failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_AGC_PARAM sucess\n");
    }
    return ret;
}

int vqe_amp_set_agc(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    struct echo_param_agc agc_param = {0};
    memcpy(&agc_param, data + sizeof(int), sizeof(struct echo_param_agc));
    _SD_Echo_SetAgcParam(AdcHandle, AUDIO_FUNC_ENABLE, &agc_param);
    printf("adc AK_RPMSG_CMD_ECHO_SET_AGC_PARAM sucess\n");
    return AK_SUCCESS;
}

int vqe_amp_get_aec(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    struct echo_param_aec aec_params = {0};
    int ret = _SD_Echo_GetAecParam(AdcHandle, &aec_params);
    if (AK_TRUE == ret) {
        ret = AK_SUCCESS;
    } else {
        printf("ERROR: %s _SD_Echo_GetAgcParam failed!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), &aec_params, sizeof(struct echo_param_aec));
    // reply
    if (0 > rpmsg_send(ept, Data, sizeof(struct echo_param_aec) + sizeof(int))) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_AEC_PARAM failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_AEC_PARAM sucess\n");
    }
    return ret;
}

int vqe_amp_set_aec(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    struct echo_param_aec aec_param = {0};
    memcpy(&aec_param, data + sizeof(int), sizeof(struct echo_param_aec));
    _SD_Echo_SetAecParam(AdcHandle, AUDIO_FUNC_ENABLE, &aec_param);
    printf("adc AK_RPMSG_CMD_ECHO_SET_AEC_PARAM sucess\n");
    return AK_SUCCESS;
}

int vqe_amp_get_hs(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    struct echo_param_howlingSuppress hs_param = {0};
    int ret = _SD_Echo_GetNearHowlingSuppressParam(AdcHandle, &hs_param);
    if (AK_TRUE == ret) {
        ret = AK_SUCCESS;
    } else {
        printf("ERROR: %s _SD_Echo_GetAgcParam failed!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), &hs_param, sizeof(struct echo_param_howlingSuppress));
    // reply
    if (0 > rpmsg_send(ept, Data, sizeof(struct echo_param_howlingSuppress) + sizeof(int))) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_HS_PARAM failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_HS_PARAM sucess\n");
    }
    return ret;
}

int vqe_amp_set_hs(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    struct echo_param_howlingSuppress hs_param = {0};
    memcpy(&hs_param, data + sizeof(int), sizeof(struct echo_param_howlingSuppress));
    _SD_Echo_SetNearHowlingSuppressParam(AdcHandle, AUDIO_FUNC_ENABLE, &hs_param);
    return AK_SUCCESS;
}

int vqe_amp_get_eq(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    printf("vqe_amp_get_eq entry...\n");
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    struct sd_param_eq eq_param = {0};
    int ret = _SD_Echo_GetNearEqParam(AdcHandle, &eq_param);
    if (AK_TRUE == ret) {
        ret = AK_SUCCESS;
    } else {
        printf("ERROR: %s _SD_Echo_GetNearEqParam failed!\n", __func__);
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), &eq_param, sizeof(struct sd_param_eq));
    // reply
    if (0 > rpmsg_send(ept, Data, sizeof(struct sd_param_eq) + sizeof(int))) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_EQ_PARAM failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_EQ_PARAM sucess\n");
    }
    printf("vqe_amp_get_eq exit...\n");
    return ret;
}

int vqe_amp_set_eq(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    struct sd_param_eq eq_param = {0};
    memcpy(&eq_param, data + sizeof(int), sizeof(struct sd_param_eq));
    _SD_Echo_SetNearEqParam(AdcHandle, AUDIO_FUNC_ENABLE, &eq_param);
    return AK_SUCCESS;
}

int vqe_amp_fill_adc(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    ION_DATA_S ion_data = {0};
    memcpy(&ion_data, data + sizeof(int), sizeof(ION_DATA_S));
    
    int head_size = sizeof(T_U16) + sizeof(unsigned long long) + sizeof(unsigned int);
    int send_res = _SD_Echo_FillAdcStream(AdcHandle, (T_U8 *)ion_data.fill_paddr, ion_data.u32DataLen, ion_data.data_ts, 1);

    if (send_res != ion_data.u32DataLen) {// 发送数据满了
        int near_jitterBuf_used_len = 0;
        near_jitterBuf_used_len = _SD_Echo_GetResult(AdcHandle, NULL, 0, 0, 1);
        printf( "_SD_Echo_FillAdcStream has %d %d byte data need to send\n",\
                ion_data.u32DataLen - send_res, send_res);
        printf( "send_res = %d, u32DataLen = %d\n", send_res, ion_data.u32DataLen);
    } else {// 发送数据成功
        unsigned long long data_ts;
        T_U16 ion_stat = 0xFF;
        if (adc_ion_w_index + head_size + ion_data.u32DataLen > ION_BUF_SIZE) {
            // 超过了buffer末端的长度，返回头部
            adc_ion_w_index = 0;
            // 读取头部状态是否为可写
            //memcpy(ion_data.result_paddr + adc_ion_w_index, &ion_stat, sizeof(T_U16));
        } 
        memcpy((T_U8 *)ion_data.result_paddr + adc_ion_w_index, &ion_stat, sizeof(T_U16));// 置为不可读
        int s32Ret = _SD_Echo_GetResult(AdcHandle, \
            (T_U8 *)(ion_data.result_paddr + adc_ion_w_index + head_size), ion_data.u32DataLen, &data_ts, 1);// 14= 2+8+4

        if (0 == s32Ret) {
            s32Ret = 0;
            printf("echo get no data, send_res=%d, u32DataLen=%d \n", send_res, ion_data.u32DataLen);
        }else if (0 > s32Ret) {
            printf("echo get result error \n");
            s32Ret = -1;
        } else {// len > 0
            memcpy((T_U8 *)ion_data.result_paddr + adc_ion_w_index + sizeof(T_U16), &data_ts, sizeof(unsigned long long));
            memcpy((T_U8 *)ion_data.result_paddr + adc_ion_w_index + sizeof(T_U16) + sizeof(unsigned long long), &s32Ret, sizeof(unsigned int));

            ion_stat = 0x11;
            memcpy((T_U8 *)ion_data.result_paddr + adc_ion_w_index, &ion_stat, sizeof(T_U16));// 置为可读
            adc_ion_w_index = adc_ion_w_index + head_size + ion_data.u32DataLen;
        }
    }
    return AK_SUCCESS;
}

int vqe_amp_fill_loopback(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == AdcHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    ION_DATA_S ion_data = {0};
    static int s32Count = 0;
    memcpy(&ion_data, data + sizeof(int), sizeof(ION_DATA_S));

    int s32SendRes = _SD_Echo_FillDacLoopback(AdcHandle,(T_U8 *)ion_data.fill_paddr, ion_data.u32DataLen, ion_data.data_ts, 1);
    if (s32SendRes != ion_data.u32DataLen) {
        if (0 == s32Count) {
            printf("_SD_Echo_FillDacLoopback has %d byte data need to send\n",\
                ion_data.u32DataLen - s32SendRes);
            if (100 == ++s32Count) {
                s32Count = 0;
            }
        }
    }
    return AK_SUCCESS;
}

int vqe_amp_dump_enable(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    AUDIO_AMP_DUMP_ATTR dump_attr = {0};
    memcpy(&dump_attr, data + sizeof(int), sizeof(AUDIO_AMP_DUMP_ATTR));
    DumpFileUpdateInfo(&dump_attr);
    return AK_SUCCESS;
}

int vqe_amp_get_version(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    int ret = AK_SUCCESS;
    T_CHR *version = _SD_GetAudioFilterVersionInfo();
    if (NULL == version) {
        printf("ERROR: _SD_Echo_GetAgcParam failed!\n");
        // reply, 失败发送ack
        reply_ack(ept, cmd_id);
        return AK_FAILED;
    }
    unsigned char Data[512] = {0};
    *((int*)Data) = cmd_id;
    memcpy(Data + sizeof(int), version, strlen(version));
    // reply，成功发送结果
    if (0 > rpmsg_send(ept, Data, strlen(version) + sizeof(int))) {
        printf("adc AK_RPMSG_CMD_ECHO_GET_VERSION failed: %d\n", ret);
    } else {
        printf("adc AK_RPMSG_CMD_ECHO_GET_VERSION sucess, %s\n", version);
    }
    return ret;
}

int vqe_amp_flush(struct rpmsg_endpoint *ept, unsigned char *data, int size)
{
    int cmd_id = *((int*)data);
    if (NULL == DacHandle) {
        printf("ERROR: %s filter not open!\n", __func__);
        return AK_FAILED;
    }
    //memcpy(&nr_param, data + sizeof(int), sizeof(struct echo_param_nr));
    T_HANDLE hUser = AK_TRUE;// reserve param, now not be used
    _SD_Echo_Flush(DacHandle, hUser);

    return AK_SUCCESS;
}
