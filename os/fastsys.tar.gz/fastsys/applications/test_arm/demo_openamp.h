#ifndef __DEMO_OPENAMP_H__
#define __DEMO_OPENAMP_H__

void run_openamp_demo(void);

#endif/*__DEMO_OPENAMP_H__*/