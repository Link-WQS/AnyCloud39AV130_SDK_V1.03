PATH_SDK			:= $(patsubst %/platform,%,$(PATH_PLATFORM))
include $(PATH_SDK)/project/rules.mk

#	
# var changea and makefile load
#
ifeq ($(ARCH),riscv)
include $(PATH_SDK)/project/rules_riscv.mk
endif
ifeq ($(ARCH),arm)
include $(PATH_SDK)/project/rules_arm.mk
endif
ifeq ($(MARCH),u64)
DEFINE				+= -D__ANYKA_SIFIVE_U64__
endif
ifeq ($(MARCH),arm926ejs)
DEFINE				+= -D__ANYKA_ARM_ARM926EJS__
endif
ifeq ($(CHIP),ak3918av200)
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include/mach/av200
endif
ifeq ($(CHIP),ak3918av100)
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include/mach/av100
endif
ifeq ($(CHIP),ak3918av130)
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include/mach/av130
endif
ifeq ($(OS),rtthread)
include $(PATH_SDK)/project/rules_rtt.mk
endif

#var
PATH_OS				= 	$(PATH_PLATFORM)/os
INCLUDE				+= 	$(call OS_INCLUDE,$(PATH_OS),$(ARCH),$(CHIP),$(OS))
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include \
						-I$(PATH_INSTALL)

DEFINE				+= 	$(DEFAULT_DEFINE)
LIBS				+= 	$(DEFAULT_CLIB)
CFLAGS				+= 	$(DEFAULT_CFLAGS) $(DEFINE) $(INCLUDE)
ASFLAGS				+= 	$(DEFAULT_ASFLAGS)
