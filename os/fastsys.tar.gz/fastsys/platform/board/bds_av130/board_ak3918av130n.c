#include "bds.h"
#include "ak3918av130_pinctrl.h"

/*
GPIO 设置
*/
__BDS_DATA static struct bds_pinctrl_settings csi0_sclk_pin_setting[] = {
    [0] = {.gpio = XGPIO_022, .configs = 0x00010010, .func = XGPIO_022_FUNC_CSI0_SCLK},
};

__BDS_DATA static struct bds_pinctrl_settings csi1_sclk_pin_setting[] = {
    [0] = {.gpio = XGPIO_030, .configs = 0x00010010, .func = XGPIO_030_FUNC_CSI1_SCLK},
};

__BDS_DATA static struct bds_pinctrl_settings pwm0_pin_setting[] = {
    [0] = {.gpio = XGPIO_053, .configs = 0x01000000, .func = XGPIO_053_FUNC_PWM_CSI0},
};

__BDS_DATA static struct bds_pinctrl_settings pwm1_pin_setting[] = {
    [0] = {.gpio = XGPIO_054, .configs = 0x01000000, .func = XGPIO_054_FUNC_PWM_CSI1},
};

/*
vi0 pinctrl group 设置
*/
__BDS_DATA static struct bds_pinctrl_state vi0_pinctrl_state[] = {
    {.name = "csi0_sclk", BDS_DECLARE_ARRAY_VAR(settings, csi0_sclk_pin_setting), },
    {.name = "csi1_sclk", BDS_DECLARE_ARRAY_VAR(settings, csi1_sclk_pin_setting), },
    {.name = "pwm0", BDS_DECLARE_ARRAY_VAR(settings, pwm0_pin_setting), },
    {.name = "pwm1", BDS_DECLARE_ARRAY_VAR(settings, pwm1_pin_setting), },
};

/*
sensor0 设置
*/
__BDS_DATA static struct bds_sensor sensor0 = {
    .i2c_id = 0,
    .i2c_addr_sel = 0,
    .gpio_reset = XGPIO_018,
    .gpio_pwdn = XGPIO_048,
    .gpio_fsync = -1,
    .gpio_power = -1
};

/*
sensor1 设置
*/
__BDS_DATA static struct bds_sensor sensor1 = {
    .i2c_id = 0,
    .i2c_addr_sel = 1,
    .gpio_reset = XGPIO_019,
    .gpio_pwdn = XGPIO_049,
    .gpio_fsync = -1,
    .gpio_power = -1
};

/*
vin0 设置
*/
__BDS_DATA static struct bds_vin vin0 = {
    .mipi_sel   = 0,
    .pwm_sel    = 0,
    .sclk       = 0,
    .switch_level   = {-1, -1, -1, -1},
    .switch_id = {-1, -1, -1, -1},
    .sensor     = &sensor0,
};

/*
vin1 设置
*/
__BDS_DATA static struct bds_vin vin1 = {
    .mipi_sel   = 1,
    .pwm_sel    = 1,
    .sclk       = 1,
    .switch_level   = {-1, -1, -1, -1},
    .switch_id = {-1, -1, -1, -1},
    .sensor     = &sensor1,
};

/*
vi0 设置
*/
__BDS_DATA static struct bds_vi0 _vi0 = {
    .pinctrl = { BDS_DECLARE_ARRAY_VAR(ps, vi0_pinctrl_state), },

    .lane_swap = {SENSOR_D0, SENSOR_C0, SENSOR_D1, SENSOR_D2, SENSOR_C1, SENSOR_D3},
    .dndp_swap = {MIPI_DNDP_NOSWAP, MIPI_DNDP_NOSWAP, MIPI_DNDP_NOSWAP, MIPI_DNDP_NOSWAP, MIPI_DNDP_NOSWAP, MIPI_DNDP_NOSWAP},

    .sw = {
        [0] = 0,
        [1] = 0,
        [2] = 0,
        [3] = 0,
    },

    .vin = {
        [0] = &vin0,
        [1] = &vin1,
        [2] = 0,
        [3] = 0,
    },
};

//i2c0
__BDS_DATA static struct bds_pinctrl_settings i2c0_pin_setting[] = {
    [0] = {.gpio = XGPIO_020, .configs = 0x00010010, .func = XGPIO_020_FUNC_TWI0_SDA},
    [1] = {.gpio = XGPIO_021, .configs = 0x00010010, .func = XGPIO_021_FUNC_TWI0_SCL},
};

__BDS_DATA static struct bds_pinctrl_state i2c0_pinctrl_state[] = {
    {.name = "i2c0_pins", BDS_DECLARE_ARRAY_VAR(settings, i2c0_pin_setting), },
};

__BDS_DATA static struct bds_pinctrl_settings i2c1_pin_setting[] = {
    [0] = {.gpio = XGPIO_010, .configs = 0x00010010, .func = XGPIO_010_FUNC_TWI1_SCL},
    [1] = {.gpio = XGPIO_011, .configs = 0x00010010, .func = XGPIO_011_FUNC_TWI1_SDA},
};

__BDS_DATA static struct bds_pinctrl_state i2c1_pinctrl_state[] = {
    {.name = "i2c1_pins", BDS_DECLARE_ARRAY_VAR(settings, i2c1_pin_setting), },
};

__BDS_DATA static struct bds_pinctrl_settings i2c2_pin_setting[] = {
    [0] = {.gpio = XGPIO_018, .configs = 0x00010010, .func = XGPIO_018_FUNC_TWI2_SCL},
    [1] = {.gpio = XGPIO_019, .configs = 0x00010010, .func = XGPIO_019_FUNC_TWI2_SDA},
};

__BDS_DATA static struct bds_pinctrl_state i2c2_pinctrl_state[] = {
    {.name = "i2c2_pins", BDS_DECLARE_ARRAY_VAR(settings, i2c2_pin_setting), },
};

__BDS_DATA static struct bds_i2c i2c[] = {
    [0] = {
        .pinctrl = { BDS_DECLARE_ARRAY_VAR(ps, i2c0_pinctrl_state), },
        .i2c_id = 0,
        .frequency = 312000,
    },
};

/*
root 设置
*/
__BDS_ROOT struct bds_root g_bds_av130n_root = {
    .board_name = "ak3918av130n",
    .vi0 = &_vi0,
    BDS_DECLARE_ARRAY_VAR(i2c, i2c),
};

