#ifndef __BDS_AV130_H__
#define __BDS_AV130_H__

//#define __BDS_ROOT      __attribute__((section(".bds.root")))
//#define __BDS_DATA      __attribute__((section(".bds.data")))

#define __BDS_ROOT
#define __BDS_DATA

//
#define BDS_DECLARE_ARRAY(type, name)      type *name; int name##_num
#define BDS_ARRAY_SIZE(array)              (sizeof((array)) / sizeof((array)[0]))

#define BDS_DECLARE_ARRAY_VAR(name, ptr)   \
    .name = (ptr),   \
    .name##_num = BDS_ARRAY_SIZE(ptr)

#define BDS_DECLARE_ARRAY_NULL(name)   \
    .name = 0,   \
    .name##_num = 0


//
#define BDS_VIN_INPUT_MAX           4
#define BDS_VIN_SWITCH_MAX          4

struct bds_pinctrl_settings {
    unsigned int gpio;
    unsigned long configs;
    unsigned int func;
};

struct bds_pinctrl_state {
    const char *name;
    BDS_DECLARE_ARRAY(struct bds_pinctrl_settings, settings);
};

struct bds_pinctrl {
    BDS_DECLARE_ARRAY(struct bds_pinctrl_state, ps);
};

struct bds_sensor {
    unsigned char  i2c_id;
    unsigned char  i2c_addr_sel;
    unsigned char  gpio_pwdn;
    unsigned char  gpio_reset;
    unsigned char  gpio_power;
    unsigned char  gpio_fsync;
};

struct bds_switch {
    unsigned char id;
    unsigned char gpio;
};

struct bds_vin {
    unsigned char   mipi_sel;
    unsigned char   pwm_sel;
    unsigned char   sclk;

    unsigned char   switch_level[BDS_VIN_SWITCH_MAX];
    unsigned char   switch_id[BDS_VIN_SWITCH_MAX];

    struct bds_sensor *sensor;
};

struct bds_vi0 {
    struct bds_pinctrl pinctrl;

    unsigned char lane_swap[6];
    unsigned char dndp_swap[6];

    struct bds_switch sw[BDS_VIN_SWITCH_MAX];
    struct bds_vin  *vin[BDS_VIN_INPUT_MAX];
};

struct bds_i2c {
    struct bds_pinctrl pinctrl;
    unsigned int i2c_id;
    unsigned int frequency;
};

struct bds_uart {
    struct bds_pinctrl pinctrl;
    unsigned int uart_id;
    unsigned int baudrate;
};

struct bds_root {
    char *board_name;
    struct bds_uart *uart;
    struct bds_vi0 *vi0;
    BDS_DECLARE_ARRAY(struct bds_i2c, i2c);
};

extern struct bds_root *_bds_tab[];

extern struct bds_root *_bds;

#endif
