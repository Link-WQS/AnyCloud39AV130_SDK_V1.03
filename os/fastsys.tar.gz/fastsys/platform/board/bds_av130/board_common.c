#include "bds.h"

extern struct bds_root g_bds_av130l_root;
extern struct bds_root g_bds_av130n_root;

struct bds_root *_bds_tab[] = {
    &g_bds_av130l_root,
    &g_bds_av130n_root,
    0
};

struct bds_root *_bds = 0;

