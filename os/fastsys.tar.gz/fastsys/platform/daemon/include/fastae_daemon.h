#ifndef __FASTAE_DAEMON_H__
#define __FASTAE_DAEMON_H__

enum {
    HOOK_INIT_CALL_F = 0,       //模块初始化前call
    HOOK_INIT_CALL_R,           //模块初始化后call
    HOOK_BASE_INIT_F,           //模块初始化前call
    HOOK_BASE_INIT_R,           //模块初始化后call
    HOOK_CORE_INIT_F,           //模块初始化前call
    HOOK_CORE_INIT_R,           //模块初始化后call
    HOOK_PREV_INIT_F,           //adc i2c
    HOOK_PREV_INIT_R,           //
    HOOK_DEVICE_INIT_F,         //vi sensor
    HOOK_DEVICE_INIT_R,         //

    //
    HOOK_BEFORE_ADC_PROBE = 12,
    HOOK_AFTER_ADC_PROBE,       //ADC 初始化 - 开始
    HOOK_BEFORE_I2C_PROBE,      //I2C 初始化 - 开始
    HOOK_AFTER_I2C_PROBE,       //I2C 初始化 - 结束
    HOOK_BEFORE_VI_PROBE,       //VI模块 初始化 - 开始
    HOOK_AFTER_VI_PROBE,        //VI模块 初始化 - 结束
    HOOK_BEFORE_SENSOR_PROBE,   //sensor 模块初始化 - 开始
    HOOK_AFTER_SENSOR_PROBE,    //sensor 模块初始化 - 结束
    HOOK_BEFORE_VENC_PROBE,     //venc 模块初始化 - 开始
    HOOK_AFTER_VENC_PROBE,      //venc 模块初始化 - 结束

    HOOK_BEFORE_VI_INIT = 24,   //视频采集初始化 - 开始
    HOOK_AFTER_VI_INIT,         //视频采集初始化 - 结束
    HOOK_BEFORE_FASTAE_INIT,    //FASTAE 初始化 - 开始
    HOOK_AFTER_FASTAE_INIT,     //FASTAE 初始化 - 结束
    HOOK_LOAD_AE_TABLE,         //加载AE table表
    HOOK_UPDATE_AE_TABLE,       //更新AE table表
    HOOK_FASTAE_LUMI_MEASURED,  //软光敏lumi测量
    HOOK_FASTAE_STABLE,         //快速收敛AE稳定
    HOOK_MACHINE_SHUTDOWN,      //大核请求关闭小核
    HOOK_GET_IRCUT_LED_STATUS,  //未实现

    HOOK_MAX_NUM = 40,
};

typedef int (*T_FASTAE_HOOK)(void *user_data, void *param);

struct fastae_hook {
    void    *user_data;
    T_FASTAE_HOOK   hook[HOOK_MAX_NUM];
};

struct fastaed_default_param {
    int     isp_default_mode;   //isp sub file index
    int     init_ae;
    int     init_awb;
};

struct fastaed_ae_table_load {
    int     dev_id;
    int     len;
    void    *ae_table;//return
};

struct fastaed_ae_table_update {
    int dev_id;
    unsigned int *data;
    int len;
    int offset;
    unsigned int value;
};

struct fastaed_lumi_measured {
    int dev_id;
    int exp_div_lumi;
    int cur_isp_mode;
};

struct fastaed_misc_config {
    unsigned int night2day_threshold;
    unsigned int day2night_threshold;
    unsigned int day_night_mode_select;
    unsigned int light_sensor_enable;
    /* whiteled_gpio */
    unsigned int whiteled_gpio_nb;
    unsigned int whiteled_gpio_vaildlev;
    unsigned int whiteled_curstate;
    /* irled_gpio */
    unsigned int irled_gpio_nb;
    unsigned int irled_gpio_vaildlev;
    unsigned int irled_curstate;
    /* ircut_a_gpio */
    unsigned int ircut_a_gpio_nb;
    unsigned int ircut_a_gpio_vaildlev;
    unsigned int ircut_a_curstate;
    /* ircut_b_gpio */
    unsigned int ircut_b_gpio_nb;
    unsigned int ircut_b_gpio_vaildlev;
    unsigned int ircut_b_curstate;
};

struct fastaed_dev_misc_config {
    int dev_id;
    struct fastaed_misc_config  misc;
};

struct fastaed_ircut_led_status {
    struct dss_hw_ircut ircut[DSS_IRCUT_MAX_NUM];
    int ircut_a_curstate[DSS_IRCUT_MAX_NUM];
    int ircut_b_curstate[DSS_IRCUT_MAX_NUM];

    struct dss_hw_led led[DSS_LED_MAX_NUM];
    int whiteled_curstate[DSS_LED_MAX_NUM];
    int irled_curstate[DSS_LED_MAX_NUM];
};

int fastae_daemon(void);

int fastae_daemon_init(T_FASTAE_HOOK *hook, void *user_data, const char *board_name);

#define is_fastae_hook(pIns, type)      ((pIns)->hook[type])

#define f_fastae_hook(pIns, type, param) ({   \
    int __ret = 0;  \
    if ((pIns)->hook[type])     \
        __ret = (pIns)->hook[type]((pIns)->user_data, param); \
    __ret;  \
})

int fastaed_set_default_param(int dev_id, struct fastaed_default_param *param);

int fastaed_get_current_isp_mode(int dev_id);

int fastaed_set_isp_mode(int dev_id, int isp_mode);

int fastaed_update_ispconfig(int dev_id);

#endif

