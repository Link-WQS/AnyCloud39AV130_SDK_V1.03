/************************************************************************
 * @Copyright (C) 2021 Anyka (GuangZhou) Micro-Electronic Technology Co.,LTD
 * @FILENAME cmsis_cfg.h
 * @BRIEF    cmsis cfg
 * @Author:  hwh
 * @Date:    2022-05-19
 * @Version:
**************************************************************************/
 
#ifndef __CMSIS_CFG_H__
#define __CMSIS_CFG_H__

// kernel identification string.
#define VERSION_STRING         "v0.00.01"

// the max length of object name.
#define OS_NAME_MAX             8

/*OS component support define.*/
#define osSupportIdleHook       1       ///< OS idle thread hood component: 1=available, 0=not available
#define osSupportTimer          1       ///< OS timer component: 1=available, 0=not available
#define osSupportEventFlags     0       ///< OS eventflags component: 1=available, 0=not available
#define osSupportMutex          1       ///< OS mutex component: 1=available, 0=not available
#define osSupportSemaphore      1       ///< OS semaphore component: 1=available, 0=not available
#define osSupportMessageQueue   1       ///< OS message queue component: 1=available, 0=not available
#define osSuppprtAlignSize      4       ///< OS Memory management Alignment

#ifdef SUPP_THD_STACK_USAGE
    #define osSupportThdStackInfo   1       ///< OS thread stack information component: 1=available, 0=not available
#else
    #define osSupportThdStackInfo   0
#endif

#endif

