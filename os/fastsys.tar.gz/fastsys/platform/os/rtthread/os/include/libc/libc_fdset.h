/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * File      : libc_errno.h
 *
 * Change Logs:
 * Date           Author       Notes
 * 2017-10-30     Bernard      The first version
 */

#ifndef LIBC_FDSET_H__
#define LIBC_FDSET_H__

#include <rtconfig.h>

#endif
