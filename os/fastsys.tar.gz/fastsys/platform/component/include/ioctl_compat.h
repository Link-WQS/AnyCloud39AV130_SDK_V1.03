#ifndef __IOCTL_COMPAT_H
#define __IOCTL_COMPAT_H

#define _IOC(a,b,c,d)   ( ((a)<<30) | ((b)<<8) | (c) | ((d)<<16) )
#define _IOC_NONE       0U
#define _IOC_WRITE      1U
#define _IOC_READ       2U
#define _IOC_NR(x)      ( x & 0x000000ff)

#define _IO(a,b)        _IOC(_IOC_NONE,(a),(b),0)
#define _IOW(a,b,c)     _IOC(_IOC_WRITE,(a),(b),sizeof(c))
#define _IOR(a,b,c)     _IOC(_IOC_READ,(a),(b),sizeof(c))
#define _IOWR(a,b,c)    _IOC(_IOC_READ|_IOC_WRITE,(a),(b),sizeof(c))

/* get # bytes to read */
#define FIONREAD        _IOR('f', 127, int)
/* set/clear non-blocking i/o */
#define FIONBIO         _IOW('f', 126, int)
/* get # bytes outstanding in send queue. */
#define FIONWRITE       _IOR('f', 121, int)

#endif