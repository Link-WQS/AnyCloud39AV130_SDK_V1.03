#include "sensor.h"
#if defined(CONFIG_MACH_AK3918AV200)
#include "video2sensor.h"
#endif
#include "ak_i2c.h"
#include "ak_pinctrl.h"
#include "string.h"
#include "ak_time.h"
#if defined(CONFIG_MACH_AK3918AV200)
#include "ak_isp_param.h"
#endif

static int common_sensor_set_power_on_func(void *arg);
static int common_sensor_probe_id_func(void *arg);
static AK_ISP_SENSOR_CB common_cb;
static struct ak_sensor_ops _s_ak_sensor_ops;

/* ------------------------common i2c read/write---------------------------*/
/*sensor i2c read*/
int ak_sensor_read(void* arg, int reg)
{
    struct ak_sensor_priv* priv = arg;
    struct ak_sensor_subdev *sd = priv->sd;
    struct sensor_info* info = priv->sensor_info;
    uint32_t i2c_id = sd->i2c_id;
    int ret;
    struct i2c_msg msg[2] = {0};
    unsigned char reg_addr[2];
    unsigned char data[2] = {0};
    int value = 0;
    int i;
    char tmp;

    for (i = info->regaddr_byte, tmp = reg&0xff; i > 0; i--) {
        reg_addr[i-1] = tmp;
        tmp = reg >> 8;
    }

    msg[0].addr = info->sensor_i2c_addr[sd->i2c_addr_sel];
    msg[0].flags = 0;
    msg[0].len = info->regaddr_byte;
    msg[0].buf = reg_addr;

    msg[1].addr = info->sensor_i2c_addr[sd->i2c_addr_sel];
    msg[1].flags = 0;
    msg[1].flags |= I2C_M_RD;
    msg[1].len = info->data_byte;
    msg[1].buf = data;  

    ret = ak_i2c_xfer(i2c_id, msg, 2);

    for (i = 0; i < info->data_byte; i++) {
        value <<= 8;
        value |= data[i];
    }

    /*
     * If everything went ok (i.e. 2 msg transmitted), return msgs
     * transmitted, else error code.
     */
    if (ret != 2) {
        sensor_err("%s write reg:%x failed\n", __func__, reg);
        return ret;
    }

    return value;
}

/*sensor i2c write*/
int ak_sensor_write(void* arg, int reg, int value)
{
    struct ak_sensor_priv* priv = arg;
    struct ak_sensor_subdev *sd = priv->sd;
    struct sensor_info* info = priv->sensor_info;
    uint32_t i2c_id = sd->i2c_id;
    int ret;
    struct i2c_msg msg[2] = {0};
    unsigned char buf[4];
    int i;
    char tmp;

    for (i = info->regaddr_byte, tmp = reg&0xff; i > 0; i--) {
        buf[i-1] = tmp;
        tmp = (reg >> 8)&0xff;
    }

    for (i = info->data_byte, tmp = value&0xff; i > 0; i--) {
        buf[i-1+info->regaddr_byte] = tmp;
        tmp = (value >> 8)&0xff;
    }

    msg[0].addr = info->sensor_i2c_addr[sd->i2c_addr_sel];
    msg[0].flags = 0;
    msg[0].len = info->regaddr_byte + info->data_byte;
    msg[0].buf = buf;

    ret = ak_i2c_xfer(i2c_id, msg, 1);

    /*
     * If everything went ok (i.e. 2 msg transmitted), return #bytes
     * transmitted, else error code.
     */
    if (ret != 1)
        sensor_err("%s write reg:%x value:%x failed\n", __func__, reg, value);

    return ret;
}

void *common_sensor_match(struct ak_sensor_subdev *sd, struct sensor_info *sns_info)
{
    //
    struct ak_sensor_priv *sns_priv = osMemoryAlloc(sns_info->struct_size);
    int id;

    if (!sns_priv) {
        sensor_err("%s alloc memory fail\n", __func__);
        return NULL;
    }

    //sns_priv初始化
    memset(sns_priv, 0, sns_info->struct_size);
    sns_priv->sensor_info = sns_info;
    sns_priv->sd = sd;

    //TODO 临时设置,不影响
    sd->sns_priv = sns_priv;

    //power on
    if(sns_info->sensor_cb->sensor_set_power_on_func != NULL)
        sns_info->sensor_cb->sensor_set_power_on_func(sns_priv);
    else
        common_sensor_set_power_on_func(sns_priv);

    if(sns_info->sensor_cb->sensor_probe_id_func != NULL)
        id = sns_info->sensor_cb->sensor_probe_id_func(sns_priv);
    else
        id = common_sensor_probe_id_func(sns_priv);

    if(id == sns_info->actual_sensor_id)
    {
        AK_ISP_SENSOR_CB *cb = sns_info->sensor_cb;
        sensor_info("%s sensor id = 0x%x\n", __func__, id);
        cb->sensor_init_func = (cb->sensor_init_func) ? \
        cb->sensor_init_func : common_cb.sensor_init_func;

        cb->sensor_read_reg_func = (cb->sensor_read_reg_func) ? \
        cb->sensor_read_reg_func : common_cb.sensor_read_reg_func;

        cb->sensor_write_reg_func = (cb->sensor_write_reg_func) ? \
        cb->sensor_write_reg_func : common_cb.sensor_write_reg_func;

        cb->sensor_read_id_func = (cb->sensor_read_id_func) ? \
        cb->sensor_read_id_func : common_cb.sensor_read_id_func;

        cb->sensor_update_a_gain_func = (cb->sensor_update_a_gain_func) ? \
        cb->sensor_update_a_gain_func : common_cb.sensor_update_a_gain_func;

        cb->sensor_update_d_gain_func = (cb->sensor_update_d_gain_func) ? \
        cb->sensor_update_d_gain_func : common_cb.sensor_update_d_gain_func;

        cb->sensor_updata_exp_time_func = (cb->sensor_updata_exp_time_func) ? \
        cb->sensor_updata_exp_time_func : common_cb.sensor_updata_exp_time_func;

        // cb->sensor_updata_exp_time_short_func = (cb->sensor_updata_exp_time_short_func) ? \
        // cb->sensor_updata_exp_time_short_func : common_cb.sensor_updata_exp_time_short_func;

        cb->sensor_set_standby_in_func = (cb->sensor_set_standby_in_func) ? \
        cb->sensor_set_standby_in_func : common_cb.sensor_set_standby_in_func;

        cb->sensor_set_standby_out_func = (cb->sensor_set_standby_out_func) ? \
        cb->sensor_set_standby_out_func : common_cb.sensor_set_standby_out_func;

        cb->sensor_probe_id_func = (cb->sensor_probe_id_func) ? \
        cb->sensor_probe_id_func : common_cb.sensor_probe_id_func;

        cb->sensor_get_resolution_func = (cb->sensor_get_resolution_func) ? \
        cb->sensor_get_resolution_func : common_cb.sensor_get_resolution_func;

        cb->sensor_get_mclk_func = (cb->sensor_get_mclk_func) ? \
        cb->sensor_get_mclk_func : common_cb.sensor_get_mclk_func;

        cb->sensor_get_fps_func = (cb->sensor_get_fps_func) ? \
        cb->sensor_get_fps_func : common_cb.sensor_get_fps_func;

        cb->sensor_get_bus_type_func = (cb->sensor_get_bus_type_func) ? \
        cb->sensor_get_bus_type_func : common_cb.sensor_get_bus_type_func;

        cb->sensor_get_valid_coordinate_func = (cb->sensor_get_valid_coordinate_func) ? \
        cb->sensor_get_valid_coordinate_func : common_cb.sensor_get_valid_coordinate_func;

        cb->sensor_get_parameter_func = (cb->sensor_get_parameter_func) ? \
        cb->sensor_get_parameter_func : common_cb.sensor_get_parameter_func;

        cb->sensor_set_power_on_func = (cb->sensor_set_power_on_func) ? \
        cb->sensor_set_power_on_func : common_cb.sensor_set_power_on_func;

        cb->sensor_set_power_off_func = (cb->sensor_set_power_off_func) ? \
        cb->sensor_set_power_off_func : common_cb.sensor_set_power_off_func;

        cb->sensor_set_fps_func = (cb->sensor_set_fps_func) ? \
        cb->sensor_set_fps_func : common_cb.sensor_set_fps_func;

        // cb->sensor_get_fast_para_func = (cb->sensor_get_fast_para_func) ? \
        // cb->sensor_get_fast_para_func : common_cb.sensor_get_fast_para_func;

        sns_priv->sensor_info = sns_info;
        sns_priv->cb_info.cb  = cb;
        sns_priv->cb_info.arg = sns_priv;

        sd->ops.set = _s_ak_sensor_ops.set;
        sd->ops.get = _s_ak_sensor_ops.get;
        if (sns_info->ops) {
            if (sns_info->ops->set)
                sd->ops.set = sns_info->ops->set;
            if (sns_info->ops->get)
                sd->ops.get = sns_info->ops->get;
        }
    }
    else
    {
        osMemoryFree(sns_priv);
        sns_priv = NULL;
    }

    return sns_priv;

}

/* ------------------------common sensor callback---------------------------*/

static int ak_sensor_set_fps_direct(struct ak_sensor_subdev *sd, void *arg)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sd->sns_priv);
    int fps = *((int *)arg);
    struct sensor_cb_info *sensor_cbi = &priv->cb_info;

    sensor_cbi->cb->sensor_set_fps_func(sensor_cbi->arg, fps);
    return 0;
}

static int ak_sensor_store_initial_regs(struct ak_sensor_priv* priv, void* arg)
{
    AK_ISP_SENSOR_INIT_PARA* sensor_para = arg;
    int ret = -1;

    if (priv->para.reg_info) {
        osMemoryFree(priv->para.reg_info);
        priv->para.reg_info = NULL;
        priv->para.num = 0;
    }

    /*store sensor configurtion*/
    priv->para.num = sensor_para->num;
    priv->para.reg_info = osMemoryAlloc(sizeof(AK_ISP_SENSOR_REG_INFO) * sensor_para->num);
    if (!priv->para.reg_info) {
        pr_err("%s alloc2 fail\n", __func__);
        goto alloc2_fail;
    }

    memcpy(priv->para.reg_info, sensor_para->reg_info, sizeof(AK_ISP_SENSOR_REG_INFO) * sensor_para->num);

    pr_debug("%s para.num;%d\n", __func__, priv->para.num);
    return 0;
alloc2_fail:
    return ret;
}

static AK_S32 ak_sensor_set(struct ak_sensor_subdev *sd, AK_U32 cmd, void *args)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sd->sns_priv);
    AK_S32 ret = 0;

    switch (cmd)
    {
        case SET_FLIP_MIRROR:
            priv->flip_mirror = *((int *)args);
            break;

        case SET_MASTER:
            priv->master_or_slave = MASTER_MODE;
            break;

        case SET_SLAVER:
            priv->master_or_slave = SLAVER_MODE;
            break;

        case SET_FPS_DIRECT:
            ret = ak_sensor_set_fps_direct(sd, args);
            break;
        case SET_BINING_MODE:
            priv->reg_list_no = *((int *)args);
            break;

        case SET_FAST_AE: {
                struct ae_fast_struct *arg=(struct ae_fast_struct *)args;
                priv->aec_parms.target_a_gain = arg->sensor_a_gain;
                priv->aec_parms.target_d_gain = arg->sensor_d_gain;
                priv->aec_parms.target_exp = arg->sensor_exp_time;
            }
            break;

//        case VICAP_APP_SET_SENSOR_INIT:
//            ak_sensor_store_initial_regs(priv, args);
//            break;
        default:
            break;

    }

    return ret;
}

static int ak_sensor_get_sensor_cb(struct ak_sensor_subdev *sd, void **arg)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sd->sns_priv);

    *arg = (void *)&priv->cb_info;
    return 0;
}

static AK_S32 ak_sensor_get(struct ak_sensor_subdev *sd, AK_U32 cmd, void *args)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sd->sns_priv);
    AK_S32 ret = 0;

    switch (cmd)
    {
        case GET_SENSOR_CB:
            ret = ak_sensor_get_sensor_cb(sd, args);
            break;

        case GET_MAX_RES: {
                struct sensor_max_res *max_res = args;
                max_res->width = priv->sensor_info->sensor_output_width[max_res->reg_list_no];
                max_res->height = priv->sensor_info->sensor_output_height[max_res->reg_list_no];
                ret = 0;
            }
            break;
        case GET_SENSOR_ID: {
                struct priv_sensor_id *sensor_id = args;
                sensor_id->sensor_id = priv->sensor_info->sensor_id;
                ret = 0;
            }
            break;
        case GET_CROPCAP: {
                struct v4l2_cropcap* a = args;
                a->bounds.width = priv->sensor_info->sensor_output_width[priv->reg_list_no];
                a->bounds.height = priv->sensor_info->sensor_output_height[priv->reg_list_no];
                a->bounds.left = 0;
                a->bounds.top = 0;
                a->defrect = a->bounds;
                a->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                a->pixelaspect.numerator = 1;
                a->pixelaspect.denominator = 1;

                pr_err("%s bounds.width:%d, bounds.height:%d\n", __func__, a->bounds.width,
                    a->bounds.height);
            }
            break;
    }

    return ret;
}

static struct ak_sensor_ops _s_ak_sensor_ops = {
    .set = ak_sensor_set,
    .get = ak_sensor_get,
};

struct ak_sensor_ops *ak_sensor_get_com_ops(void)
{
    return &_s_ak_sensor_ops;
}

static int get_ae_fast_default(struct ae_fast_struct* ae_fast)
{

static struct ae_fast_struct ae_fast_default = { .sensor_exp_time = 2152,
    .sensor_a_gain = 256,
    .sensor_d_gain = 256,
    .isp_d_gain = 256,
    { .r_gain = 445,
        .g_gain = 256,
        .b_gain = 396,
        .r_offset = 0,
        .g_offset = 0,
        .b_offset = 0 } };

    *ae_fast = ae_fast_default;
    return 0;
}

/* ------------------------common sensor callback---------------------------*/
/*sensor power on*/
static int common_sensor_set_power_on_func(void *arg)
{
    struct ak_sensor_priv* priv = arg;
    struct ak_sensor_subdev *sd = priv->sd;
    struct sensor_info *sensor_info = priv->sensor_info;

    if (sd->gpio_pwdn >= 0) {
        gpio_set_pin_dir(sd->gpio_pwdn, 1);
        gpio_set_pin_level(sd->gpio_pwdn, !sensor_info->sensor_pwdn_level);
    }

    if ((sd->gpio_reset >= 0) && (priv->state == SNS_STATE_POWER_OFF)) {
        gpio_set_pin_dir(sd->gpio_reset, 1);
#if !SUPPORT_DULEOS
//        gpio_set_pin_level(sd->gpio_reset, !sensor_info->sensor_reset_level);
        // os_msleep(25);
//        gpio_set_pin_level(sd->gpio_reset, sensor_info->sensor_reset_level);
        // os_msleep(25);
#endif
        gpio_set_pin_level(sd->gpio_reset, !sensor_info->sensor_reset_level);
        // os_msleep(25);   //TODO need?
    }

    if (priv->state == SNS_STATE_POWER_OFF)
        priv->state = SNS_STATE_POWER_ON;

    // aec_parms_init(sensor_info);
    return 0;
}

static int common_sensor_probe_id_func(void *arg) // use IIC bus
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info *sensor_info = priv->sensor_info;
    int id;
    int value;
    int id_reg_byte = sensor_info->id_reg_byte;

    value = ak_sensor_read(arg, sensor_info->id_reg_h);
    id = value << 8;
    value = ak_sensor_read(arg, sensor_info->id_reg_l);
    id |= value;

    if (id_reg_byte == 3) {
        value = ak_sensor_read(arg, sensor_info->id_reg_b) << 16;
        id |= value;
//        sensor_info("id_reg_byte = 3\n", id_reg_byte);
    }
    return id;
}

/*read sensor register*/
static int common_sensor_read_reg_func(void* arg, const int reg_addr)
{
    return ak_sensor_read(arg, reg_addr);
}

/*write sensor register*/
static int common_sensor_write_reg_func(void* arg, const int reg_addr, int value)
{
    return ak_sensor_write(arg, reg_addr, value);
}

static int common_sensor_read_id_func(void* arg) // no use IIC bus
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info *sensor_info = priv->sensor_info;
    return sensor_info->sensor_id;
}

static int common_sensor_get_resolution_func(void* arg, int* width, int* height)
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info *sensor_info = priv->sensor_info;
    *width = sensor_info->sensor_output_width[priv->reg_list_no];
    *height = sensor_info->sensor_output_height[priv->reg_list_no];

    return 0;
}

/*get mclk*/
static int common_sensor_get_mclk_func(void* arg) 
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info *sensor_info = priv->sensor_info;

    return sensor_info->sensor_mclk; 
}

static int common_sensor_get_fps_func(void* arg)
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info* sensor_info = priv->sensor_info;

    return priv->fps_info.current_fps;
}

/*get valid coordinate*/
static int common_sensor_get_valid_coord_func(void* arg, int* x, int* y)
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info *sensor_info = priv->sensor_info;

    *x = sensor_info->sensor_valid_offset_x[priv->reg_list_no];
    *y = sensor_info->sensor_valid_offset_y[priv->reg_list_no];
    return 0;
}

/*get bus type*/
static enum sensor_bus_type common_sensor_get_bus_type_func(void* arg)
{
    struct ak_sensor_priv* priv = arg;
    struct sensor_info *sensor_info = priv->sensor_info;

    return sensor_info->sensor_bus_type;
}

/*sensor power off*/
static int common_sensor_set_power_off_func(void* arg)
{
    struct ak_sensor_priv* priv = arg;
    struct ak_sensor_subdev *sd = priv->sd;
    struct sensor_info *sensor_info = priv->sensor_info;
#if defined(CONFIG_MACH_AK3918AV130)
    //
#else
    if (sd->gpio_pwdn >= 0) {
        gpio_set_pin_dir(sd->gpio_pwdn, 1);
        gpio_set_pin_level(sd->gpio_pwdn, sensor_info->sensor_pwdn_level);
    }

    if (sd->gpio_reset >= 0) {
        gpio_set_pin_dir(sd->gpio_reset, 1);
        gpio_set_pin_level(sd->gpio_reset, sensor_info->sensor_reset_level);
    }
#endif

    priv->state = SNS_STATE_POWER_OFF;

    return 0;
}

/*set sensor fps*/
static int common_sensor_set_fps_func(void* arg, const int fps)
{
    struct ak_sensor_priv *priv = arg;
    priv->fps_info.to_fps = fps;
    return 0;
}

static int common_sensor_init_func(void* arg, const AK_ISP_SENSOR_INIT_PARA* npara)
{
    struct ak_sensor_priv *priv = arg;

    priv->state = SNS_STATE_INIT;

    priv->state = SNS_STATE_WORK;
    return 0;
}

/*sensor timer*/
static int common_sensor_timer_func(void* arg) { return 0; }

/*standby in*/
static int common_sensor_set_standby_in_func(void* arg) { return 0; }

/*standby out*/
static int common_sensor_set_standby_out_func(void* arg) { return 0; }

/*low level read sensor ID, user i2c ops*/
static int common_sensor_update_a_gain_func(void* arg, const unsigned int a_gain)
{
    struct ak_sensor_priv *priv = arg;
    priv->aec_parms.target_a_gain = a_gain;
    return 0;
}

/*set sensor dgain*/
static int common_sensor_update_d_gain_func(void* arg, const unsigned int d_gain)
{
    struct ak_sensor_priv *priv = arg;
    priv->aec_parms.target_d_gain = d_gain;
    return 0;
}

static int common_sensor_updata_exp_time_func(void* arg, unsigned int exp_time)
{
    struct ak_sensor_priv *priv = arg;
    priv->aec_parms.target_exp = exp_time;
    return 0;
}

/*get self definded params*/
static int common_sensor_get_parameter_func(void* arg, int param, void* value)
{
    struct ak_sensor_priv *priv = arg;
    struct ak_sensor_subdev *sd = priv->sd;
    struct sensor_info *info = priv->sensor_info;
    int ret = 0;

    switch (param) {
        case GET_INTERFACE:
            *((int *)value) = info->dvp ? DVP_INTERFACE:MIPI_INTERFACE;
            break;

        case GET_IO_LEVEL:
            *((int *)value) = info->sensor_io_level;
            break;

        case GET_MIPI_MHZ:
            *((int *)value) = info->mipi_mbps;
            break;

#if defined(CONFIG_MACH_AK3918AV200)
        //TODO 
         case GET_MIPI_LANES_SWAP:
             *((int*)value) = info->mipi_lanes_swap;
             break; 
#endif
        case GET_MIPI_LANES:
            *((int *)value) = info->mipi_lanes;
            break;

        case GET_RESET_GPIO:
            *((int *)value) = sd->gpio_reset;
            break;

        case GET_PWDN_GPIO:
            *((int *)value) = sd->gpio_pwdn;
            break;

        case GET_DUAL_SYNC_MODE:
            if(info->sensor_dual_sync_mode)
                *((enum dual_sync_mode *)value) = info->sensor_dual_sync_mode;
            else
                ret = -1;
            break;

        case GET_MAX_FPS:
            *((int*)value) = info->max_fps[priv->reg_list_no];
            break;
#if defined(CONFIG_MACH_AK3918AV200)
        case GET_RAW_FORMAT:
            *((int*)value) = info->raw_format;
            break;
#endif
        case GET_STEPS_OF_1LINE_EXP:
            if(info->exp_unit <= 0)
                *((char*)value) = 1;
            else if(info->exp_unit > 0)
                *((char*)value) = info->exp_unit;
            break;
        case GET_MAX_EXP:
            *((int*)value) = info->max_exp[priv->reg_list_no];
            break;
        case GET_MAX_AGAIN:
            *((int*)value) = info->max_again_x;
            break;
        case GET_MAX_DGAIN:
            *((int*)value) = info->max_dgain_x;
            break;
        case GET_EXP_BINING2NORMAL:
            *((int*)value) = 100;
            break;

#if defined(CONFIG_MACH_AK3918AV130)
        case GET_REAL_HEIGHT:
            *((int*)value) = info->sensor_output_height[priv->reg_list_no];
            pr_info("GET_REAL_HEIGHT =%d, reg_list_no%d\n",
                    info->sensor_output_height[priv->reg_list_no],
                    priv->reg_list_no);
            ret = 0;
            break;
        case GET_AE_FAST_DEFAULT: {
                get_ae_fast_default(value);
            }
            ret = 0;
            break;
        case GET_SCAN_METHOD:
            ret = -1;
            break;
#endif
        default:
            ret = -1;
            break;
    }

    if(-1 == ret)
        printf("%s param:%d not support\n", __func__, param);

    return ret;
}

static AK_ISP_SENSOR_CB common_cb = {
    .sensor_init_func = common_sensor_init_func,    //空实现
    .sensor_read_reg_func = common_sensor_read_reg_func,
    .sensor_write_reg_func = common_sensor_write_reg_func,
    .sensor_read_id_func = common_sensor_read_id_func,
    .sensor_update_a_gain_func = common_sensor_update_a_gain_func,  //空实现
    .sensor_update_d_gain_func = common_sensor_update_d_gain_func,  //空实现
    .sensor_updata_exp_time_func = common_sensor_updata_exp_time_func,  //空实现
    .sensor_timer_func = common_sensor_timer_func,  //空实现
    .sensor_set_standby_in_func = common_sensor_set_standby_in_func,    //空实现
    .sensor_set_standby_out_func = common_sensor_set_standby_out_func,  //空实现
    .sensor_probe_id_func = common_sensor_probe_id_func,
    .sensor_get_resolution_func = common_sensor_get_resolution_func,
    .sensor_get_mclk_func = common_sensor_get_mclk_func,
    .sensor_get_fps_func = common_sensor_get_fps_func,
    .sensor_get_valid_coordinate_func = common_sensor_get_valid_coord_func,
    .sensor_get_bus_type_func = common_sensor_get_bus_type_func,
    .sensor_get_parameter_func = common_sensor_get_parameter_func,  
    .sensor_set_power_on_func = common_sensor_set_power_on_func,
    .sensor_set_power_off_func = common_sensor_set_power_off_func,
    .sensor_set_fps_func = common_sensor_set_fps_func,  //空实现
};

AK_ISP_SENSOR_CB *ak_sensor_get_com_cbs(void)
{
    return &common_cb;
}

/* ------------------------common sensor callback end---------------------------*/

/*end of file*/
