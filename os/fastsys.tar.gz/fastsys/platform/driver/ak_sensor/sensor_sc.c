#include "sensor.h"
#include "sensor_init_para.h"

#define EXP_EFFECT_FRAMES    1 /*adjust exp_time for 1/2 frames*/
#define A_GAIN_EFFECT_FRAMES 1 /*adjust a_gain for 1/2 frames*/
#define D_GAIN_EFFECT_FRAMES 1 /*adjust d_gain for 1/2 frames*/

#define FLIP_OFFSET     0
#define MIRROR_OFFSET   1

struct smartsen_attr
{
    struct ak_sensor_priv   priv;
};

/* ------------------------sc common function---------------------------*/
static int sc_sensor_set_standby_in_func(void* arg) {
    struct ak_sensor_priv *priv = arg;

    //sleep mode enable
    return ak_sensor_write(priv, 0x100, 0);
}

static int __get_reg_frame_vts(struct ak_sensor_priv* priv)
{
    return (ak_sensor_read(priv, 0x320e) & 0x7f) << 8
        | ak_sensor_read(priv, 0x320f);
}

static int __set_reg_frame_vts(struct ak_sensor_priv* priv, int vts)
{
    int active_blank_rows = vts - 4;
    int ret = 0;

    ak_sensor_write(priv, 0x320e, (vts >> 8) & 0x7f);
    ak_sensor_write(priv, 0x320f, vts & 0xff);

    if (priv->master_or_slave == SLAVER_MODE) {
        ak_sensor_write(priv, 0x322e, (active_blank_rows >> 8));
        ak_sensor_write(priv, 0x322f, (active_blank_rows & 0xff));
    }

    priv->fps_info.reg_fps_value = vts;

    return ret;
}

/*set sensor exp time*/
static int __set_reg_exp_time(struct ak_sensor_priv* priv, int exp_time)
{
    int ret = 0;
    struct sensor_info* info = priv->sensor_info;

    unsigned char exposure_time_ext;
    unsigned char exposure_time_msb;
    unsigned char exposure_time_lsb;

    //printf("%s, exp:%d\n", __func__, exp_time);
    if (exp_time < 1) {
        exp_time = 1;
    }

    exposure_time_ext = (exp_time >> 12) & 0xf;
    exposure_time_msb = (exp_time >> 4) & 0xff;
    exposure_time_lsb = ((exp_time)&0xf) << 4;

    ak_sensor_write(priv, 0x3e00, exposure_time_ext); //EXP_REG_E
    ak_sensor_write(priv, 0x3e01, exposure_time_msb); //EXP_REG_H
    ak_sensor_write(priv, 0x3e02, exposure_time_lsb); //EXP_REG_L
    return ret;
}

static void __update_frame_vts_and_exp_ctrl(struct ak_sensor_priv* priv)
{
    /*
     * exp_time=1 mean half line exptime
     * max exp_time = {R0x320e[6:0],R0x320f} * 2 - 8
     */
    int const cur_frame_vts = __get_reg_frame_vts(priv);
    int const target_frame_vts = priv->fps_info.to_fps_value;
    struct sensor_info* info = priv->sensor_info;
    int max_exp_ctrl = (info->exp_unit == 1) ? \
        priv->fps_info.to_fps_value - 6 : priv->fps_info.to_fps_value * 2 - 8; // Vts*2-11
    int target_exp_ctrl = 0;

    if (priv->aec_parms.target_exp <= max_exp_ctrl) {
        target_exp_ctrl = priv->aec_parms.target_exp;
    } else {
        target_exp_ctrl = max_exp_ctrl;
    }

//    pr_err("VTS = %d->%d \n", cur_frame_vts, target_frame_vts);
//    pr_err("EXP = %d/%d \n", target_exp_ctrl, priv->aec_parms.target_exp);

    if ((target_frame_vts <= 0) || (target_exp_ctrl <= 0))
        return;

    if (target_frame_vts >= cur_frame_vts) {
        if (target_frame_vts != cur_frame_vts)
            __set_reg_frame_vts(priv, target_frame_vts);
        __set_reg_exp_time(priv, target_exp_ctrl);
    } else {
        __set_reg_exp_time(priv, target_exp_ctrl);
        __set_reg_frame_vts(priv, target_frame_vts);
        priv->fps_info.reg_fps_value = target_frame_vts;
    }
}

static int sc_sensor_updata_exp_time_func(void *arg, unsigned int exp_time)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    priv->aec_parms.target_exp = exp_time;
    if (priv->state < SNS_STATE_INIT)
        return 0;

    __update_frame_vts_and_exp_ctrl(arg);

    return EXP_EFFECT_FRAMES;   //adjust exp_time for 1/2 frames
}

static int sc_fps_to_vts(struct ak_sensor_priv* priv, const int fps)
{
    /*
     * sc431ai:
     *
     * mipi:
     * HTS=(0x320c,0x320d)*2
     * VTS=(0x320e[6:0],0x320f)
     * fps = pclk / HTS / VTS
     *
     */
    int vts;
    unsigned int fps_tmp;
    struct sensor_info* info = priv->sensor_info;

    sensor_info("%s #%d fps:%d\n", __func__, __LINE__, fps);

    switch (fps) {
        case 12:
            fps_tmp = 1250;
            break;

        case 14:
            fps_tmp = 1428;
            break;

        default:
            fps_tmp = fps * 100;
            break;
    }

    vts = priv->aec_parms.calc_vts_tmp / fps_tmp;

    return vts;
}

/*set sensor fps*/
static int sc_sensor_set_fps_func(void *arg, int fps)
{
    int tmp;
    struct ak_sensor_priv *priv = arg;

    tmp = sc_fps_to_vts(priv, fps);
    // pr_info("\nfps:%d to vts:%x\n",fps,tmp);
    if (tmp > 0) {
        priv->fps_info.to_fps_value = tmp;
        priv->fps_info.to_fps = fps;
    }

    return 0;
}


static int sc_set_fps_direct(struct ak_sensor_subdev *sns_obj, void *arg)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sns_obj->sns_priv);
    struct sensor_cb_info *sensor_cbi = &priv->cb_info;
    int fps = *((int *)arg);

    if (priv->state < SNS_STATE_INIT) {
        ak_sensor_get_com_cbs()->sensor_set_fps_func(sensor_cbi->arg, fps);
        return 0;
    }

    sensor_cbi->cb->sensor_set_fps_func(sensor_cbi->arg, fps);
    if (priv->fps_info.to_fps != priv->fps_info.current_fps) {
        __update_frame_vts_and_exp_ctrl(priv);
        priv->fps_info.current_fps = priv->fps_info.to_fps;
    }
    return 0;
}

static int sc_set_flip_mirror(struct ak_sensor_subdev *sns_obj, void *arg)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sns_obj->sns_priv);
    struct sensor_cb_info *sensor_cbi = &priv->cb_info;
    int enable = *((int*)arg);
    int value = 0;
    int flip_en = enable & (0x1 << FLIP_OFFSET);
    int mirror_en = enable & (0x1 << MIRROR_OFFSET);

    if (priv->state < SNS_STATE_INIT) {
        ak_sensor_get_com_ops()->set(sns_obj, SET_FLIP_MIRROR, arg);
        return 0;
    }

    if (flip_en)
        value |= 0x3 << 5;
    else
        value &= ~(0x3 << 5);

    if (mirror_en)
        value |= 0x3 << 1;
    else
        value &= ~(0x3 << 1);

    //FLIP_MIRROR reg 0x3221
    ak_sensor_write(priv, 0x3221, value);

    return 0;
}

static AK_S32 sc_sensor_set(struct ak_sensor_subdev *sns_obj, AK_U32 cmd, void *args)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sns_obj->sns_priv);
    struct ak_sensor_ops *com_ops = ak_sensor_get_com_ops();
    AK_S32 ret = 0;

    switch (cmd)
    {
        case SET_FPS_DIRECT:
            ret = sc_set_fps_direct(sns_obj, args);
            break;

        case SET_FLIP_MIRROR:
            ret = sc_set_flip_mirror(sns_obj, args);
            break;

        default:
            ret = com_ops->set(sns_obj, cmd, args);
            break;
    }

    return ret;
}

static struct ak_sensor_ops sc_sensor_ops = {
    .set = sc_sensor_set,
};

/* ------------------------sc common function end---------------------------*/

/* ------------------------sc200ai sensor callback---------------------------*/
#ifdef SC200AI
static AK_ISP_SENSOR_CB sc200ai_cb;

static void smartsen_parms_init_f(struct ak_sensor_priv *priv, AK_ISP_SENSOR_INIT_PARA* para)
{
    struct sensor_info *sns_info = priv->sensor_info;
    AK_ISP_SENSOR_REG_INFO* preg_info;
    int vts_h_tmp = 0x4, vts_l_tmp = 0x65;
    int i = 0;

    preg_info = para->reg_info;
    for (i = 0; i < para->num; i++) {
        if (preg_info->reg_addr == 0x320e)
            vts_h_tmp = preg_info->value;
        else if (preg_info->reg_addr == 0x320f)
            vts_l_tmp = preg_info->value;

        preg_info++;
    }

    priv->aec_parms.calc_vts_tmp = (vts_h_tmp << 8 | vts_l_tmp) * sns_info->max_fps[priv->reg_list_no] * 100;
    pr_err("calc_vts_tmp %d \n", priv->aec_parms.calc_vts_tmp);
}

static int sc200ai_sensor_init_func(void *arg, const AK_ISP_SENSOR_INIT_PARA *npara)
{
    int i;
    int value;
    AK_ISP_SENSOR_REG_INFO *preg_info;
    struct ak_sensor_priv *priv = arg;
    struct sensor_info *info = priv->sensor_info;
    struct smartsen_attr *sc_attr = container_of(priv, struct smartsen_attr, priv);
    AK_ISP_SENSOR_INIT_PARA *para = &priv->para;
    AK_ISP_SENSOR_CB *sensor_cb = priv->cb_info.cb;
    AK_ISP_SENSOR_INIT_PARA para1;

    sensor_info("%s sensor_mode %s\n", __func__,
        (priv->master_or_slave == MASTER_MODE) ? "MASTER" : "SLAVER");

    if (priv->master_or_slave == MASTER_MODE) {
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)sc200ai_960x540_120fps;
            para->num = sizeof(sc200ai_960x540_120fps)
                / sizeof(sc200ai_960x540_120fps[0]) / 2;
        }
        else
        {
            preg_info = (void*)sc200ai_1920x1080_30fps;
            para->num = sizeof(sc200ai_1920x1080_30fps)
                / sizeof(sc200ai_1920x1080_30fps[0]) / 2;
        }
    } else if (priv->master_or_slave == SLAVER_MODE) {
        sensor_err("[%s]%dSLAVER mode not support\n", __func__, __LINE__);
    } else {
        if (para->num <= 0 && npara)
            para = (void*)npara;

        preg_info = para->reg_info;
    }
    sensor_info("reg_list_no:%d, para_num:%d\n", priv->reg_list_no, para->num);

    if(preg_info == NULL){
        sensor_err("preg_info == NULL\n");
        return -1;
    }

    priv->state = SNS_STATE_INIT;
    para1.num = para->num;
    para1.reg_info = preg_info;
    smartsen_parms_init_f(priv, &para1);
    if (priv->fps_info.to_fps == 0)
        priv->fps_info.to_fps = info->max_fps[priv->reg_list_no];
    for (i = 0; i < para->num; i++) {

        if((preg_info->reg_addr == 0x100) && (preg_info->value == 1)){
            pr_err("init fps_exp_again:%d-%d-%d\r\n", priv->fps_info.to_fps,
                                                        priv->aec_parms.target_exp,
                                                        priv->aec_parms.target_a_gain);

            sensor_cb->sensor_set_fps_func(priv, priv->fps_info.to_fps);

            sensor_cb->sensor_updata_exp_time_func(priv, priv->aec_parms.target_exp);

            priv->fps_info.current_fps = priv->fps_info.to_fps;//TODO

            sensor_cb->sensor_update_a_gain_func(priv, priv->aec_parms.target_a_gain);

            sensor_cb->sensor_update_d_gain_func(priv, priv->aec_parms.target_d_gain);

            sc_set_flip_mirror(priv->sd, &priv->flip_mirror);
        }

        ak_sensor_write(arg, preg_info->reg_addr, preg_info->value);
        preg_info++;
    }
    //VTS_REG_H 0x320e  VTS_REG_L 0x320f
//    sc_attr->aec_parms.reg_frame_vts =
//        (ak_sensor_read(arg,0x320e) << 8 | ak_sensor_read(arg,0x320f));
//    //HTS_REG_H 0x320c  HTS_REG_L 0x320d
//    sc_attr->aec_parms.reg_frame_hts =
//        (ak_sensor_read(arg,0x320c) << 8 | ak_sensor_read(arg,0x320d)) * 2;
//    sc_attr->aec_parms.pclk_freq = sc_attr->aec_parms.reg_frame_hts *
//        sc_attr->aec_parms.reg_frame_vts * info->max_fps;
//
//    sensor_info("%s hts %d vts %d pclk %d\n", __func__,
//        sc_attr->aec_parms.reg_frame_hts, sc_attr->aec_parms.reg_frame_vts,
//        sc_attr->aec_parms.pclk_freq);
//
//    priv->fps_info.current_fps = info->max_fps;
//    priv->fps_info.to_fps = priv->fps_info.current_fps;
//    priv->fps_info.to_fps_value = sc_attr->aec_parms.reg_frame_vts;
//    priv->fps_info.reg_fps_value = sc_attr->aec_parms.reg_frame_vts;

    // sc200ai_agc_mode
    value = ak_sensor_read(arg, 0x3e03) & 0xf0; //AGC_CTRL 0x3e03
    value |= 0xb; //AGC_CTRL[3:0] set to 0xb
    ak_sensor_write(arg, 0x3e03, value);

    priv->state = SNS_STATE_WORK;

    return 0;
}
/* end of func sc200ai_sensor_init_func */

static int sc200ai_sensor_update_a_gain_func(void *arg, const unsigned int a_gain)
{
    /*
     * max again < 25 times = 8192
     * */
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const gain = (int const )a_gain * 1000 / 256;
    int ana_gain = 0x03;
    int ana_fine_gain = 0x40;
    priv->aec_parms.target_a_gain = a_gain;

    if (priv->state < SNS_STATE_INIT)
    {
        return 0;
    }

    if (gain < 1000)
    {
        ana_gain = 0x03;
        ana_fine_gain = 0x40;
    }
    else if (gain < 2000)
    {
        ana_gain = 0x03;
        ana_fine_gain = (gain - 1000) * (0x7f - 0x40) / (1984 - 1000) + 0x40;

    }
    else if (gain < 3400)
    {
        ana_gain = 0x07;
        ana_fine_gain = (gain - 2000) * (0x6c - 0x40) / (3375 - 2000) + 0x40;

    }
    else if (gain < 6800)
    {
        ana_gain = 0x23;
        ana_fine_gain = (gain - 3400) * (0x7f - 0x40) / (6747 - 3400) + 0x40;

    }
    else if (gain < 13600)
    {
        ana_gain = 0x27;
        ana_fine_gain = (gain - 6800) * (0x7f - 0x40) / (13494 - 6800) + 0x40;

    }
    else if (gain < 27200)
    {
        ana_gain = 0x2f;
        ana_fine_gain = (gain - 13600) * (0x7f - 0x40) / (26988 - 13600) + 0x40;

    }
    else if (gain <= 53975)
    {
        ana_gain = 0x3f;
        ana_fine_gain = (gain - 27200) * (0x7f - 0x40) / (53975 - 27200) + 0x40;

    }
    else {
        ana_gain = 0x3f;
        ana_fine_gain = 0x7f;
    }
    ak_sensor_write(arg, 0x3e08,ana_gain);        //ANA GAIN    AGAIN_REG 0x3e08
    ak_sensor_write(arg, 0x3e09,ana_fine_gain);        //DIG GAIN   A_FINE_GAIN_REG 0x3e09

    return A_GAIN_EFFECT_FRAMES;   //A_GAIN_EFFECT_FRAMES 1 adjust a_gain for 1/2 frames
}

static int sc200ai_sensor_update_d_gain_func(void *arg, const unsigned int d_gain)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const gain = d_gain * 1000 / 256;
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int x = 0,range = 0;
    priv->aec_parms.target_d_gain = d_gain;

    if (priv->state < SNS_STATE_INIT)
    {
        return 0;
    }

    x = gain / 1000;
    range = 0xfe - 0x80;

    if (x < 1)
    {
        dig_gain = 0x00;
        dig_fine_gain = 0x80;

    }
    else if (x < 2)
    {
        dig_gain = 0x00;
        dig_fine_gain = (gain - 1000) * range / (1984 - 1000) + 0x80;

    }
    else if (x < 4)
    {
        dig_gain = 0x01;
        dig_fine_gain = (gain - 2000) * range / (3969 - 2000) + 0x80;

    }
    else if (x < 8)
    {
        dig_gain = 0x03;
        dig_fine_gain = (gain - 4000) * range / (7938 - 4000) + 0x80;

    }
    else if (x < 16)
    {
        dig_gain = 0x07;
        dig_fine_gain = (gain - 8000) * range / (15875 - 8000) + 0x80;

    }
    else if (x < 32)
    {
        dig_gain = 0x0f;
        dig_fine_gain = (gain - 16000) * range / (31750 - 16000) + 0x80;

    }
    else {
        dig_gain = 0x0f;
        dig_fine_gain = 0xfe;
    }

    ak_sensor_write(arg, 0x3e06, dig_gain);     //DGAIN_REG 0x3e06
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);   //D_FINE_GAIN_REG 0x3e07


    return D_GAIN_EFFECT_FRAMES;    //D_GAIN_EFFECT_FRAMES 1 adjust d_gain for 1/2 frames
}

static AK_ISP_SENSOR_CB sc200ai_cb = {
    .sensor_init_func = sc200ai_sensor_init_func,

    .sensor_update_a_gain_func = sc200ai_sensor_update_a_gain_func,
    .sensor_update_d_gain_func = sc200ai_sensor_update_d_gain_func,
    .sensor_updata_exp_time_func = sc_sensor_updata_exp_time_func,
    .sensor_set_standby_in_func = sc_sensor_set_standby_in_func,
    .sensor_set_fps_func = sc_sensor_set_fps_func,
};


#define SC200AI_SENSOR_INFO {   \
    .sensor_pwdn_level              = 0,    \
    .sensor_reset_level             = 0,    \
    .sensor_i2c_addr                = {0x30, 0x32}, \
    .sensor_cb                      = &sc200ai_cb,  \
    .regaddr_byte                   = 2,    \
    .data_byte                      = 1,    \
    .max_fps                        = {30, 120},   \
    .max_exp                        = {3375/2, 558},   \
    .max_again_x                    = 53,   \
    .max_dgain_x                    = 32,   \
    .id_reg_h                       = 0x3107,   \
    .id_reg_l                       = 0x3108,   \
    .actual_sensor_id               = 0xcb1c,   \
    .sensor_id                      = 0x200a,   \
    .sensor_output_width            = {1920, 960}, \
    .sensor_output_height           = {1080, 540}, \
    .sensor_mclk                    = 24,   \
    .sensor_valid_offset_x          = {0,0},    \
    .sensor_valid_offset_y          = {0,0},    \
    .sensor_io_level                = IO_LEVEL_1V8, \
    .sensor_dual_sync_mode          = DUAL_SYNC_PWM_FREQ_FIXED, \
    .exp_unit                       = 2, \
    .raw_format                     = 3,    \
    .mipi_lanes_swap                = 0x435A1,  \
    .mipi_lanes                     = 2,    \
    .sensor_bus_type                = BUS_TYPE_RAW, \
    .struct_size                    = sizeof(struct smartsen_attr),   \
    .ops                            = &sc_sensor_ops,   \
}

#endif
/* ------------------------sc200ai sensor callback end-----------------------*/


/* ------------------------sc450ai sensor callback---------------------------*/
#ifdef SC450AI

/* for sc450ai again calc */
#define RANGE(gain_max,gain_min)  (gain_max - gain_min)
#define CALC_AGAIN_FINE_GAIN(val,max,min,gain_max,gain_min)  \
    (((val-min) * RANGE(gain_max,gain_min) / (max-min)) + gain_min)

static AK_ISP_SENSOR_CB sc450ai_cb;

struct sensor_sc450ai_attr{

    struct smartsen_attr smartsen_attr;

};

#define SC450AI_SENSOR_INFO {                           \
    .sensor_pwdn_level              = 0,                \
    .sensor_reset_level             = 0,                \
    .sensor_i2c_addr                = {0x30, 0x32},         \
    .sensor_cb                      = &sc450ai_cb,          \
    .regaddr_byte                   = 2,                \
    .data_byte                      = 1,                \
    .max_fps                        = {30, 120},               \
    .max_exp                        = {2*1520-8, 780},   \
    .max_again_x                    = 59,   \
    .max_dgain_x                    = 16,   \
    .id_reg_h                       = 0x3107,           \
    .id_reg_l                       = 0x3108,           \
    .actual_sensor_id               = 0xbd2f,               \
    .sensor_id                      = 0x450a,               \
    .sensor_output_width            = {2688, 1280},             \
    .sensor_output_height           = {1520, 720},             \
    .sensor_mclk                    = 24,               \
    .sensor_valid_offset_x          = {0,0},                \
    .sensor_valid_offset_y          = {0,0},                \
    .sensor_io_level                = IO_LEVEL_1V8,     \
    .sensor_dual_sync_mode          = DUAL_SYNC_PWM_FREQ_FIXED, \
    .exp_unit                       = 2, \
    .raw_format                     = 3,                \
    .mipi_lanes_swap                = 0x55032,  /*单目板0x55032 双目板0x435A1*/\
    .mipi_lanes                     = 2,    \
    .sensor_bus_type                = BUS_TYPE_RAW,     \
    .struct_size                    = sizeof(struct smartsen_attr),   \
    .ops                            = &sc_sensor_ops,   \
}



/*from CloudAV200 sc450driver*/
static int sc450ai_sensor_init_func(void *arg, const AK_ISP_SENSOR_INIT_PARA *npara)
{
    int i;
    int value;
    AK_ISP_SENSOR_REG_INFO *preg_info;
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;
   struct smartsen_attr *sc_attr = container_of(priv, struct smartsen_attr, priv);
    AK_ISP_SENSOR_INIT_PARA *para = &priv->para;
    AK_ISP_SENSOR_CB *sensor_cb = priv->cb_info.cb;
    AK_ISP_SENSOR_INIT_PARA para1;

    sensor_info("%s sensor_mode %s\n", __func__,
        (priv->master_or_slave == MASTER_MODE) ? "MASTER" : "SLAVER");

    if (priv->master_or_slave == MASTER_MODE) {
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)sc450ai_1280x720_120fps_2lane_10bit_720Mbps_master;
            para->num = sizeof(sc450ai_1280x720_120fps_2lane_10bit_720Mbps_master)
                / sizeof(sc450ai_1280x720_120fps_2lane_10bit_720Mbps_master[0]) / 2;
        }
        else
        {
            preg_info = (void*)sc450ai_2688x1520_30fps_2lane_10bit_720Mbps_master;
            para->num = sizeof(sc450ai_2688x1520_30fps_2lane_10bit_720Mbps_master)
                / sizeof(sc450ai_2688x1520_30fps_2lane_10bit_720Mbps_master[0]) / 2;
        }
    } else if (priv->master_or_slave == SLAVER_MODE) {
        sensor_err("%s %dSLAVER mode not support\n", __func__, __LINE__);
    } else {
        if (para->num <= 0 && npara)
            para = (void*)npara;

        preg_info = para->reg_info;
    }

    if(preg_info == NULL){
        sensor_err("preg_info == NULL\n");
        return -1;
    }
    sensor_info("reg_list_no:%d, para_num:%d\n", priv->reg_list_no, para->num);

    priv->state = SNS_STATE_INIT;
    para1.num = para->num;
    para1.reg_info = preg_info;
    smartsen_parms_init_f(priv, &para1);
    if (priv->fps_info.to_fps == 0)
        priv->fps_info.to_fps = info->max_fps[priv->reg_list_no];
    for (i = 0; i < para->num; i++) {

        if((preg_info->reg_addr == 0x100) && (preg_info->value == 1)){
            pr_err("init fps_exp_again:%d-%d-%d\r\n", priv->fps_info.to_fps,
                                                        priv->aec_parms.target_exp,
                                                        priv->aec_parms.target_a_gain);

            sensor_cb->sensor_set_fps_func(priv, priv->fps_info.to_fps);

            sensor_cb->sensor_updata_exp_time_func(priv, priv->aec_parms.target_exp);

            priv->fps_info.current_fps = priv->fps_info.to_fps;//TODO

            sensor_cb->sensor_update_a_gain_func(priv, priv->aec_parms.target_a_gain);

            sensor_cb->sensor_update_d_gain_func(priv, priv->aec_parms.target_d_gain);

            sc_set_flip_mirror(priv->sd, &priv->flip_mirror);
        }

        ak_sensor_write(arg, preg_info->reg_addr, preg_info->value);
        preg_info++;
    }
    priv->state = SNS_STATE_WORK;

    return 0;
}
/* end of func ak_sensor_init_func */

/*set sensor again*/
/*max gain: 60999 (59.57 times)*/
static int sc450ai_sen_update_a_gain_func(
    void* arg, const unsigned int a_gain)
{
    struct ak_sensor_priv* priv = arg;
    unsigned int again = a_gain * 1000 / 256;    //*4
    int ana_gain = 0x00;
    int ana_fine_gain = 0x00;

    if (again < 1000) {             //gain<1x
        ana_gain = 0x03;
        ana_fine_gain = 0x40;
    } else if (again < 2000) {      //gain<1.95x
        ana_gain = 0x03;
        ana_fine_gain = CALC_AGAIN_FINE_GAIN(again, 2000, 1000, 0x80, 0x40);
    } else if (again < 3813) {      //again<3.72x
        ana_gain = 0x07;
        ana_fine_gain = CALC_AGAIN_FINE_GAIN(again, 3813, 2000, 0x7a, 0x40);
    } else if (again < 7625) {      //again<7.44x
        ana_gain = 0x23;
        ana_fine_gain = CALC_AGAIN_FINE_GAIN(again, 7625, 3813, 0x80, 0x40);
    } else if (again < 15250) {     //again<14.89x
        ana_gain = 0x27;
        ana_fine_gain = CALC_AGAIN_FINE_GAIN(again, 15250, 7625, 0x80, 0x40);
    } else if (again < 30500) {     //again<29.78x
        ana_gain = 0x2f;
        ana_fine_gain = CALC_AGAIN_FINE_GAIN(again, 30500, 15250, 0x80, 0x40);
    } else if (again < 60999) {     //again<59.57x
        ana_gain = 0x3f;
        ana_fine_gain = CALC_AGAIN_FINE_GAIN(again, 60999, 30500, 0x80, 0x40);
    } else {                        //again>=59.57x
        ana_gain = 0x3f;
        ana_fine_gain = 0x7f;
    }

    ak_sensor_write(arg, 0x3e08,ana_gain);        //ANA GAIN    AGAIN_REG 0x3e08
    if(ana_fine_gain > 0x7f)
        ana_fine_gain = 0x7f;
    ak_sensor_write(arg, 0x3e09,ana_fine_gain);        //DIG GAIN   A_FINE_GAIN_REG 0x3e09

    return A_GAIN_EFFECT_FRAMES;
}

/*set sensor dgain*/
/*max gain: 4000 (15.625 times)*/
static int sc450ai_sen_update_d_gain_func(
    void* arg, const unsigned int d_gain)
{
    struct ak_sensor_priv* priv = arg;
    unsigned int dgain = d_gain * 1000 / 256;       //*4
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int range = 0;
    range = 0x100 - 0x80;

    //gain = 256 * GAIN Value
    //dgain = 1000 * GAIN Value
    if (dgain < 1000) {             //dgain<1x
        dig_gain = 0x00;
        dig_fine_gain = 0x80;
    } else if (dgain < 2000) {      //dgain<1.95x
        dig_gain = 0x00;
        dig_fine_gain = (dgain - 1000) * range / (2000 - 1000) + 0x80;
    } else if (dgain < 4000) {      //dgain<3.9x
        dig_gain = 0x01;
        dig_fine_gain = (dgain - 2000) * range / (4000 - 2000) + 0x80;
    } else if (dgain < 8000) {      //dgain<7.81x
        dig_gain = 0x03;
        dig_fine_gain = (dgain - 4000) * range / (8000 - 4000) + 0x80;
    } else if (dgain < 16000) {     //dgain<15.63
        dig_gain = 0x07;
        dig_fine_gain = (dgain - 8000) * range / (16000 - 8000) + 0x80;
    } else {                        //dgain>=15.63
        dig_gain = 0x07;
        dig_fine_gain = 0xfe;
    }

    dig_fine_gain = dig_fine_gain & 0xfe;
    ak_sensor_write(arg, 0x3e06, dig_gain);     //DGAIN_REG 0x3e06
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);   //D_FINE_GAIN_REG 0x3e07

    return D_GAIN_EFFECT_FRAMES;
}

static AK_ISP_SENSOR_CB sc450ai_cb = {
    .sensor_init_func = sc450ai_sensor_init_func,

    .sensor_update_a_gain_func = sc450ai_sen_update_a_gain_func,
    .sensor_update_d_gain_func = sc450ai_sen_update_d_gain_func,
    .sensor_updata_exp_time_func = sc_sensor_updata_exp_time_func,
    .sensor_set_standby_in_func = sc_sensor_set_standby_in_func,
    .sensor_set_fps_func = sc_sensor_set_fps_func,
};
#endif

/* ------------------------sc450ai sensor callback end-----------------------*/

/* ------------------------sc3332 sensor callback---------------------------*/
#ifdef SC3332
static AK_ISP_SENSOR_CB sc3332_cb;

static void smartsen_parms_init_f(struct ak_sensor_priv *priv, AK_ISP_SENSOR_INIT_PARA* para)
{
    struct sensor_info *sns_info = priv->sensor_info;
    AK_ISP_SENSOR_REG_INFO* preg_info;
    int vts_h_tmp = 0x5, vts_l_tmp = 0x0050;
    int i = 0;

    preg_info = para->reg_info;
    for (i = 0; i < para->num; i++) {
        if (preg_info->reg_addr == 0x320e)
            vts_h_tmp = preg_info->value;
        else if (preg_info->reg_addr == 0x320f)
            vts_l_tmp = preg_info->value;

        preg_info++;
    }

    priv->aec_parms.calc_vts_tmp = (vts_h_tmp << 8 | vts_l_tmp) * sns_info->max_fps[priv->reg_list_no] * 100;
    pr_err("calc_vts_tmp %d \n", priv->aec_parms.calc_vts_tmp);
}

static int sc3332_sensor_init_func(void *arg, const AK_ISP_SENSOR_INIT_PARA *npara)
{
    int i;
    int value;
    AK_ISP_SENSOR_REG_INFO *preg_info;
    struct ak_sensor_priv *priv = arg;
    struct sensor_info *info = priv->sensor_info;
    struct smartsen_attr *sc_attr = container_of(priv, struct smartsen_attr, priv);
    AK_ISP_SENSOR_INIT_PARA *para = &priv->para;
    AK_ISP_SENSOR_CB *sensor_cb = priv->cb_info.cb;
    AK_ISP_SENSOR_INIT_PARA para1;
    int sensor_last_state = priv->state;

    sensor_info("%s sensor_mode %s\n", __func__,
        (priv->master_or_slave == MASTER_MODE) ? "MASTER" : "SLAVER");

    if (priv->master_or_slave == MASTER_MODE) {
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)sc3332_1152x648_50fps;
            para->num = sizeof(sc3332_1152x648_50fps)
                / sizeof(sc3332_1152x648_50fps[0]) / 2;
        }
        else
        {
            if (npara) {
                para = (void*)npara;
                preg_info = para->reg_info;
            }
//            else {
//                preg_info = (void*)sc3332_2304x1296_30fps;
//                para->num = sizeof(sc3332_2304x1296_30fps)
//                    / sizeof(sc3332_2304x1296_30fps[0]) / 2;
//            }
        }
    } else if (priv->master_or_slave == SLAVER_MODE) {
        sensor_err("[%s]%dSLAVER mode not support\n", __func__, __LINE__);
    } else {
        if (para->num <= 0 && npara)
            para = (void*)npara;

        preg_info = para->reg_info;
    }
    sensor_info("reg_list_no:%d,para_num:%d,to_fps:%d,max_fps:%d,last_state:%d\n", priv->reg_list_no, para->num,
                                                priv->fps_info.to_fps, info->max_fps[priv->reg_list_no], sensor_last_state);

    if(preg_info == NULL){
        sensor_err("preg_info == NULL\n");
        return -1;
    }

    priv->state = SNS_STATE_INIT;
    para1.num = para->num;
    para1.reg_info = preg_info;
    smartsen_parms_init_f(priv, &para1);
    if (priv->fps_info.to_fps == 0)
        priv->fps_info.to_fps = info->max_fps[priv->reg_list_no];
    for (i = 0; i < para->num; i++) {

        if((preg_info->reg_addr == 0x100) && (preg_info->value == 1)){

            sensor_cb->sensor_set_fps_func(priv, priv->fps_info.to_fps);

            sensor_cb->sensor_updata_exp_time_func(priv, priv->aec_parms.target_exp);

            priv->fps_info.current_fps = priv->fps_info.to_fps;//TODO

            sensor_cb->sensor_update_a_gain_func(priv, priv->aec_parms.target_a_gain);

            sensor_cb->sensor_update_d_gain_func(priv, priv->aec_parms.target_d_gain);

            sc_set_flip_mirror(priv->sd, &priv->flip_mirror);

            pr_err("init fps_exp_again:%d-%d-%d\r\n", priv->fps_info.to_fps,
                                                        priv->aec_parms.target_exp,
                                                        priv->aec_parms.target_a_gain);

            if (sensor_last_state == SNS_STATE_WORK) {
                //小窗切大窗, AV130不采大窗, 不开启码流
                sensor_info("switch big windows\n");
                break;
            }
        }

        ak_sensor_write(arg, preg_info->reg_addr, preg_info->value);
        preg_info++;
    }

    // sc200ai_agc_mode
    value = ak_sensor_read(arg, 0x3e03) & 0xf0; //AGC_CTRL 0x3e03
    value |= 0xb; //AGC_CTRL[3:0] set to 0xb
    ak_sensor_write(arg, 0x3e03, value);

    priv->state = SNS_STATE_WORK;

    return 0;
}
/* end of func sc200ai_sensor_init_func */

static int sc3332_sensor_update_a_gain_func(void *arg, const unsigned int a_gain)
{
    /*
     * max again < 25 times = 8192
     * */
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const gain = a_gain * 1000 / 256;
    int ana_gain = 0x00;
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int x = 0, range = 0;
    x = gain / 1000;
    range = 0x100 - 0x80;           //v1.0.04修改

    if (gain < 1000) {

        ana_gain = 0x00;
        dig_gain = 0x00;
        dig_fine_gain = 0x80;

    } else if (gain < 2000) {

        ana_gain = 0x00;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 1000) * range / (2000 - 1000) + 0x80;

    } else if (gain < 4000) {

        ana_gain = 0x08;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 2000) * range / (4000 - 2000) + 0x80;

    } else if (gain < 8000) {

        ana_gain = 0x09;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 4000) * range / (8000 - 4000) + 0x80;

    } else if (gain < 16000) {

        ana_gain = 0x0b;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 8000) * range / (16000 - 8000) + 0x80;

    } else if (gain < 32000) {

        ana_gain = 0x0f;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 16000) * range / (32000 - 16000) + 0x80;

    } else {

        ana_gain = 0x1f;
        dig_gain = 0x00;
        dig_fine_gain = 0x80;
    }

    ak_sensor_write(arg, 0x3e09, ana_gain);
    dig_fine_gain = dig_fine_gain & 0xfc;
    ak_sensor_write(arg, 0x3e06, dig_gain);
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);

    return A_GAIN_EFFECT_FRAMES;   //A_GAIN_EFFECT_FRAMES 1 adjust a_gain for 1/2 frames
}

static int sc3332_sensor_update_d_gain_func(void *arg, const unsigned int d_gain)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const gain = d_gain * 1000 / 256;
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int x = 0, range = 0;
    x = gain / 1000;
    range = 0xfc - 0x80;

    if (x < 1) {

        dig_gain = 0x00;
        dig_fine_gain = 0x80;

    } else if (x < 2) {

        dig_gain = 0x00;
        dig_fine_gain = (gain - 1000) * range / (1969 - 1000) + 0x80;

    } else if (x < 4) {

        dig_gain = 0x01;
        dig_fine_gain = (gain - 2000) * range / (3938 - 2000) + 0x80;

    } else if (x < 8) {

        dig_gain = 0x03;
        dig_fine_gain = (gain - 4000) * range / (7875 - 4000) + 0x80;

    } else if (x < 16) {

        dig_gain = 0x07;
        dig_fine_gain = (gain - 8000) * range / (15750 - 8000) + 0x80;

    } else {

        dig_gain = 0x07;
        dig_fine_gain = 0xfc;
    }

    dig_fine_gain = dig_fine_gain & 0xfc;
    // pr_err("set dgian dig_gain:0x%x\n", dig_gain);
    // pr_err("set dgian dig_fine_gain:0x%x\n", dig_fine_gain);
    ak_sensor_write(arg, 0x3e06, dig_gain);
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);

    return D_GAIN_EFFECT_FRAMES;    //D_GAIN_EFFECT_FRAMES 1 adjust d_gain for 1/2 frames
}

static AK_ISP_SENSOR_CB sc3332_cb = {
    .sensor_init_func = sc3332_sensor_init_func,

    .sensor_update_a_gain_func = sc3332_sensor_update_a_gain_func,
    .sensor_update_d_gain_func = sc3332_sensor_update_d_gain_func,
    .sensor_updata_exp_time_func = sc_sensor_updata_exp_time_func,
    .sensor_set_standby_in_func = sc_sensor_set_standby_in_func,
    .sensor_set_fps_func = sc_sensor_set_fps_func,
};


#define SC3332_SENSOR_INFO {   \
    .sensor_pwdn_level              = 0,    \
    .sensor_reset_level             = 0,    \
    .sensor_i2c_addr                = {0x30, 0x32}, \
    .sensor_cb                      = &sc3332_cb,  \
    .regaddr_byte                   = 2,    \
    .data_byte                      = 1,    \
    .max_fps                        = {25, 50},   \
    .max_exp                        = {2712/2, 674},   \
    .max_again_x                    = 32,   \
    .max_dgain_x                    = 16,   \
    .id_reg_h                       = 0x3107,   \
    .id_reg_l                       = 0x3108,   \
    .id_reg_b                       = 0x801b,   \
    .id_reg_byte                    = 3,   \
    .actual_sensor_id               = 0xcc44,   \
    .sensor_id                      = 0x3332,   \
    .sensor_output_width            = {2304, 1152}, \
    .sensor_output_height           = {1296, 648}, \
    .sensor_mclk                    = 24,   \
    .sensor_valid_offset_x          = {0,0},    \
    .sensor_valid_offset_y          = {0,0},    \
    .sensor_io_level                = IO_LEVEL_1V8, \
    .sensor_dual_sync_mode          = DUAL_SYNC_PWM_FREQ_FIXED, \
    .exp_unit                       = 1, \
    .raw_format                     = 3,    \
    .mipi_lanes_swap                = 0x435A1,  \
    .mipi_lanes                     = 2,    \
    .sensor_bus_type                = BUS_TYPE_RAW, \
    .struct_size                    = sizeof(struct smartsen_attr),   \
    .ops                            = &sc_sensor_ops,   \
}

#endif
/* ------------------------sc3332 sensor callback end-----------------------*/

/* ------------------------sc2337p sensor callback---------------------------*/
#ifdef SC2337P
static AK_ISP_SENSOR_CB sc2337p_cb;

static void sc2337p_parms_init_f(struct ak_sensor_priv *priv, AK_ISP_SENSOR_INIT_PARA* para)
{
    struct sensor_info *sns_info = priv->sensor_info;
    AK_ISP_SENSOR_REG_INFO* preg_info;
    int vts_h_tmp = 0x4, vts_l_tmp = 0x0070;
    int i = 0;

    preg_info = para->reg_info;
    for (i = 0; i < para->num; i++) {
        if (preg_info->reg_addr == 0x320e)
            vts_h_tmp = preg_info->value;
        else if (preg_info->reg_addr == 0x320f)
            vts_l_tmp = preg_info->value;

        preg_info++;
    }
//    vts_h_tmp = 0x02;
//    vts_l_tmp = 0x58;

    priv->aec_parms.calc_vts_tmp = (vts_h_tmp << 8 | vts_l_tmp) * sns_info->max_fps[priv->reg_list_no] * 100;
    pr_err("calc_vts_tmp %d \n", priv->aec_parms.calc_vts_tmp);
}

static int sc2337p_sensor_init_func(void *arg, const AK_ISP_SENSOR_INIT_PARA *npara)
{
    int i;
    int value;
    AK_ISP_SENSOR_REG_INFO *preg_info;
    struct ak_sensor_priv *priv = arg;
    struct sensor_info *info = priv->sensor_info;
    struct smartsen_attr *sc_attr = container_of(priv, struct smartsen_attr, priv);
    AK_ISP_SENSOR_INIT_PARA *para = &priv->para;
    AK_ISP_SENSOR_CB *sensor_cb = priv->cb_info.cb;
    AK_ISP_SENSOR_INIT_PARA para1;
    int sensor_last_state = priv->state;

    sensor_info("%s sensor_mode %s\n", __func__,
        (priv->master_or_slave == MASTER_MODE) ? "MASTER" : "SLAVER");

    if (priv->master_or_slave == MASTER_MODE) {
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)sc2337p_960x540_60fps;
            para->num = sizeof(sc2337p_960x540_60fps)
                / sizeof(sc2337p_960x540_60fps[0]) / 2;
        }
        else
        {
            if (npara) {
                para = (void*)npara;
                preg_info = para->reg_info;
            }
//            else {
//                preg_info = (void*)sc2337p_1920x1080_30fps;
//                para->num = sizeof(sc2337p_1920x1080_30fps)
//                    / sizeof(sc2337p_1920x1080_30fps[0]) / 2;
//            }
        }
    } else if (priv->master_or_slave == SLAVER_MODE) {
        if(priv->reg_list_no == 1) {
            preg_info = (void*)sc2337p_slave_960x540_60fps;
            para->num = sizeof(sc2337p_slave_960x540_60fps)
                / sizeof(sc2337p_slave_960x540_60fps[0]) / 2;
        } else {
            if (npara) {
                para = (void*)npara;
                preg_info = para->reg_info;
            }
//            preg_info = (void*)sc2337p_1920x1080_30fps;
//            para->num = sizeof(sc2337p_1920x1080_30fps)
//                / sizeof(sc2337p_1920x1080_30fps[0]) / 2;
        }
    } else {
        if (para->num <= 0 && npara)
            para = (void*)npara;

        preg_info = para->reg_info;
    }
    sensor_info("reg_list_no:%d,para_num:%d,to_fps:%d,max_fps:%d,last_state:%d\n", priv->reg_list_no, para->num,
                                                priv->fps_info.to_fps, info->max_fps[priv->reg_list_no], sensor_last_state);

    if(preg_info == NULL){
        sensor_err("preg_info == NULL\n");
        return -1;
    }

    priv->state = SNS_STATE_INIT;
    para1.num = para->num;
    para1.reg_info = preg_info;
    sc2337p_parms_init_f(priv, &para1);
    if (priv->fps_info.to_fps == 0)
        priv->fps_info.to_fps = info->max_fps[priv->reg_list_no];
    for (i = 0; i < para->num; i++) {

        if((preg_info->reg_addr == 0x100) && (preg_info->value == 1)){

            sensor_cb->sensor_set_fps_func(priv, priv->fps_info.to_fps);

            sensor_cb->sensor_updata_exp_time_func(priv, priv->aec_parms.target_exp);

            priv->fps_info.current_fps = priv->fps_info.to_fps;//TODO

            sensor_cb->sensor_update_a_gain_func(priv, priv->aec_parms.target_a_gain);

            sensor_cb->sensor_update_d_gain_func(priv, priv->aec_parms.target_d_gain);

            sc_set_flip_mirror(priv->sd, &priv->flip_mirror);

            pr_err("init fps_exp_again:%d-%d-%d\r\n", priv->fps_info.to_fps,
                                                        priv->aec_parms.target_exp,
                                                        priv->aec_parms.target_a_gain);

            if (sensor_last_state == SNS_STATE_WORK) {
                //小窗切大窗, AV130不采大窗, 不开启码流
                sensor_info("switch big windows\n");
                break;
            }
        }

        ak_sensor_write(arg, preg_info->reg_addr, preg_info->value);
        preg_info++;
    }

    // sc200ai_agc_mode
    value = ak_sensor_read(arg, 0x3e03) & 0xf0; //AGC_CTRL 0x3e03
    value |= 0xb; //AGC_CTRL[3:0] set to 0xb
    ak_sensor_write(arg, 0x3e03, value);

    priv->state = SNS_STATE_WORK;

    return 0;
}
/* end of func sc2337p_sensor_init_func */

static int sc2337p_sensor_update_a_gain_func(void *arg, const unsigned int a_gain)
{
    /*
     * max again < 25 times = 8192
     * */
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const gain = a_gain * 1000 / 256;
    int ana_gain = 0x00;
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int x = 0, range = 0;
    x = gain / 1000;
    range = 0x100 - 0x80;           //v1.0.04修改

    if (gain < 1000) {
        ana_gain = 0x00;
        dig_gain = 0x00;
        dig_fine_gain = 0x80;
    } else if (gain < 2000) {
        ana_gain = 0x00;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 1000) * range / (2000 - 1000) + 0x80;
    } else if (gain < 4000) {
        ana_gain = 0x08;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 2000) * range / (4000 - 2000) + 0x80;
    } else if (gain < 8000) {
        ana_gain = 0x09;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 4000) * range / (8000 - 4000) + 0x80;
    } else if (gain < 16000) {
        ana_gain = 0x0b;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 8000) * range / (16000 - 8000) + 0x80;
    } else if (gain < 32000) {
        ana_gain = 0x0f;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 16000) * range / (32000 - 16000) + 0x80;

    } else if (gain < 64000) {

        ana_gain = 0x1f;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 32000) * range / (64000 - 32000) + 0x80;

    } else if (gain < 128000) {

        ana_gain = 0x1f;
        dig_gain = 0x01;
        dig_fine_gain = (gain - 64000) * range / (128000 - 64000) + 0x80;

    } else {
        ana_gain = 0x1f;
        dig_gain = 0x03;
        dig_fine_gain = 0x80;
    }

    dig_fine_gain = dig_fine_gain & 0xfc;
    ak_sensor_write(arg, 0x3e09, ana_gain);
    ak_sensor_write(arg, 0x3e06, dig_gain);
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);

    return A_GAIN_EFFECT_FRAMES;   //A_GAIN_EFFECT_FRAMES 1 adjust a_gain for 1/2 frames
}

static int sc2337p_sensor_update_d_gain_func(void *arg, const unsigned int d_gain)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

//    int const gain = d_gain * 1000 / 256;
//    int dig_gain = 0x00;
//    int dig_fine_gain = 0x80;
//    int x = 0, range = 0;
//    x = gain / 1000;
//    range = 0xfc - 0x80;

    unsigned int dgain = d_gain * 1000 / 256;       //*4
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int range = 0;
    range = 0x100 - 0x80;

    if (dgain < 1000) {             //dgain<1x
        dig_gain = 0x00;
        dig_fine_gain = 0x80;
    } else if (dgain < 2000) {      //dgain<2x
        dig_gain = 0x00;
        dig_fine_gain = (dgain - 1000) * range / (2000 - 1000) + 0x80;
    } else if (dgain < 4000) {      //dgain<4x
        dig_gain = 0x01;
        dig_fine_gain = (dgain - 2000) * range / (4000 - 2000) + 0x80;
    } else {
        dig_gain = 0x03;
        dig_fine_gain = 0x80;
    }

    dig_fine_gain = dig_fine_gain & 0xfc;
    // pr_err("set dgian dig_gain:0x%x\n", dig_gain);
    // pr_err("set dgian dig_fine_gain:0x%x\n", dig_fine_gain);
    ak_sensor_write(arg, 0x3e06, dig_gain);
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);

    return D_GAIN_EFFECT_FRAMES;    //D_GAIN_EFFECT_FRAMES 1 adjust d_gain for 1/2 frames
}

static AK_ISP_SENSOR_CB sc2337p_cb = {
    .sensor_init_func = sc2337p_sensor_init_func,

    .sensor_update_a_gain_func = sc2337p_sensor_update_a_gain_func,
    .sensor_update_d_gain_func = sc2337p_sensor_update_d_gain_func,
    .sensor_updata_exp_time_func = sc_sensor_updata_exp_time_func,
    .sensor_set_standby_in_func = sc_sensor_set_standby_in_func,
    .sensor_set_fps_func = sc_sensor_set_fps_func,
};


#define SC2337P_SENSOR_INFO {   \
    .sensor_pwdn_level              = 0,    \
    .sensor_reset_level             = 0,    \
    .sensor_i2c_addr                = {0x30, 0x32}, \
    .sensor_cb                      = &sc2337p_cb,  \
    .regaddr_byte                   = 2,    \
    .data_byte                      = 1,    \
    .max_fps                        = {30, 60},   \
    .max_exp                        = {1130, 590},   \
    .max_again_x                    = 32,   \
    .max_dgain_x                    = 4,   \
    .id_reg_h                       = 0x3107,   \
    .id_reg_l                       = 0x3108,   \
    .actual_sensor_id               = 0xcb3a,   \
    .sensor_id                      = 0x23370f,   \
    .sensor_output_width            = {1920, 960}, \
    .sensor_output_height           = {1080, 540}, \
    .sensor_mclk                    = 24,   \
    .sensor_valid_offset_x          = {0,0},    \
    .sensor_valid_offset_y          = {0,0},    \
    .sensor_io_level                = IO_LEVEL_1V8, \
    .sensor_dual_sync_mode          = DUAL_SYNC_BY_EFSYNC, \
    .exp_unit                       = 1, \
    .raw_format                     = 3,    \
    .mipi_lanes_swap                = 0x435A1,  \
    .mipi_lanes                     = 2,    \
    .sensor_bus_type                = BUS_TYPE_RAW, \
    .struct_size                    = sizeof(struct smartsen_attr),   \
    .ops                            = &sc_sensor_ops,   \
}

#endif
/* ------------------------sc2337p sensor callback end-----------------------*/

/* ------------------------sc3332p sensor callback---------------------------*/
#ifdef SC3332P
static AK_ISP_SENSOR_CB sc3332p_cb;

static void sc3332p_parms_init_f(struct ak_sensor_priv *priv, AK_ISP_SENSOR_INIT_PARA* para)
{
    struct sensor_info *sns_info = priv->sensor_info;
    AK_ISP_SENSOR_REG_INFO* preg_info;
    int vts_h_tmp = 0x5, vts_l_tmp = 0x0028;
    int i = 0;

    preg_info = para->reg_info;
    for (i = 0; i < para->num; i++) {
        if (preg_info->reg_addr == 0x320e)
            vts_h_tmp = preg_info->value;
        else if (preg_info->reg_addr == 0x320f)
            vts_l_tmp = preg_info->value;

        preg_info++;
    }

    priv->aec_parms.calc_vts_tmp = (vts_h_tmp << 8 | vts_l_tmp) * sns_info->max_fps[priv->reg_list_no] * 100;
    pr_err("calc_vts_tmp %d \n", priv->aec_parms.calc_vts_tmp);
}

static int sc3332p_sensor_init_func(void *arg, const AK_ISP_SENSOR_INIT_PARA *npara)
{
    int i;
    int value;
    AK_ISP_SENSOR_REG_INFO *preg_info;
    struct ak_sensor_priv *priv = arg;
    struct sensor_info *info = priv->sensor_info;
    struct smartsen_attr *sc_attr = container_of(priv, struct smartsen_attr, priv);
    AK_ISP_SENSOR_INIT_PARA *para = &priv->para;
    AK_ISP_SENSOR_CB *sensor_cb = priv->cb_info.cb;
    AK_ISP_SENSOR_INIT_PARA para1;
    int sensor_last_state = priv->state;

    sensor_info("%s sensor_mode %s\n", __func__,
        (priv->master_or_slave == MASTER_MODE) ? "MASTER" : "SLAVER");

    if (priv->master_or_slave == MASTER_MODE) {
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)sc3332p_1152x648_60fps_0x09;
            para->num = sizeof(sc3332p_1152x648_60fps_0x09)
                / sizeof(sc3332p_1152x648_60fps_0x09[0]) / 2;
        }
        else
        {
            if (npara) {
                para = (void*)npara;
                preg_info = para->reg_info;
            }
//            else {
//                preg_info = (void*)sc3332p_2304x1296_30fps;
//                para->num = sizeof(sc3332p_2304x1296_30fps)
//                    / sizeof(sc3332p_2304x1296_30fps[0]) / 2;
//            }
        }
    } else if (priv->master_or_slave == SLAVER_MODE) {
        sensor_err("[%s]%dSLAVER mode not support\n", __func__, __LINE__);
    } else {
        if (para->num <= 0 && npara)
            para = (void*)npara;

        preg_info = para->reg_info;
    }
    sensor_info("reg_list_no:%d,para_num:%d,to_fps:%d,max_fps:%d,last_state:%d\n", priv->reg_list_no, para->num,
                                                priv->fps_info.to_fps, info->max_fps[priv->reg_list_no], sensor_last_state);

    if(preg_info == NULL){
        sensor_err("preg_info == NULL\n");
        return -1;
    }

    priv->state = SNS_STATE_INIT;
    para1.num = para->num;
    para1.reg_info = preg_info;
    sc3332p_parms_init_f(priv, &para1);
    if (priv->fps_info.to_fps == 0)
        priv->fps_info.to_fps = info->max_fps[priv->reg_list_no];
    for (i = 0; i < para->num; i++) {

        if((preg_info->reg_addr == 0x100) && (preg_info->value == 1)){

            sensor_cb->sensor_set_fps_func(priv, priv->fps_info.to_fps);

            sensor_cb->sensor_updata_exp_time_func(priv, priv->aec_parms.target_exp);

            priv->fps_info.current_fps = priv->fps_info.to_fps;//TODO

            sensor_cb->sensor_update_a_gain_func(priv, priv->aec_parms.target_a_gain);

            sensor_cb->sensor_update_d_gain_func(priv, priv->aec_parms.target_d_gain);

            sc_set_flip_mirror(priv->sd, &priv->flip_mirror);

            pr_err("init fps_exp_again:%d-%d-%d\r\n", priv->fps_info.to_fps,
                                                        priv->aec_parms.target_exp,
                                                        priv->aec_parms.target_a_gain);

            if (sensor_last_state == SNS_STATE_WORK) {
                //小窗切大窗, AV130不采大窗, 不开启码流
                sensor_info("switch big windows\n");
                break;
            }
        }

        ak_sensor_write(arg, preg_info->reg_addr, preg_info->value);

        #if 0
        {
            int value;

            value = ak_sensor_read(arg, preg_info->reg_addr);
            pr_err("reg:%x write value:%x, read back value:%x\n",
                    preg_info->reg_addr, preg_info->value, value);
        }
        #endif

        preg_info++;
    }

    // sc200ai_agc_mode
    value = ak_sensor_read(arg, 0x3e03) & 0xf0; //AGC_CTRL 0x3e03
    value |= 0xb; //AGC_CTRL[3:0] set to 0xb
    ak_sensor_write(arg, 0x3e03, value);

    priv->state = SNS_STATE_WORK;

    return 0;
}
/* end of func sc200ai_sensor_init_func */

static int sc3332p_sensor_update_a_gain_func(void *arg, const unsigned int a_gain)
{
    /*
     * max again < 25 times = 8192
     * */
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const gain = a_gain * 1000 / 256;
    int ana_gain = 0x00;
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int x = 0, range = 0;
    x = gain / 1000;
    range = 0x100 - 0x80;

    if (gain < 1000) {

        ana_gain = 0x00;
        dig_gain = 0x00;
        dig_fine_gain = 0x80;

    } else if (gain < 2000) {

        ana_gain = 0x00;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 1000) * range / (2000 - 1000) + 0x80;

    } else if (gain < 4000) {

        ana_gain = 0x08;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 2000) * range / (4000 - 2000) + 0x80;

    } else if (gain < 8000) {

        ana_gain = 0x09;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 4000) * range / (8000 - 4000) + 0x80;

    } else if (gain < 16000) {

        ana_gain = 0x0b;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 8000) * range / (16000 - 8000) + 0x80;

    } else if (gain < 32000) {

        ana_gain = 0x0f;
        dig_gain = 0x00;
        dig_fine_gain = (gain - 16000) * range / (32000 - 16000) + 0x80;

    } else {

        ana_gain = 0x1f;
        dig_gain = 0x00;
        dig_fine_gain = 0x80;
    }

    ak_sensor_write(arg, 0x3e09, ana_gain);
    dig_fine_gain = dig_fine_gain & 0xfc;
    ak_sensor_write(arg, 0x3e06, dig_gain);
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);

    return A_GAIN_EFFECT_FRAMES;   //A_GAIN_EFFECT_FRAMES 1 adjust a_gain for 1/2 frames
}

static int sc3332p_sensor_update_d_gain_func(void *arg, const unsigned int d_gain)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    int const dgain = d_gain * 1000 / 256;
    int dig_gain = 0x00;
    int dig_fine_gain = 0x80;
    int x = 0, range = 0;
    x = dgain / 1000;
    range = 0x100 - 0x80;

    if((priv->aec_parms.target_a_gain / 256) < 16) {
        return 0;
    }

    if (x < 1) {

        dig_gain = 0x00;
        dig_fine_gain = 0x80;

    } else if (x < 2) {

        dig_gain = 0x00;
        dig_fine_gain = (dgain - 1000) * range / (2000 - 1000) + 0x80;

    } else if (x < 4) {

        dig_gain = 0x01;
        dig_fine_gain = (dgain - 2000) * range / (4000 - 2000) + 0x80;

    } else if (x < 8) {

        dig_gain = 0x03;
        dig_fine_gain = (dgain - 4000) * range / (8000 - 4000) + 0x80;

    } else if (x < 16) {

        dig_gain = 0x07;
        dig_fine_gain = (dgain - 8000) * range / (16000 - 8000) + 0x80;

    } else {

        dig_gain = 0x07;
        dig_fine_gain = 0xfc;
    }

    dig_fine_gain = dig_fine_gain & 0xfc;
    // pr_err("set dgian dig_gain:0x%x\n", dig_gain);
    // pr_err("set dgian dig_fine_gain:0x%x\n", dig_fine_gain);
    ak_sensor_write(arg, 0x3e06, dig_gain);
    ak_sensor_write(arg, 0x3e07, dig_fine_gain);

    return D_GAIN_EFFECT_FRAMES;    //D_GAIN_EFFECT_FRAMES 1 adjust d_gain for 1/2 frames
}

static AK_ISP_SENSOR_CB sc3332p_cb = {
    .sensor_init_func = sc3332p_sensor_init_func,

    .sensor_update_a_gain_func = sc3332p_sensor_update_a_gain_func,
    .sensor_update_d_gain_func = sc3332p_sensor_update_d_gain_func,
    .sensor_updata_exp_time_func = sc_sensor_updata_exp_time_func,
    .sensor_set_standby_in_func = sc_sensor_set_standby_in_func,
    .sensor_set_fps_func = sc_sensor_set_fps_func,
};


#define SC3332P_SENSOR_INFO {   \
    .sensor_pwdn_level              = 0,    \
    .sensor_reset_level             = 0,    \
    .sensor_i2c_addr                = {0x30, 0x32}, \
    .sensor_cb                      = &sc3332p_cb,  \
    .regaddr_byte                   = 2,    \
    .data_byte                      = 1,    \
    .max_fps                        = {30, 60},   \
    .max_exp                        = {1320, 680},   \
    .max_again_x                    = 32,   \
    .max_dgain_x                    = 16,   \
    .id_reg_h                       = 0x3107,   \
    .id_reg_l                       = 0x3108,   \
    .id_reg_b                       = 0x801b,   \
    .id_reg_byte                    = 3,   \
    .actual_sensor_id               = 0x0fcc44,   \
    .sensor_id                      = 0x33320f,   \
    .sensor_output_width            = {2304, 1152}, \
    .sensor_output_height           = {1296, 648}, \
    .sensor_mclk                    = 24,   \
    .sensor_valid_offset_x          = {0,0},    \
    .sensor_valid_offset_y          = {0,0},    \
    .sensor_io_level                = IO_LEVEL_1V8, \
    .sensor_dual_sync_mode          = DUAL_SYNC_PWM_FREQ_FIXED, \
    .exp_unit                       = 1, \
    .raw_format                     = 3,    \
    .mipi_lanes_swap                = 0x435A1,  \
    .mipi_lanes                     = 2,    \
    .sensor_bus_type                = BUS_TYPE_RAW, \
    .struct_size                    = sizeof(struct smartsen_attr),   \
    .ops                            = &sc_sensor_ops,   \
}

#endif
/* ------------------------sc3332p sensor callback end-----------------------*/

struct sensor_info sc_sensor_info_table[] = {
    #ifdef SC200AI
    SC200AI_SENSOR_INFO,
    #endif

    #ifdef SC450AI
    SC450AI_SENSOR_INFO,
    #endif

    #ifdef SC3332
    SC3332_SENSOR_INFO,
    #endif

    #ifdef SC2337P
    SC2337P_SENSOR_INFO,
    #endif

    #ifdef SC3332P
    SC3332P_SENSOR_INFO,
    #endif
};

int sc_sensor_info_table_count = sizeof(sc_sensor_info_table) / sizeof(sc_sensor_info_table[0]);

/*end of file*/
