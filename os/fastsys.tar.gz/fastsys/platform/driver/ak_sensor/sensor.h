#ifndef __SENSOR_H__
#define __SENSOR_H__

#include "types.h"
#include "ak_types.h"
#include "list.h"
#include "cmsis_os2.h"
#if defined(CONFIG_MACH_AK3918AV200)
#include "video2sensor.h"
#endif
#if defined(CONFIG_MACH_AK3918AV130)
#include "ak_video_priv_cmd.h"
#include "ak_video_priv_cmd_internal.h"
#include "mach/av130/ak_isp_drv.h"
#endif
#include "ak_sensor.h"
#include "stdio.h"
#include "ak_print.h"

#define sensor_err(str, arg...) \
    printf("[sensor] err " str, ##arg)
#define sensor_dbg(str, arg...) \
    printf("[sensor] dbg " str, ##arg)
#define sensor_info(str, arg...) \
    printf("[sensor] info " str, ##arg)

//#define sensor_container_of(ptr, type, member) \
//    ((type *)((char *)(ptr) - (unsigned long)(&((type *)0)->member)))

#if defined(CONFIG_MACH_AK3918AV200)
enum sensor_bus_type { BUS_TYPE_RAW, BUS_TYPE_YUV, BUS_TYPE_NUM };
#endif
enum sensor_master_or_slave_mode {
    SINGLE_MODE = 0,
    MASTER_MODE,
    SLAVER_MODE,
};

#define SENSOR_ADDR_NUM             2
#define SENSOR_REG_LIST_NUM         2
/*
 * store sensor fps informations
 * @current_fps: current fps
 * @to_fps: should changed to the fps
 * @to_fps_value: the fps paramter
 */
struct sensor_fps_info {
    int current_fps;
    int to_fps;
    int to_fps_value;
    int reg_fps_value;
};

struct sensor_aec_parms {
    int calc_vts_tmp;
    int target_exp;
    int target_a_gain;
    int target_d_gain;
};

////TODO: 适配双目及框架修改
struct sensor_info {
    //i2c
    uint8_t                regaddr_byte;
    uint8_t                data_byte;
    uint16_t               sensor_i2c_addr[SENSOR_ADDR_NUM];
    uint32_t               id_reg_h;
    uint32_t               id_reg_l;
    uint32_t               id_reg_b;
    uint32_t               id_reg_byte;

    //sensor attr
    uint32_t               max_fps[SENSOR_REG_LIST_NUM];
    int32_t                max_exp[SENSOR_REG_LIST_NUM];
    int32_t                max_again_x;//以倍数为单位
    int32_t                max_dgain_x;

    uint32_t               actual_sensor_id;
    uint32_t               sensor_id;
    uint16_t               sensor_output_width[SENSOR_REG_LIST_NUM];
    uint16_t               sensor_output_height[SENSOR_REG_LIST_NUM];
    uint16_t               sensor_valid_offset_x[SENSOR_REG_LIST_NUM];
    uint16_t               sensor_valid_offset_y[SENSOR_REG_LIST_NUM];

    uint8_t                sensor_mclk;
    enum sensor_bus_type   sensor_bus_type;
    enum io_level          sensor_io_level;
    enum dual_sync_mode    sensor_dual_sync_mode;
    uint8_t                exp_unit;
    uint8_t                raw_format;
    uint8_t             dvp;

    //hw mipi
    uint16_t               mipi_mbps;
    uint16_t               mipi_lanes;
    unsigned int           mipi_lanes_swap;
    //hw gpio
    uint8_t                sensor_pwdn_level;
    uint8_t                sensor_reset_level;

    //priv size
    uint32_t            struct_size;

    //ops
    AK_ISP_SENSOR_CB    *sensor_cb;
    struct ak_sensor_ops *ops;
};

enum {
    SNS_STATE_POWER_OFF = 0,
    SNS_STATE_POWER_ON,
    SNS_STATE_INIT,
    SNS_STATE_WORK,
};

struct ak_sensor_priv {
    struct ak_sensor_subdev    *sd;//外部硬件配置参数

    struct sensor_cb_info cb_info;
    struct sensor_info* sensor_info;

    struct sensor_fps_info fps_info;
    struct sensor_aec_parms aec_parms;
    enum sensor_master_or_slave_mode master_or_slave;
    AK_ISP_SENSOR_INIT_PARA para;

    uint32_t    state;//0
    uint32_t    flip_mirror;
    uint32_t    reg_list_no;
};

int ak_sensor_read(void *arg, int reg);
int ak_sensor_write(void *arg, int reg, int value);
struct ak_sensor_ops *ak_sensor_get_com_ops(void);
AK_ISP_SENSOR_CB *ak_sensor_get_com_cbs(void);

void *common_sensor_match(struct ak_sensor_subdev *sd, struct sensor_info *sns_info);

#endif
