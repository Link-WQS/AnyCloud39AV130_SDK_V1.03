#include "ak_sensor.h"
#include "sensor.h"
#if defined(CONFIG_MACH_AK3918AV200)
#include "video2sensor.h"
#include "gpio.h"
#endif
#include "ak_time.h"

#if defined(CONFIG_MACH_AK3918AV200)
extern AK_S32 ak_vi_sensor_get_subdevs(struct ak_sensor_subdev **sds);
extern AK_S32 ak_vi_subdev_match_sensor(struct ak_sensor_subdev *sd);
#endif

#if defined(CONFIG_MACH_AK3918AV130)
struct ak_sensor_subdev *ak_camera_get_sensor_subdevs(int *cis_num);
int ak_camera_subdev_match_sensor(struct ak_sensor_subdev *ak_sd);
#endif

extern struct sensor_info sc_sensor_info_table[];
extern int sc_sensor_info_table_count;

extern struct sensor_info gc_sensor_info_table[];
extern int gc_sensor_info_table_count;


void ak_sensor_add_table(struct sensor_info *sns_info, int sns_num)
{
    struct ak_sensor_subdev *sds;
    AK_S32  sd_num;
    AK_S32 i, n;
    AK_U32  match_num = 0;
    void    *sns_priv;

#if defined(CONFIG_MACH_AK3918AV200)
    sd_num = ak_vi_sensor_get_subdevs(&sds);
#endif

#if defined(CONFIG_MACH_AK3918AV130)
    sds = ak_camera_get_sensor_subdevs(&sd_num);
#endif

    for (n = 0; n < sd_num; ++n) {
        if (sds[n].match) {
            match_num++;
        }
    }

    if (match_num == sd_num)
    {
        sensor_info("all sensor s match completed!\n");
        return;
    }

#if defined(CONFIG_MACH_AK3918AV200)
    os_msleep(4);
#endif

    for (i = 0; i < sns_num; i++) {

        for (n = 0; n < sd_num; ++n) {
            if (sds[n].match == 0) {
                sns_priv = common_sensor_match(&sds[n], &sns_info[i]);
                if (sns_priv) {
#if defined(CONFIG_MACH_AK3918AV200)
                    ak_vi_subdev_match_sensor(&sds[n]);
#endif
#if defined(CONFIG_MACH_AK3918AV130)
                    ak_camera_subdev_match_sensor(&sds[n]);
#endif
                    sensor_info("sensor match success!\n");
                    match_num++;
                }
            }
        }

        if (match_num == sd_num)
            break;
    }

    if(match_num == 0)
        sensor_err("sensor match fail!\n");
}

void ak_sensor_probe(void)
{
    ak_sensor_add_table(sc_sensor_info_table, sc_sensor_info_table_count);
    ak_sensor_add_table(gc_sensor_info_table, gc_sensor_info_table_count);
}

