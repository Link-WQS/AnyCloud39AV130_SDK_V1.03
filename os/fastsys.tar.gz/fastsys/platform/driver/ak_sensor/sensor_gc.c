#include "sensor.h"

#define EXP_EFFECT_FRAMES    1 /*adjust exp_time for 1/2 frames*/
#define A_GAIN_EFFECT_FRAMES 1 /*adjust a_gain for 1/2 frames*/
#define D_GAIN_EFFECT_FRAMES 1 /*adjust d_gain for 1/2 frames*/

#define FLIP_OFFSET     0
#define MIRROR_OFFSET   1

struct gc_common_attr
{
    struct ak_sensor_priv   priv;
};

/* ------------------------sc common function---------------------------*/

static int __get_reg_frame_vts(struct ak_sensor_priv* priv)
{
    return (ak_sensor_read(priv, 0x0340) & 0x7f) << 8
        | ak_sensor_read(priv, 0x0341);
}

static int __set_reg_frame_vts(struct ak_sensor_priv* priv, int vts)
{
    int ret = 0;
    //printf("%s, vts:%d\n", __func__, vts);

    ak_sensor_write(priv, 0x0340, (vts >> 8) & 0x7f);
    ak_sensor_write(priv, 0x0341, vts & 0xff);

    priv->fps_info.reg_fps_value = vts;

    return ret;
}

/*set sensor exp time*/
static int __set_reg_exp_time(struct ak_sensor_priv* priv, int exp_time)
{
    int ret = 0;
    struct sensor_info* info = priv->sensor_info;
    int exp_h, exp_l;

    if (exp_time < 1)
        exp_time = 1;
    if (exp_time > 65536)
        exp_time = 65536; // 2^16

    exp_l = ((exp_time)) & 0xff;
    exp_h = (exp_time >> 8) & 0xff;

    ak_sensor_write(priv, 0x0202, exp_h); //EXP_REG_E
    ak_sensor_write(priv, 0x0203, exp_l); //EXP_REG_H
    return ret;
}

static void __update_frame_vts_and_exp_ctrl(struct ak_sensor_priv* priv)
{
#if 0
    /*
     * exp_time=1 mean half line exptime
     * max exp_time = {R0x320e[6:0],R0x320f} * 2 - 8
     */
    int const cur_frame_vts = __get_reg_frame_vts(priv);
    int const target_frame_vts = priv->fps_info.to_fps_value;
    struct sensor_info* info = priv->sensor_info;
    int max_exp_ctrl = (info->exp_unit == 1) ? \
        priv->fps_info.to_fps_value - 6 : priv->fps_info.to_fps_value * 2 - 8; // Vts*2-11
    int target_exp_ctrl = 0;

    if (priv->aec_parms.target_exp <= max_exp_ctrl) {
        target_exp_ctrl = priv->aec_parms.target_exp;
    } else {
        target_exp_ctrl = max_exp_ctrl;
    }

//    pr_err("VTS = %d->%d \n", cur_frame_vts, target_frame_vts);
//    pr_err("EXP = %d/%d \n", target_exp_ctrl, priv->aec_parms.target_exp);

    if ((target_frame_vts <= 0) || (target_exp_ctrl <= 0))
        return;

    if (target_frame_vts >= cur_frame_vts) {
        if (target_frame_vts != cur_frame_vts)
            __set_reg_frame_vts(priv, target_frame_vts);
        __set_reg_exp_time(priv, target_exp_ctrl);
    } else {
        __set_reg_exp_time(priv, target_exp_ctrl);
        __set_reg_exp_time(priv, target_frame_vts);
        priv->fps_info.reg_fps_value = target_frame_vts;
    }
#endif
    /*
     * exp_time =1 mean half line exptime
     * max exp_time = {R0x0202,R0x0203} - 8
     *
     * now:
     * at max_exptime_30fps
     * = {R0x0202,R0x0203} - 8
     * = 0x465 - 8 //shaokc...update!!!
     * = 1125 -8
     * = 1117
     *
     * exp_reg_value = VTS - exp_time !
     *
     */

    int const cur_frame_vts = __get_reg_frame_vts(priv);

    int const max_exp_ctrl = cur_frame_vts - 8; // VTS - 8

    int const target_frame_vts = (priv->fps_info.to_fps_value);

    int target_exp_ctrl = (priv->aec_parms.target_exp > max_exp_ctrl) ? max_exp_ctrl : priv->aec_parms.target_exp;


    if ((target_frame_vts <= 0) || (target_exp_ctrl <= 0))
        return;

    if (target_frame_vts >= cur_frame_vts) {
        if (target_frame_vts != cur_frame_vts)
            __set_reg_frame_vts(priv, target_frame_vts);
        __set_reg_exp_time(priv, target_exp_ctrl);
    } else {
        __set_reg_exp_time(priv, target_exp_ctrl);
        __set_reg_frame_vts(priv, target_frame_vts);
    }
}

static int gc_sensor_updata_exp_time_func(void *arg, unsigned int exp_time)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info* info = priv->sensor_info;

    priv->aec_parms.target_exp = exp_time;
    if (priv->state < SNS_STATE_INIT)
        return 0;

    __update_frame_vts_and_exp_ctrl(arg);

    return EXP_EFFECT_FRAMES;   //adjust exp_time for 1/2 frames
}

static int gc_fps_to_vts(struct ak_sensor_priv* priv, const int fps)
{
    /*
     * sc431ai:
     *
     * mipi:
     * HTS=(0x320c,0x320d)*2
     * VTS=(0x320e[6:0],0x320f)
     * fps = pclk / HTS / VTS
     *
     */
    int vts;
    unsigned int fps_tmp;
    struct sensor_info* info = priv->sensor_info;

    sensor_info("%s #%d fps:%d\n", __func__, __LINE__, fps);

    switch (fps) {
        case 12:
            fps_tmp = 1250;
            break;

        case 14:
            fps_tmp = 1428;
            break;

        default:
            fps_tmp = fps * 100;
            break;
    }
    if (priv->master_or_slave == SLAVER_MODE) {
//        if (fps != MAX_FPS){
            //fps_tmp = fps_tmp * 10000 / 9974;   //  从模式时，帧率要比PWM频率快一点
//            fps_tmp = fps_tmp * 1000000 / (1000000 - fps_tmp * 3);
//        }
    }

    vts = priv->aec_parms.calc_vts_tmp / fps_tmp;

    return vts;
}

/*set sensor fps*/
static int gc_sensor_set_fps_func(void *arg, int fps)
{
    int tmp;
    struct ak_sensor_priv *priv = arg;

    tmp = gc_fps_to_vts(priv, fps);
    // pr_info("\nfps:%d to vts:%x\n",fps,tmp);
    if (tmp > 0) {
        priv->fps_info.to_fps_value = tmp;
        priv->fps_info.to_fps = fps;
    }

    return 0;
}


static int gc_set_fps_direct(struct ak_sensor_subdev *sns_obj, void *arg)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sns_obj->sns_priv);
    struct sensor_cb_info *sensor_cbi = &priv->cb_info;
    int fps = *((int *)arg);

    if (priv->state < SNS_STATE_INIT) {
        ak_sensor_get_com_cbs()->sensor_set_fps_func(sensor_cbi->arg, fps);
        return 0;
    }

    sensor_cbi->cb->sensor_set_fps_func(sensor_cbi->arg, fps);
    if (priv->fps_info.to_fps != priv->fps_info.current_fps) {
        __update_frame_vts_and_exp_ctrl(priv);
        priv->fps_info.current_fps = priv->fps_info.to_fps;
    }
    return 0;
}

static int gc_set_flip_mirror(struct ak_sensor_subdev *sns_obj, void *arg)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sns_obj->sns_priv);
    struct sensor_cb_info *sensor_cbi = &priv->cb_info;
    int enable = *((int*)arg);
    int value = 0;
    int flip_en = enable & (0x1 << FLIP_OFFSET);
    int mirror_en = enable & (0x1 << MIRROR_OFFSET);

    if (priv->state < SNS_STATE_INIT) {
        ak_sensor_get_com_ops()->set(sns_obj, SET_FLIP_MIRROR, arg);
        return 0;
    }

//    if (flip_en)
//        value |= 0x3 << 5;
//    else
//        value &= ~(0x3 << 5);
//
//    if (mirror_en)
//        value |= 0x3 << 1;
//    else
//        value &= ~(0x3 << 1);
//
//    //FLIP_MIRROR reg 0x3221
//    ak_sensor_write(priv, 0x3221, value);

    return 0;
}

static AK_S32 gc_sensor_set(struct ak_sensor_subdev *sns_obj, AK_U32 cmd, void *args)
{
    struct ak_sensor_priv *priv = (struct ak_sensor_priv *)(sns_obj->sns_priv);
    struct ak_sensor_ops *com_ops = ak_sensor_get_com_ops();
    AK_S32 ret = 0;

    switch (cmd)
    {
        case SET_FPS_DIRECT:
            ret = gc_set_fps_direct(sns_obj, args);
            break;

        case SET_FLIP_MIRROR:
            ret = gc_set_flip_mirror(sns_obj, args);
            break;

        default:
            ret = com_ops->set(sns_obj, cmd, args);
            break;
    }

    return ret;
}

static struct ak_sensor_ops gc_sensor_ops = {
    .set = gc_sensor_set,
};

/* ------------------------gc common function end---------------------------*/


/* ------------------------gc20c3 sensor callback---------------------------*/
#ifdef GC20C3
static AK_ISP_SENSOR_CB gc20c3_cb;

static void gc20c3_parms_init_f(struct ak_sensor_priv *priv, AK_ISP_SENSOR_INIT_PARA* para)
{
    struct sensor_info *sns_info = priv->sensor_info;
    AK_ISP_SENSOR_REG_INFO* preg_info;
    int vts_h_tmp = 0x02, vts_l_tmp = 0x32;
    int i = 0;

    preg_info = para->reg_info;
    for (i = 0; i < para->num; i++) {
        if (preg_info->reg_addr == 0x0340)
            vts_h_tmp = preg_info->value;
        else if (preg_info->reg_addr == 0x0341)
            vts_l_tmp = preg_info->value;

        preg_info++;
    }

    priv->aec_parms.calc_vts_tmp = (vts_h_tmp << 8 | vts_l_tmp) * sns_info->max_fps[priv->reg_list_no] * 100;
    pr_err("calc_vts_tmp %d \n", priv->aec_parms.calc_vts_tmp);
}

static unsigned short gc20c3_960x540_60fps[] = {
    0x03fe,0xff,
    0x03fe,0x00,
    0x03fe,0x10,
    0x0190,0x03,
    0x0b4d,0x02,
    0x0d40,0x01,
    0x0087,0x50,
    0x0209,0x00,
    0x03b5,0x11,
    0x031c,0x18,
    0x03b2,0x03,
    0x03bb,0xff,
    0x03be,0xff,
    0x0d11,0x0b,
    0x0d15,0x03,
    0x0d12,0x05,
    0x0d16,0x00,
    0x0d17,0x87,
    0x0d10,0x06,
    0x0d10,0x07,
    0x0d1a,0x02,
    0x0d18,0x01,
    0x0d19,0x88,
    0x010d,0x04,
    0x010e,0xb0,
    0x0145,0x0e,
    0x0144,0x02,
    0x0142,0x02,
    0x0143,0x08,
    0x0146,0x03,
    0x0141,0x01,
    0x0149,0x02,
    0x014a,0x02,
    0x014b,0x04,
    0x0b4e,0x88,
    0x0e0c,0x00,
    0x0e0f,0x00,
    0x0e3a,0x98,
    0x0b45,0x06,
    0x0b47,0xf0,
    0x0d30,0x07,
    0x0d2f,0x05,
    0x0b40,0x57,
    0x0b43,0x00,
    0x0b41,0x0c,
    0x0d31,0x03,
    0x0c23,0x40,
    0x0e23,0x1a,
    0x0e2a,0x09,
    0x0e2b,0xc9,
    0x0e41,0x87,
    0x0e3b,0xb5,
    0x0e3a,0x15,
    0x0e37,0x1f,
    0x0e0f,0x00,
    0x0e13,0x00,
    0x03bd,0x40,
    0x0d41,0x00,
    0x0217,0x02,
    0x0213,0x04,
    0x0218,0x10,
    0x0219,0xc2,
    0x0259,0x04,
    0x025a,0x58,
    0x0211,0x01,
    0x0340,0x02,
    0x0341,0x32,
    0x0342,0x03,
    0x0343,0xe8,
    0x0212,0x18,
    0x0350,0x06,
    0x0348,0x07,
    0x0349,0x88,
    0x034a,0x04,
    0x034b,0x40,
    0x0347,0x00,
    0x0b0c,0x00,
    0x0b0d,0x02,
    0x0b0e,0x07,
    0x0b0f,0x8a,
    0x034e,0x07,
    0x034f,0xa8,
    0x030e,0x01,
    0x0004,0x0f,
    0x0444,0x00,
    0x0038,0x20,
    0x0039,0x20,
    0x003a,0x20,
    0x003b,0x20,
    0x0492,0x00,
    0x0493,0x00,
    0x0070,0x00,
    0x0094,0x03,
    0x0095,0xc0,
    0x0096,0x02,
    0x0097,0x1c,
    0x0099,0x02,
    0x009b,0x02,
    0x0438,0x0f,
    0x0439,0xf0,
    0x021a,0x10,
    0x0476,0x01,
    0x0430,0x23,
    0x0443,0x02,
    0x0038,0x00,
    0x0039,0x00,
    0x003a,0x00,
    0x003b,0x00,
    0x0070,0x80,
    0x0448,0x0d,
    0x0449,0x0d,
    0x044a,0x0d,
    0x044b,0x0d,
    0x044c,0x74,
    0x044d,0x74,
    0x044e,0x74,
    0x044f,0x74,
    0x0485,0x68,
    0x0d38,0x07,
    0x0d39,0x57,
    0x0e4e,0xa9,
    0x0072,0x09,
    0x0073,0x05,
    0x0c20,0x09,
    0x0c1d,0x02,
    0x0c1e,0x2c,
    0x0c1f,0xe6,
    0x0c19,0x00,
    0x0c1a,0x11,
    0x0c1b,0x00,
    0x0c1c,0x80,
    0x0261,0x13,
    0x0004,0x0f,
    0x0040,0x2c,
    0x004c,0x10,
    0x004d,0x40,
    0x004e,0xc0,
    0x0043,0x03,
    0x0044,0x11,
    0x0045,0x58,
    0x0046,0x57,
    0x0052,0x84,
    0x0053,0xa0,
    0x0055,0x20,
    0x0152,0x14,
    0x0100,0x03,
    0x031c,0x1f,
    0x0336,0x01,
    0x0336,0x00,
    0x03fe,0x00,
    0x027f,0x03,
    0x0295,0x01,
    0x0290,0x00,
    0x0293,0x00,
    0x0294,0x00,
    0x0296,0x3f,
};


static unsigned short gc20c3_slave_960x540_60fps[] = {
    0x03fe,0xff,
    0x03fe,0x00,
    0x03fe,0x10,
    0x0190,0x03,
    0x0b4d,0x02,
    0x0d40,0x01,
    0x0087,0x50,
    0x0209,0x00,
    0x03b5,0x11,
    0x031c,0x18,
    0x03b2,0x03,
    0x03bb,0xff,
    0x03be,0xff,
    0x0d11,0x0b,
    0x0d15,0x03,
    0x0d12,0x05,
    0x0d16,0x00,
    0x0d17,0x87,
    0x0d10,0x06,
    0x0d10,0x07,
    0x0d1a,0x02,
    0x0d18,0x01,
    0x0d19,0x88,
    0x010d,0x04,
    0x010e,0xb0,
    0x0145,0x0e,
    0x0144,0x02,
    0x0142,0x02,
    0x0143,0x08,
    0x0146,0x03,
    0x0141,0x01,
    0x0149,0x02,
    0x014a,0x02,
    0x014b,0x04,
    0x0b4e,0x88,
    0x0e0c,0x00,
    0x0e0f,0x00,
    0x0e3a,0x98,
    0x0b45,0x06,
    0x0b47,0xf0,
    0x0d30,0x07,
    0x0d2f,0x05,
    0x0b40,0x57,
    0x0b43,0x00,
    0x0b41,0x0c,
    0x0d31,0x03,
    0x0c23,0x40,
    0x0e23,0x1a,
    0x0e2a,0x09,
    0x0e2b,0xc9,
    0x0e41,0x87,
    0x0e3b,0xb5,
    0x0e3a,0x15,
    0x0e37,0x1f,
    0x0e0f,0x00,
    0x0e13,0x00,
    0x03bd,0x40,
    0x0d41,0x00,
    0x0217,0x02,
    0x0213,0x04,
    0x0218,0x10,
    0x0219,0xc2,
    0x0259,0x04,
    0x025a,0x58,
    0x0211,0x01,
//    0x0340,0x02,
//    0x0341,0x32,
//    0x0342,0x03,
//    0x0343,0xe8,
    0x0340,0x02,
    0x0341,0x3E,
    0x0342,0x03,
    0x0343,0xd4,

    0x0212,0x18,
    0x0350,0x06,
    0x0348,0x07,
    0x0349,0x88,
    0x034a,0x04,
    0x034b,0x40,
    0x0347,0x00,
    0x0b0c,0x00,
    0x0b0d,0x02,
    0x0b0e,0x07,
    0x0b0f,0x8a,
    0x034e,0x07,
    0x034f,0xa8,
    0x030e,0x01,
    0x0004,0x0f,
    0x0444,0x00,
    0x0038,0x20,
    0x0039,0x20,
    0x003a,0x20,
    0x003b,0x20,
    0x0492,0x00,
    0x0493,0x00,
    0x0070,0x00,
    0x0094,0x03,
    0x0095,0xc0,
    0x0096,0x02,
    0x0097,0x1c,
    0x0099,0x02,
    0x009b,0x02,
    0x0438,0x0f,
    0x0439,0xf0,
    0x021a,0x10,
    0x0476,0x01,
    0x0430,0x23,
    0x0443,0x02,
    0x0038,0x00,
    0x0039,0x00,
    0x003a,0x00,
    0x003b,0x00,
    0x0070,0x80,
    0x0448,0x0d,
    0x0449,0x0d,
    0x044a,0x0d,
    0x044b,0x0d,
    0x044c,0x74,
    0x044d,0x74,
    0x044e,0x74,
    0x044f,0x74,
    0x0485,0x68,
    0x0d38,0x07,
    0x0d39,0x57,
    0x0e4e,0xa9,
    0x0072,0x09,
    0x0073,0x05,
    0x0c20,0x09,
    0x0c1d,0x02,
    0x0c1e,0x2c,
    0x0c1f,0xe6,
    0x0c19,0x00,
    0x0c1a,0x11,
    0x0c1b,0x00,
    0x0c1c,0x80,
    0x0261,0x13,
    0x0004,0x0f,
    0x0040,0x2c,
    0x004c,0x10,
    0x004d,0x40,
    0x004e,0xc0,
    0x0043,0x03,
    0x0044,0x11,
    0x0045,0x58,
    0x0046,0x57,
    0x0052,0x84,
    0x0053,0xa0,
    0x0055,0x20,
    0x0152,0x14,
    0x0100,0x03,
    0x031c,0x1f,
    0x0336,0x01,
    0x0336,0x00,
    0x03fe,0x00,
//    0x027f,0x03,
//    0x0295,0x01,
//    0x0290,0x00,
//    0x0293,0x00,
//    0x0294,0x00,
//    0x0296,0x3f,

    0x0252,0x00,
    0x0253,0x00,
    0x0254,0x00,
    0x0282,0x02,
    0x027f,0x03,
    0x0295,0x02,
    0x0291,0x90,
    0x0273,0x03,
};

#if 0
static unsigned short gc20c3_1920x1080_30fps[] = {
0x03fe, 0x00ff,
0x03fe, 0x0000,
0x03fe, 0x0010,
0x0d40, 0x0001,
0x0087, 0x0051,
0x0209, 0x0000,
0x031c, 0x0018,
0x03bb, 0x00ff,
0x03be, 0x00ff,
0x0d10, 0x0002,
0x0d11, 0x000a,
0x0d10, 0x0007,
0x0d1a, 0x0002,
0x0d15, 0x0002,
0x0d12, 0x0025,
0x0d16, 0x0000,
0x0d17, 0x002d,
0x0d18, 0x0021,
0x0d19, 0x0028,
0x0145, 0x000d,
0x0144, 0x0002,
0x0142, 0x0004,
0x0143, 0x0014,
0x0146, 0x0005,
0x0141, 0x0005,
0x0149, 0x0005,
0x014a, 0x0007,
0x014b, 0x0006,
0x0b4e, 0x0088,
0x0e0c, 0x0000,
0x0e0f, 0x0000,
0x0e3a, 0x0098,
0x0b45, 0x0006,
0x0b47, 0x00f0,
0x0d30, 0x000a,
0x0d2f, 0x0004,
0x0b40, 0x0057,
0x0b43, 0x0000,
0x0b41, 0x000c,
0x0d31, 0x0003,
0x0c23, 0x0040,
0x0e23, 0x001a,
0x0e2a, 0x0009,
0x0e2b, 0x00c9,
0x0e41, 0x0087,
0x0e3b, 0x00b5,
0x0e3a, 0x0015,
0x0e37, 0x001f,
0x0217, 0x0000,
0x0213, 0x0004,
0x0219, 0x00c2,
0x0259, 0x0004,
0x025a, 0x004c,
0x0340, 0x0004,
0x0341, 0x0084,
0x0342, 0x0003,
0x0343, 0x00cd,
0x0350, 0x0014,
0x0348, 0x0007,
0x0349, 0x0088,
0x034a, 0x0004,
0x034b, 0x0040,
0x0347, 0x0000,
0x0b0c, 0x0000,
0x0b0d, 0x0002,
0x0b0e, 0x0007,
0x0b0f, 0x008a,
0x0b4d, 0x0002,
0x034e, 0x0007,
0x034f, 0x00a8,
0x0004, 0x000f,
0x0444, 0x000a,
0x0038, 0x0020,
0x0039, 0x0020,
0x003a, 0x0020,
0x003b, 0x0020,
0x0492, 0x0000,
0x0493, 0x0000,
0x0070, 0x0000,
0x0094, 0x0007,
0x0095, 0x0080,
0x0096, 0x0004,
0x0097, 0x0038,
0x0099, 0x0004,
0x009b, 0x0004,
0x0438, 0x000f,
0x0439, 0x00f0,
0x021a, 0x0010,
0x0476, 0x0001,
0x0430, 0x0023,
0x0443, 0x0002,
0x0038, 0x0000,
0x0039, 0x0000,
0x003a, 0x0000,
0x003b, 0x0000,
0x0070, 0x0080,
0x0448, 0x000d,
0x0449, 0x000d,
0x044a, 0x000d,
0x044b, 0x000d,
0x044c, 0x0074,
0x044d, 0x0074,
0x044e, 0x0074,
0x044f, 0x0074,
0x0485, 0x0068,
0x0d38, 0x0007,
0x0d39, 0x0057,
0x0e4e, 0x00a9,
0x0072, 0x0009,
0x0073, 0x0005,
0x0c20, 0x000d,
0x0c1d, 0x0004,
0x0c1e, 0x0080,
0x0c1f, 0x00c0,
0x031c, 0x001f,
0x0336, 0x0001,
0x0336, 0x0000,
0x03fe, 0x0000,
0x0151, 0x0002,
0x0202, 0x0001,
0x0203, 0x0000,
0x0261, 0x0013,
0x03bc, 0x000f,
0x03b0, 0x0003,
0x0209, 0x0001,
0x03b1, 0x0002,
0x03b5, 0x0011,
0x03b6, 0x0000,
0x03b7, 0x0020,
0x03b9, 0x0000,
0x03ba, 0x0040,
0x0252, 0x0000,
0x0253, 0x0000,
0x0254, 0x0000,
0x0280, 0x0002,
0x027f, 0x0003,
0x0295, 0x0002,
0x0291, 0x0090,
0x0273, 0x0003,
0x0100, 0x0003,
};
#endif
static int gc20c3_sensor_init_func(void *arg, const AK_ISP_SENSOR_INIT_PARA *npara)
{
    struct ak_sensor_priv *priv = arg;
    struct sensor_info *info = priv->sensor_info;
    struct gc_common_attr *sc_attr = container_of(priv, struct gc_common_attr, priv);
    AK_ISP_SENSOR_INIT_PARA *para = &priv->para;
    AK_ISP_SENSOR_CB *sensor_cb = priv->cb_info.cb;
    int sensor_last_state = priv->state;
    AK_ISP_SENSOR_REG_INFO *preg_info;
    AK_ISP_SENSOR_INIT_PARA para1;
    int i;
    int value;

    sensor_info("%s sensor_mode %s\n", __func__,
        (priv->master_or_slave == MASTER_MODE) ? "MASTER" : "SLAVER");

    if (priv->master_or_slave == MASTER_MODE) {
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)gc20c3_960x540_60fps;
            para->num = sizeof(gc20c3_960x540_60fps)
                / sizeof(gc20c3_960x540_60fps[0]) / 2;
        }
        else
        {
            if (npara) {
                para = (void*)npara;
                preg_info = para->reg_info;
            }
//            else {
//                preg_info = (void*)gc20c3_1920x1080_30fps;
//                para->num = sizeof(gc20c3_1920x1080_30fps)
//                    / sizeof(gc20c3_1920x1080_30fps[0]) / 2;
//            }
        }
    } else if (priv->master_or_slave == SLAVER_MODE) {
//        sensor_err("[%s]%dSLAVER mode not support\n", __func__, __LINE__);
        if(priv->reg_list_no == 1)
        {
            preg_info = (void*)gc20c3_slave_960x540_60fps;
            para->num = sizeof(gc20c3_slave_960x540_60fps)
                / sizeof(gc20c3_slave_960x540_60fps[0]) / 2;
        }
        else
        {
            if (npara) {
                para = (void*)npara;
                preg_info = para->reg_info;
            }
        }
    } else {
        if (para->num <= 0 && npara)
            para = (void*)npara;

        preg_info = para->reg_info;
    }
    sensor_info("reg_list_no:%d,para_num:%d,to_fps:%d,max_fps:%d,last_state:%d\n", priv->reg_list_no, para->num,
                                                priv->fps_info.to_fps, info->max_fps[priv->reg_list_no], sensor_last_state);

    if(preg_info == NULL){
        sensor_err("preg_info == NULL\n");
        return -1;
    }

    priv->state = SNS_STATE_INIT;
    para1.num = para->num;
    para1.reg_info = preg_info;
    gc20c3_parms_init_f(priv, &para1);
    if (priv->fps_info.to_fps == 0)
        priv->fps_info.to_fps = info->max_fps[priv->reg_list_no];
    for (i = 0; i < para->num; i++) {

#if 1
        if (preg_info->reg_addr == 0x100) {

            sensor_cb->sensor_set_fps_func(priv, priv->fps_info.to_fps);

            sensor_cb->sensor_updata_exp_time_func(priv, priv->aec_parms.target_exp);

            priv->fps_info.current_fps = priv->fps_info.to_fps;//TODO

            sensor_cb->sensor_update_a_gain_func(priv, priv->aec_parms.target_a_gain);

//            sensor_cb->sensor_update_d_gain_func(priv, priv->aec_parms.target_d_gain);

//            gc_set_flip_mirror(priv->sd, &priv->flip_mirror);

            pr_err("init fps_exp_again:%d-%d-%d\r\n", priv->fps_info.to_fps,
                                                        priv->aec_parms.target_exp,
                                                        priv->aec_parms.target_a_gain);

            if (sensor_last_state == SNS_STATE_WORK) {
                //小窗切大窗, AV130不采大窗, 不开启码流
                sensor_info("switch big windows\n");
                break;
            }
        }
#endif
        ak_sensor_write(arg, preg_info->reg_addr, preg_info->value);
        preg_info++;
    }

    priv->state = SNS_STATE_WORK;

    return 0;
}
/* end of func gc20c3_sensor_init_func */

/*
    release_AEC_v1.2.0_00&02&03&05&06_liner_GC20C3.txt
*/
static unsigned int regValTable[13][7] = {
  //   0d04  0d05  0e36  0e39   04a8   04a9   0052      |  实际倍数   | Again dB|
     { 0x00, 0x01, 0x15, 0x15,  0x01,  0x00,  0x64},    //|  X1        | 0.00    |
     { 0x00, 0x02, 0x15, 0x15,  0x01,  0x1b,  0x64},    //|  X1.43     | 3.09    |
     { 0x00, 0x03, 0x16, 0x16,  0x02,  0x00,  0x64},    //|  X2.01     | 6.05    |
     { 0x00, 0x04, 0x17, 0x17,  0x02,  0x37,  0x64},    //|  X2.87     | 9.17    |
     { 0x00, 0x05, 0x17, 0x17,  0x04,  0x02,  0x84},    //|  X4.03     | 12.11   |
     { 0x00, 0x06, 0x18, 0x18,  0x05,  0x32,  0x84},    //|  X5.79     | 15.25   |
     { 0x00, 0x07, 0x19, 0x19,  0x08,  0x05,  0x84},    //|  X8.09     | 18.16   |
     { 0x04, 0x97, 0x1a, 0x1a,  0x0b,  0x10,  0x84},    //|  X11.25    | 21.03   |
     { 0x08, 0x07, 0x1b, 0x1b,  0x10,  0x04,  0x84},    //|  X16.07    | 24.12   |
     { 0x0a, 0x4f, 0x1c, 0x1c,  0x16,  0x22,  0x88},    //|  X22.54    | 27.06   |
     { 0x0c, 0x07, 0x1d, 0x1d,  0x20,  0x06,  0x88},    //|  X32.10    | 30.13   |
     { 0x0d, 0x2f, 0x1e, 0x1e,  0x2d,  0x10,  0x88},    //|  X45.26    | 33.11   |
     { 0x0e, 0x07, 0x20, 0x20,  0x3f,  0x23,  0x72},    //|  X63.56    | 36.06   |
};

static unsigned int gainLevelTable[14] = {
    64,
    91,
    128,
    183,
    257,
    370,
    517,
    720,
    1028,
    1442,
    2054,
    2896,
    4067,
    0xffffffff,
};

static int SetSensorGain(struct ak_sensor_priv* priv, unsigned int gain)
{
    int i;

    unsigned int tol_dig_gain = 0;
    int total = sizeof(gainLevelTable) / sizeof(gainLevelTable[0]);
    unsigned int tmp_gain = gain / 4;  //1/64 ISP传参精度

//    if (priv->aec_parms.curr_again_level>0)
//        total = priv->aec_parms.curr_again_level;
    for (i = 0; i < total-2 ; i++)
    {
        if ((gainLevelTable[i] <= tmp_gain) && (tmp_gain < gainLevelTable[i + 1]))
            break;
    }

    tol_dig_gain = tmp_gain * 1024 / gainLevelTable[i];
    //tol_dig_gain = tmp_gain*64 / gainLevelTable[i];

    //高温逻辑，限制dgain
    if(tol_dig_gain>2*1024)
        tol_dig_gain=2*1024;

    //pr_err("[%s] gain:%d total_dig_gain:%d\n", __func__, tmp_gain, tol_dig_gain);

    ak_sensor_write(priv, 0x0d04, regValTable[i][0]);
    ak_sensor_write(priv, 0x0d05, regValTable[i][1]);
    ak_sensor_write(priv, 0x0e36, regValTable[i][2]);
    ak_sensor_write(priv, 0x0e39, regValTable[i][3]);
    ak_sensor_write(priv, 0x04a8, regValTable[i][4]);
    ak_sensor_write(priv, 0x04a9, regValTable[i][5]);
    ak_sensor_write(priv, 0x0052, regValTable[i][6]);

    ak_sensor_write(priv, 0x0474, (tol_dig_gain >> 8) & 0xff);
    ak_sensor_write(priv, 0x0475, (tol_dig_gain & 0xff));

    return 0;
}

static int gc20c3_sensor_update_a_gain_func(void *arg, const unsigned int a_gain)
{
    /*
     * max again < 25 times = 8192
     * */
    struct ak_sensor_priv *priv = arg;
//    struct sensor_info* info = priv->sensor_info;

    SetSensorGain(priv, a_gain); //64=1x

    return A_GAIN_EFFECT_FRAMES;   //A_GAIN_EFFECT_FRAMES 1 adjust a_gain for 1/2 frames
}

static int gc20c3_sensor_update_d_gain_func(void *arg, const unsigned int d_gain)
{
    return 0;
}

static AK_ISP_SENSOR_CB gc20c3_cb = {
    .sensor_init_func = gc20c3_sensor_init_func,

    .sensor_update_a_gain_func = gc20c3_sensor_update_a_gain_func,
    .sensor_update_d_gain_func = gc20c3_sensor_update_d_gain_func,
    .sensor_updata_exp_time_func = gc_sensor_updata_exp_time_func,
    .sensor_set_fps_func = gc_sensor_set_fps_func,
};


#define GC20C3_SENSOR_INFO {   \
    .sensor_pwdn_level              = 0,    \
    .sensor_reset_level             = 0,    \
    .sensor_i2c_addr                = {0x31, 0x10}, \
    .sensor_cb                      = &gc20c3_cb,  \
    .regaddr_byte                   = 2,    \
    .data_byte                      = 1,    \
    .max_fps                        = {30, 60},   \
    .max_exp                        = {1130, 590},   \
    .max_again_x                    = 64,   \
    .max_dgain_x                    = 1,   \
    .id_reg_h                       = 0x03f0,   \
    .id_reg_l                       = 0x03f1,   \
    .actual_sensor_id               = 0x20c3,   \
    .sensor_id                      = 0x20c3,   \
    .sensor_output_width            = {1920, 960}, \
    .sensor_output_height           = {1080, 540}, \
    .sensor_mclk                    = 24,   \
    .sensor_valid_offset_x          = {0,0},    \
    .sensor_valid_offset_y          = {0,0},    \
    .sensor_io_level                = IO_LEVEL_1V8, \
    .sensor_dual_sync_mode          = DUAL_SYNC_PWM_FREQ_FIXED, \
    .exp_unit                       = 1, \
    .raw_format                     = 3,    \
    .mipi_lanes_swap                = 0x435A1,  \
    .mipi_lanes                     = 2,    \
    .sensor_bus_type                = BUS_TYPE_RAW, \
    .struct_size                    = sizeof(struct gc_common_attr),   \
    .ops                            = &gc_sensor_ops,   \
}

#endif
/* ------------------------gc20c3 sensor callback end-----------------------*/

struct sensor_info gc_sensor_info_table[] = {
    #ifdef GC20C3
    GC20C3_SENSOR_INFO,
    #endif
};

int gc_sensor_info_table_count = sizeof(gc_sensor_info_table) / sizeof(gc_sensor_info_table[0]);

/*end of file*/
