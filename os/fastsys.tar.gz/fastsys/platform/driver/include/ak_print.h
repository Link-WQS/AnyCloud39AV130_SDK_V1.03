#ifndef __AK_PRINT_H__
#define __AK_PRINT_H__

#include <stdio.h>

/**/
#define pr_err(s, arg...)      printf(s, ##arg)
#define pr_warn(s, arg...)      printf(s, ##arg)
//#define pr_info(s, arg...)      printf(s, ##arg)
//#define pr_debug(s, arg...)      printf(s, ##arg)
#define pr_info(s, arg...)
#define pr_debug(s, arg...)

#define drv_debug                    pr_debug
#define drv_info                     pr_info
#define drv_warn                     pr_warn
#define drv_err                      pr_err

#endif
