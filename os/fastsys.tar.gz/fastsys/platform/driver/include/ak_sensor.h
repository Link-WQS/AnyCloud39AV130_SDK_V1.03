#ifndef __AK_SENSOR_H__
#define __AK_SENSOR_H__

struct ak_sensor_subdev;

struct ak_sensor_ops {
    int  (*set)(struct ak_sensor_subdev *obj, unsigned int cmd, void *args);
    int  (*get)(struct ak_sensor_subdev *obj, unsigned int cmd, void *args);
};

struct ak_sensor_subdev {
    //
    unsigned int  sns_id;//dev + sub
    //dts配置参数
    unsigned int  i2c_id;
    unsigned int  i2c_addr_sel;
    unsigned int  gpio_pwdn;
    unsigned int  gpio_reset;
    unsigned int  gpio_power;
    unsigned int  gpio_fsync;

    //匹配前, 系统赋值
    struct ak_sensor_ops    ops;
    //
    void    *sns_priv;

    unsigned int  match:1;
};


void ak_sensor_probe(void);

#endif