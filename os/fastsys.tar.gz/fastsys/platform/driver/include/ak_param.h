#ifndef __AK_PARAM_H__
#define __AK_PARAM_H__

#include "dss.h"

/**/
int ak_fastsys_param_init();
/**/
struct ak_qs_dss_info *ak_get_dss_param();
/**/
int is_hw_photosensitivity_enable(int dev_id);
/**/
int disable_hw_sensor(int dev_id);
/**/
int is_soft_sensor_enable(int dev_id);
/**/
int ak_fastsys_param_is_init();

struct image_header {
    uint32_t data[16];  //0 - magic
                        //1 - header checksum
                        //2 - time
                        //3 - data size
                        //6 - data checksum
};

#define be32_to_cpu(x) \
    ((((x) & 0xff000000) >> 24) | \
     (((x) & 0x00ff0000) >>  8) | \
     (((x) & 0x0000ff00) <<  8) | \
     (((x) & 0x000000ff) << 24))

unsigned int ak_check_sum(const void *buf, unsigned int bytes);

#endif // __AK_PARAM_H__
