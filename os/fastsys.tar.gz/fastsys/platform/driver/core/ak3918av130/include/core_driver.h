#ifndef __CORE_DRIVER_AK3918AV130_H__
#define __CORE_DRIVER_AK3918AV130_H__

#include "rtconfig.h"
#include "types.h"
#include "cmsis_os2.h"
#include "ak_time.h"
#include "ak_print.h"
#include "ak_irq.h"

/**
 * error code
 */
#define DRV_EOK                          0               /**< There is no error */
#define DRV_ERROR                        1               /**< A generic error happens */
#define DRV_ETIMEOUT                     2               /**< Timed out */
#define DRV_EFULL                        3               /**< The resource is full */
#define DRV_EEMPTY                       4               /**< The resource is empty */
#define DRV_ENOMEM                       5               /**< No memory */
#define DRV_ENOSYS                       6               /**< No system */
#define DRV_EBUSY                        7               /**< Busy */
#define DRV_EIO                          8               /**< IO error */
#define DRV_EINTR                        9               /**< Interrupted system call */
#define DRV_EINVAL                       10              /**< Invalid argument */

uint32_t tick_from_millisecond(uint32_t ms);

/**
 * timer
 */
/* get tick in us */
static inline uint64_t core_driver_get_timer_tick_us(void)
{
    return 0;
}

/* it will be bug if overflow of the systime count */
static inline void os_udelay_no_schedule(uint32_t us)
{

}
#define core_driver_udelay_no_schedule(us)  os_udelay_no_schedule(us)

static inline void os_msleep(uint32_t ms)
{
    osDelay(tick_from_millisecond(ms));
}

/**
 * irq
 */
/**/
#define irq_alloc()                 uint32_t __flags
#define irq_store()                 __flags = drv_irq_store()
#define irq_restore()               drv_irq_restore(__flags)
/**/
#define core_driver_irq_alloc       irq_alloc
#define core_driver_irq_store       irq_store
#define core_driver_irq_restore     irq_restore

/**
 * mem
 */
static inline void *__malloc_align(unsigned long size, unsigned long align)
{
    return osMemoryAlloc(size);
}
static inline void __free_align(void *ptr)
{
    osMemoryFree(ptr);
}
#define drv_malloc_align                __malloc_align
#define drv_free_align                  __free_align
#define drv_dma_alloc_align             __malloc_align
#define drv_dma_free_align              __free_align

#define drv_mmap(paddr, len)            ((void *)paddr)
#define drv_mmap_nocache(paddr, len)    ((void *)paddr)
#define drv_unmap(start, len)           (0)
#define drv_va2pa(ptr)                  (ptr)

volatile unsigned int _g_AK_FASTSYS_MEM_SIZE;
volatile unsigned int _g_AK_FASTSYS_MEM_BASE;

volatile unsigned int _g_AK_IPI_MEM_SIZE;
volatile unsigned int _g_AK_IPI_MEM_BASE;

volatile unsigned int _g_AK_PARAM_MEM_SIZE;
volatile unsigned int _g_AK_PARAM_MEM_BASE;

volatile unsigned int _g_AK_LOG_MEM_SIZE;
volatile unsigned int _g_AK_LOG_MEM_BASE;

volatile unsigned int _g_AK_ISPCONF_MEM_SIZE;
volatile unsigned int _g_AK_ISPCONF_MEM_BASE;

volatile unsigned int _g_AK_HEAP_MEM_END;

volatile unsigned int _g_AK_SYS_VECTOR_MEM_BASE;

#endif
