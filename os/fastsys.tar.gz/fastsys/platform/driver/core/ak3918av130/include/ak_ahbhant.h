#ifndef __AK_AHBHANT_H__
#define __AK_AHBHANT_H__

#include "types.h"
#include "ak_irq.h"

void ak_ahbhant_register_intr(irq_handler_t callback,void *priv);
void ak_ahbhant_trigger_cpub_irq(void);

#endif // __AK_AHBHANT_H__
