#ifndef __FASTSYS_DEFCONFIG_H__
#define __FASTSYS_DEFCONFIG_H__

#define FASTSYS_MEM_BASE    0x81400000
#define FASTSYS_MEM_SIZE    0x300000        /* 3M */

#define SYS_VECTOR_MEM_SIZE 0x10000         // 64K
#define SYS_VECTOR_MEM_BASE (FASTSYS_MEM_BASE + FASTSYS_MEM_SIZE - SYS_VECTOR_MEM_SIZE)

#define IPI_MEM_SIZE        0x10000         // 64K
#define IPI_MEM_BASE        (SYS_VECTOR_MEM_BASE - IPI_MEM_SIZE)
//
#define PARAM_MEM_SIZE      0x2000          // 8K
#define PARAM_MEM_BASE      (IPI_MEM_BASE - PARAM_MEM_SIZE)

#define LOG_MEM_SIZE        0x40000         // 256k
#define LOG_MEM_BASE        (PARAM_MEM_BASE - LOG_MEM_SIZE)

#define ISPCONF_MEM_SIZE    0x30000
#define ISPCONF_MEM_BASE    (LOG_MEM_BASE - ISPCONF_MEM_SIZE)

#define HEAP_MEM_END        (ISPCONF_MEM_BASE)

#define AK_MAIN_THREAD_STACK_SIZE   (64 * 1024)

#endif
