#ifndef __FASTSYS_DEFCONFIG_H__
#define __FASTSYS_DEFCONFIG_H__

#define FASTSYS_MEM_BASE    0x81400000
#define FASTSYS_MEM_SIZE    (512 * 1024)        /* 512k */

#define LOG_MEM_SIZE        (16 * 1024)         // 16k
#define LOG_MEM_BASE        (FASTSYS_MEM_BASE + FASTSYS_MEM_SIZE - LOG_MEM_SIZE)

#define HEAP_MEM_END        (LOG_MEM_BASE)

#endif
