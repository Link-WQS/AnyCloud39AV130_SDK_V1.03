#ifndef __IRQ_H__
#define __IRQ_H__

#include <stdbool.h>

typedef bool (* irq_handler_t)(int irq, void *dev);

typedef enum {
    INT_VECTOR_NSS_LEVEL2,
    INT_VECTOR_ISS_LEVEL2,
    INT_VECTOR_ESS_LEVEL2,
    INT_VECTOR_SYS_CTRL,
    INT_VECTOR_MCI0,
    INT_VECTOR_MCI1,
    INT_VECTOR_DAC,
    INT_VECTOR_ADC,
    INT_VECTOR_SFC,
    INT_VECTOR_SPI1,
    INT_VECTOR_UART0,
    INT_VECTOR_UART1,
    INT_VECTOR_L2_BUF,
    INT_VECTOR_TWI_LEVEL2,
    INT_VECTOR_SPI2,
    INT_VECTOR_GPIO,
    INT_VECTOR_MAC,
    INT_VECTOR_SE_LEVEL2,
    INT_VECTOR_USB,
    INT_VECTOR_USB_DMA,
    INT_VECTOR_MEM_COPY,
    INT_VECTOR_L_AHBHOT,
    INT_VECTOR_MCI2,
    INT_VECTOR_PWM,
    INT_VECTOR_UART2,
    INT_VECTOR_RESERVED,
    INT_VECTOR_B_AHBHOT,
    INT_VECTOR_TIMER0,
    INT_VECTOR_TIMER1,
    INT_VECTOR_TIMER2,
    INT_VECTOR_TIMER3,
    INT_VECTOR_TIMER4,

    INT_VECTOR_TWI0 = 32,
    INT_VECTOR_TWI1,
    INT_VECTOR_TWI2,

    INT_VECTOR_ENCRYPT = INT_VECTOR_TWI0 + 32,
    INT_VECTOR_HASH,
    INT_VECTOR_TRNG,
    INT_VECTOR_PKE,

    INT_VECTOR_NNE = INT_VECTOR_ENCRYPT + 32,
    INT_VECTOR_BPP,
    INT_VECTOR_NPU_SMMU,

    INT_VECTOR_ISP = INT_VECTOR_NNE + 32,
    INT_VECTOR_PP,
    INT_VECTOR_VI,
    INT_VECTOR_SMMU,
    INT_VECTOR_CSI0,
    INT_VECTOR_CSI1,
    INT_VECTOR_CSI0_ERROR,
    INT_VECTOR_CSI1_ERROR,

    INT_VECTOR_VENC = INT_VECTOR_ISP + 32,
    INT_VECTOR_VENC_BRIDGE,
    INT_VECTOR_ESS_SMMU,

    INT_VECTOR_SAR_ADC = INT_VECTOR_VENC +32,
    INT_VECTOR_RTC_RDY,
    INT_VECTOR_RTC_ALARM,
    INT_VECTOR_RTC_TIMER,
    INT_VECTOR_RTC_WDT,
    INT_VECTOR_TSENSOR,
    INT_VECTOR_NUM,
} INT_VECTOR;

int irq_request(INT_VECTOR irq, irq_handler_t handler, void *dev);

void irq_free(INT_VECTOR irq);

int irq_enable(INT_VECTOR irq);

int irq_disable(INT_VECTOR irq);

void interrupt_init();

void ak_irq_handler();

extern unsigned long rt_hw_interrupt_disable(void);
extern void rt_hw_interrupt_enable(unsigned long level);

static inline unsigned long drv_irq_store(void)
{
    return (unsigned long)rt_hw_interrupt_disable();
}

static inline void drv_irq_restore(unsigned long flags)
{
    rt_hw_interrupt_enable((unsigned long)flags);
}

#endif