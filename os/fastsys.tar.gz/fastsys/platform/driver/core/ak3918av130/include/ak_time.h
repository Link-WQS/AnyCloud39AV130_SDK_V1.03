#ifndef __AK_TIME_H__
#define __AK_TIME_H__

#include "types.h"

typedef void (*timer_handler_t)(void *dev);

void ak_tick_timer_init(u32 tick_ms, timer_handler_t handler);

u64 get_tick_count_us(void);

u32 drv_get_tick_count_us(void);

u32 drv_get_tick_count_ms(void);

#endif // __AK_TIME_H__
