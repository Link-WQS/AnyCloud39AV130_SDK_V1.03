#ifndef __TYPES_H__
#define __TYPES_H__

#include <stddef.h>
#include <stdbool.h>

/* base */
typedef signed      char        s8;
typedef unsigned    char        u8;
typedef signed      short       s16;
typedef unsigned    short       u16;
typedef signed      int         s32;
typedef unsigned    int         u32;
typedef unsigned    long long       u64;
typedef signed      long  long       s64;

typedef u8          uint8_t;
typedef u16         uint16_t;
typedef u32         uint32_t;
typedef u64         uint64_t;
typedef s8          int8_t;
typedef s16         int16_t;
typedef s32         int32_t;
typedef s64         int64_t;

typedef uint8_t     bool_t;
typedef uint32_t    psize_t;

#endif /* __TYPES_H__ */