#ifndef __CPU_CONFIG_H__
#define __CPU_CONFIG_H__

#include "autoconf.h"

#endif
