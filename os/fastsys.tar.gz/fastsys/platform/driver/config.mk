
# ak3918av200
ifeq ($(CHIP),ak3918av200)
I2C				= y
SARADC			= y
SENSOR			= y
VI				= y
VENC			= y
IPI				= y
AK_PARAM		= y
endif

# ak3918av100
ifeq ($(CHIP),ak3918av100)
I2C				= n
SARADC			= n
SENSOR			= n
VI				= n
VENC			= n
IPI				= n
endif

# ak3918av130
ifeq ($(CHIP),ak3918av130)
I2C				= y
SARADC			= y
SENSOR			= y
VI				= y
VENC			= n
IPI				= y
AK_PARAM		= y
endif
