
#ifndef  __ANYKA_RSC_TABLE_H__
#define  __ANYKA_RSC_TABLE_H__

#include <stddef.h>
#include <stdint.h>
#include "remoteproc.h"


#define NUM_RESOURCE_ENTRIES	2
#define NUM_VRINGS				2

#define FW_RSC_U64_ADDR_ANY 0xFFFFFFFFFFFFFFFFUL
#define FW_RSC_U32_ADDR_ANY 0xFFFFFFFFUL

#define RPROC_MAX_NAME_LEN 32

/* Memory attribute */
/* bit0: cacheable / non-cacheable */
#define MEM_CACHEABLE		(1U << 0)
#define MEM_NONCACHEABLE	(0U << 0)

struct ak_resource_table {
	uint32_t version;
	uint32_t num;
	uint32_t reserved[2];
	uint32_t offset[NUM_RESOURCE_ENTRIES];

	/* shared memory entry for rpmsg virtIO device */
	struct fw_rsc_carveout rvdev_shm;
	/* rpmsg vdev entry */
	struct fw_rsc_vdev vdev;
	struct fw_rsc_vdev_vring vring0;
	struct fw_rsc_vdev_vring vring1;
}__attribute__((packed)) ;
//  #pragma pack()

 void resource_table_init(int rsc_id, void **table_ptr, int *length);


struct fw_rsc_carveout *resource_table_get_rvdev_shm_entry(void *rsc_table, int rvdev_id);
unsigned int resource_table_vdev_notifyid(void);
struct fw_rsc_vdev *resource_table_get_vdev(int index);

#endif /*__ANYKA_RSC_TABLE_H__*/
