#ifndef __OPENAMP_LOG_H__
#define __OPENAMP_LOG_H__

#include <stdio.h>
#include "ak_print.h"

#ifdef __cplusplus
extern "C" {
#endif

#define OPENAMP_DBG

#ifdef OPENAMP_DBG
#define openamp_dbg(fmt, args...) \
	printf("[AMP_DBG]" fmt, ##args)
#define openamp_dbgFromISR(fmt, args...) \
	printf("[AMP_DBG]" fmt, ##args)
#else
#define openamp_dbg(fmt, args...)
#define openamp_dbgFromISR(fmt, args...)
#endif /* OPENAMP_DBG */

#define openamp_info(fmt, args...) \
	printf("[AMP_INFO]" fmt, ##args)
#define openamp_infoFromISR(fmt, args...) \
	printf("[AMP_INFO]" fmt, ##args)

#define openamp_err(fmt, args...) \
	printf("[AMP_ERR]" fmt, ##args)
#define openamp_errFromISR(fmt, args...) \
	printf("[AMP_ERR]" fmt, ##args)

#ifdef __cplusplus
}
#endif

#endif /* ifndef __OPENAMP_LOG_H__ */

