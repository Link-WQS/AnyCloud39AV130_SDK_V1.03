#ifndef __ANYKA_RPROC_H__
#define __ANYKA_RPROC_H__

#ifdef __cplusplus
extern "C" {
#endif

struct rproc_global_impls {
	void *ops;
	void *priv;
};

extern struct rproc_global_impls ak_rproc_impls[];
extern const size_t ak_rproc_impls_size;

#define GET_RPROC_GLOBAL_IMPLS_ITEMS(impls_array) \
        sizeof(impls_array) / sizeof(impls_array[0]);

#ifdef __cplusplus
}
#endif


#endif /* __ANYKA_RPROC_H__ */
