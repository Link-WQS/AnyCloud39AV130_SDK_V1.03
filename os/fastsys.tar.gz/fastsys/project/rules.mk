# tools
RM           		= rm -rf
MKDIR        		= mkdir
MAKE				= make

# support list
SUPPORT_LIST_ARCH 	:= 	riscv arm
SUPPORT_LIST_MARCH	:= 	u64 arm926ejs
SUPPORT_LIST_CHIP	:= 	ak3918av200 ak3918av100 ak3918av130
SUPPORT_LIST_OS		:= 	rtthread

# function
printf_var			= $(1)=$($(1))
# error
ERRCODE_PARAM		= 1
err					= $(error $(1):$($(1)) text:$(2))
err_nodef			= $(call err,ERRCODE_PARAM,No found $(1) define!!!)
err_param 			= $(call err,ERRCODE_PARAM,$(call printf_var,$(1)) unsupport!!!)

#
# prepare
#
# var
SENSOR_TYPE			:=$(shell echo $$CONFIG_SENSOR_TYPE)
ifeq ($(SENSOR_TYPE),sc450ai)
CFLAGS	+=	-DCONFIG_AK_SENSOR_SC450AI
endif
ifeq ($(SENSOR_TYPE),sc200ai)
CFLAGS	+=	-DCONFIG_AK_SENSOR_SC200AI
endif

ifeq ($(CHIP),ak3918av200)
DEFINE				+= -DCONFIG_MACH_AK3918AV200 -D__CHIP_AK3918AV200_SERIES
endif
ifeq ($(CHIP),ak3918av100)
DEFINE				+= -DCONFIG_MACH_AK3918AV100 -D__CHIP_AK3918AV100_SERIES
endif
ifeq ($(CHIP),ak3918av130)
DEFINE				+= -DCONFIG_MACH_AK3918AV130 -D__CHIP_AK3918AV130_SERIES
endif

# func
# .PHONY: common_prepare
# common_prepare:
# 	@echo $(call printf_var,SENSOR_TYPE)
# 	@echo $(call printf_var,CFLAGS)

