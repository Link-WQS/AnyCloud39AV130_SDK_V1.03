#!/bin/bash

# clean all
./clean_all.sh
# build config
./build_tool.sh build