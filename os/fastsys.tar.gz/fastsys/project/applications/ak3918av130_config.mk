#!/bin/bash

#arch
CONFIG_ARCH=arm

#march
CONFIG_MARCH=arm926ejs

#chip
CONFIG_CHIP=ak3918av130

#os
CONFIG_OS=rtthread

#application
CONFIG_APP=test_arm

CONFIG_CONSOLE_UART=2

if [ ${CONFIG_APP} = vicap_demo_av130 ]; then
	CONFIG_FASTSYS_DEFCONFIG="fastsys_fastae_defconfig.h"
else
	CONFIG_FASTSYS_DEFCONFIG="fastsys_defconfig.h"
fi