#!/bin/bash

# clean all
./build_tool.sh clean ak3918av130
# build config_1
./build_tool.sh build ak3918av130