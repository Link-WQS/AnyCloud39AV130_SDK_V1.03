#!/bin/bash

#arch
CONFIG_ARCH=riscv

#march
CONFIG_MARCH=u64

#chip
CONFIG_CHIP=ak3918av200

#os
CONFIG_OS=rtthread

#application
CONFIG_APP=vicap_demo

#board default config
CONFIG_BOARD_DEFAULT_DSS=configs/dss_anyka_av200_fastsys/dss_anyka_av200_fastsys_defconfig.c
#board sc450ai config
CONFIG_BOARD_SC450AI_DSS=configs/dss_anyka_av200_fastsys/dss_anyka_av200_fastsys_sc450ai.c

#sensor
#sensor list: sc450ai,sc200ai
CONFIG_SENSOR_TYPE=sc450ai

#board config
if [ $CONFIG_SENSOR_TYPE = sc450ai ]; then
    CONFIG_BOARD_DSS=$CONFIG_BOARD_SC450AI_DSS
elif test $CONFIG_SENSOR_TYPE = "sc200ai"; then
    CONFIG_BOARD_DSS=$CONFIG_BOARD_DEFAULT_DSS
else
    CONFIG_BOARD_DSS=$CONFIG_BOARD_SC450AI_DSS
fi

#export
export CONFIG_SENSOR_TYPE