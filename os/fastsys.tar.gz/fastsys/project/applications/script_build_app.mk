
include ../rules.mk

#
#project
#
PROJ				:= fastsys
APP_NAME			:= applications
BUILD				:= bd
PATH_PROJECT		:= $(shell pwd)
PATH_SDK			:= $(patsubst %/project/$(APP_NAME),%,$(PATH_PROJECT))
PATH_APP			:= $(PATH_SDK)/$(APP_NAME)
PATH_PLATFORM		:= $(PATH_SDK)/platform
PATH_OS				:= $(PATH_PLATFORM)/os
PATH_BUILD			:= $(PATH_PROJECT)/$(BUILD)
PATH_LIBS			:= $(PATH_PROJECT)/export
KEEP_LIBS			:= libcom_test

#
# var changea and makefile load
#
ifeq ($(ARCH),riscv)
include ../rules_riscv.mk
LINKER				:= link_riscv.lds.in
endif
ifeq ($(ARCH),arm)
include ../rules_arm.mk
LINKER				:= link_arm.lds.in
endif
ifeq ($(MARCH),u64)
DEFINE				+= -D__ANYKA_SIFIVE_U64__
endif
ifeq ($(MARCH),arm926ejs)
DEFINE				+= -D__ANYKA_ARM_ARM926EJS__
endif
ifeq ($(CHIP),ak3918av200)
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include/mach/av200
endif
ifeq ($(CHIP),ak3918av100)
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include/mach/av100
endif
ifeq ($(CHIP),ak3918av130)
INCLUDE				+= 	-I$(PATH_PLATFORM)/driver/include/mach/av130
endif
ifeq ($(OS),rtthread)
include ../rules_rtt.mk
endif

# add app source path
SRCDIR				+= 	$(PATH_APP)
SRCDIR				+= 	$(PATH_APP)/$(APP)
# include path
INCLUDE				+=	$(call OS_INCLUDE,$(PATH_OS),$(ARCH),$(CHIP),$(OS))
# add app include path
INCLUDE				+=	-I$(PATH_APP)
INCLUDE				+=  -I$(PATH_APP)/$(APP)
#INCLUDE				+=	-I$(PATH_PROJECT)/export
# add driver and component include path
INCLUDE				+=	-I$(PATH_PLATFORM)/component \
						-I$(PATH_PLATFORM)/component/include \
						-I$(PATH_PLATFORM)/daemon/include \
						-I$(PATH_PLATFORM)/middle \
						-I$(PATH_PLATFORM)/middle/include \
						-I$(PATH_PLATFORM)/middle/openamp \
						-I$(PATH_PLATFORM)/middle/openamp/metal \
						-I$(PATH_PLATFORM)/middle/openamp/open_amp/include \
						-I$(PATH_PLATFORM)/middle/openamp/open_amp/include/openamp \
						-I$(PATH_PLATFORM)/driver/core/$(CHIP)/include \
						-I$(PATH_PLATFORM)/driver/core/$(CHIP)/source \
						-I$(PATH_PLATFORM)/driver/include \
						-I$(PATH_PLATFORM)/board/dss_new	\
						-I$(PATH_PLATFORM)/os
# add source file
CSRCS 				+= $(foreach d, $(SRCDIR), $(wildcard $d/*.c))
SSRCS 				+= $(foreach d, $(SRCDIR), $(wildcard $d/*.S))
# create target file
COBJS 				+= $(patsubst $(PATH_SDK)/%.S, $(PATH_PROJECT)/$(BUILD)/%.o, $(SSRCS))
COBJS 				+= $(patsubst $(PATH_SDK)/%.c, $(PATH_PROJECT)/$(BUILD)/%.o, $(CSRCS))
# libs
LIBS				+= $(DEFAULT_CLIB)
KEEP_LIBS			:= $(foreach name, $(KEEP_LIBS), $(foreach d, $(PATH_LIBS), $(wildcard $d/$(name).a)))
LIBS				+= $(foreach d, $(PATH_LIBS), $(filter-out $(KEEP_LIBS), $(wildcard $d/*.a)))
# param
DEFINE				+= $(DEFAULT_DEFINE) -D__USER__='"'"$(USER)"'"'
CFLAGS				+= $(DEFAULT_CFLAGS) $(DEFINE) $(INCLUDE)
ASFLAGS				+= $(DEFAULT_ASFLAGS)
LDFLAGS				+= $(DEFAULT_LDFLAGS) $(CFLAGS) -Wl,-Map=$(PATH_BUILD)/map.txt -T link.lds
PATH_MKDIR 			+= $(dir $(COBJS))

# target
.PHONY: all check prepare info makedir maketarget clean
all: check prepare info makedir maketarget

check:
# check define 
ifndef ARCH
	$(call err_nodef,ARCH)
endif
ifndef MARCH
	$(call err_nodef,MARCH)
endif
ifndef CHIP
	$(call err_nodef,CHIP)
endif
ifndef OS
	$(call err_nodef,OS)
endif
ifndef APP
	$(call err_nodef,APP)
endif
# check match support
ifeq ($(filter $(ARCH), $(SUPPORT_LIST_ARCH)),)
	$(call err_param,ARCH)
endif
ifeq ($(filter $(MARCH), $(SUPPORT_LIST_MARCH)),)
	$(call err_param,MARCH)
endif
ifeq ($(filter $(CHIP), $(SUPPORT_LIST_CHIP)),)
	$(call err_param,CHIP)
endif
ifeq ($(filter $(OS), $(SUPPORT_LIST_OS)),)
	$(call err_param,OS)
endif

prepare:
ifeq ($(ARCH),riscv)
endif
ifeq ($(ARCH),arm)
endif
ifeq ($(MARCH),u64)
endif
ifeq ($(MARCH),arm926ejs)
endif
ifeq ($(CHIP),ak3918av200)
endif
ifeq ($(CHIP),ak3918av100)
endif
ifeq ($(CHIP),ak3918av130)
endif
ifeq ($(OS),rtthread)
endif

info:
	@echo $(call printf_var,PROJ)
	@echo $(call printf_var,APP_NAME)
	@echo $(call printf_var,BUILD)
	@echo $(call printf_var,ARCH)
	@echo $(call printf_var,MARCH)
	@echo $(call printf_var,CHIP)
	@echo $(call printf_var,OS)
	@echo $(call printf_var,APP)
	@echo $(call printf_var,CROSS_PATH)
	@echo $(call printf_var,CROSS_PREFIX)
	@echo $(call printf_var,LIBC_PATH)
	@echo $(call printf_var,LIBGCC_PATH)
	@echo $(call printf_var,PATH_PROJECT)
	@echo $(call printf_var,PATH_SDK)
	@echo $(call printf_var,PATH_APP)
	@echo $(call printf_var,PATH_PLATFORM)
	@echo $(call printf_var,PATH_OS)
	@echo $(call printf_var,PATH_BUILD)
	@echo $(call printf_var,PATH_MKDIR)
	@echo $(call printf_var,SRCDIR)
	@echo $(call printf_var,INCLUDE)
	@echo $(call printf_var,SSRCS)
	@echo $(call printf_var,CSRCS)
	@echo $(call printf_var,COBJS)
	@echo $(call printf_var,LIBS)
	@echo $(call printf_var,CFLAGS)
	@echo $(call printf_var,LDFLAGS)

makedir:
	@echo ---------------------[mkdir path list]----------------------------------
	@for i in $(PATH_MKDIR); \
	do \
		echo mkdir: $$i; \
		mkdir -p $$i; \
	done
	@echo ---------------------[build object list]---------------------------------
	@for i in $(COBJS); \
	do \
		echo build: $$i; \
	done

maketarget: $(PATH_BUILD)/$(PROJ).elf $(PATH_BUILD)/$(PROJ).bin

$(PATH_BUILD)/$(PROJ).bin:  $(PATH_BUILD)/$(PROJ).elf
	@echo ---------------------[build bin binary]----------------------------------
	$(OBJCOPY) -O binary $< $@

$(PATH_BUILD)/$(PROJ).elf:  $(SOBJS) $(COBJS) $(LIBS)
	@echo ---------------------[build out]-----------------------------------------
	ls -l $(PATH_PROJECT)/export
	$(CC) -E -P -x c-header -o link.lds $(LINKER) $(INCLUDE)
	$(CC) $(LDFLAGS) -o $(PATH_BUILD)/$(PROJ).elf -Wl,--start-group $(SOBJS) $(COBJS) $(LIBS) -Wl,--end-group -Wl,--whole-archive $(KEEP_LIBS) -Wl,--no-whole-archive
	$(OBJDUMP) -Dh $(PATH_BUILD)/$(PROJ).elf > $(PATH_BUILD)/$(PROJ)_objdump.txt

$(PATH_BUILD)/%.o: $(PATH_SDK)/%.c
	@echo ---------------------[$<]------------------------------------------------
	$(CC) -c $(CFLAGS) -c -o $@ $<

$(PATH_BUILD)/%.o: $(PATH_SDK)/%.S
	@echo ---------------------[$<]------------------------------------------------
	$(CC) -c $(CFLAGS) $(ASFLAGS) -c -o $@ $<

clean:
	rm -rf $(PATH_BUILD) link.lds




