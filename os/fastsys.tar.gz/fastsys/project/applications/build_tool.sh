#!/bin/bash

usage() {
    echo "Usage:"
    echo "  ./build_tool.sh                   Show help information"
    echo "Configuration actions:"
    echo "  build       - Build all"
    echo "  clean       - Clean build result of each projects"
    echo "  -c       - config.mk"
}

# 获取fastsys 目录
FASTSYS_DIR=$(pwd)/../../
echo "FASTSYS_DIR: " ${FASTSYS_DIR}

# 获取config.mk
CONFIG_MK=config
if [ $# -gt 1 ]; then
    CONFIG_CHIP_SERIES=${2}
    CONFIG_MK=${CONFIG_CHIP_SERIES}_config.mk
    CONFIG_MK_LIST=`ls ${CONFIG_CHIP_SERIES}_*config.mk`
fi

# reslease flag
IS_RELEASE=false
if [ -f ".release_fastsys" ]; then
    IS_RELEASE=true
fi

process_args()
{
    while [[ $# -gt 0 ]]; do
        case $1 in
            -c)
                if [ -n "$2" ]; then
                    CONFIG_MK="$2".mk
                shift
                fi
                shift
                ;;
            -h|--help)
                shift
                ;;
            *)
                echo "未知参数: $1"
                shift
                ;;
        esac
    done
}

#解析参数
process_args "$@"

echo 'CONFIG_MK: ' ${CONFIG_MK}

# build component
build_component()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean component"
            cd ../../platform/component
            make OS=$CONFIG_OS clean
            cd $tmp
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            cd ../../platform/component
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export
            ret=$?
            cd $tmp
            ;;
        *)
            ret=1
            ;;
        esac
        return $ret
}

# build kernel
build_kernel()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean kernel"
            cd ../../platform/os
            make OS=$CONFIG_OS clean
            cd $tmp
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            cd ../../platform/os
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export CONSOLE_UART=$CONFIG_CONSOLE_UART
            ret=$?
            cd $tmp
            ;;
        *)
            ret=1
            ;;
        esac
        return $ret
}

# build driver
build_driver()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean driver"
            cd ../../platform/driver
            make CHIP=$CONFIG_CHIP clean
            cd $tmp
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            cd ../../platform/driver
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export
            ret=$?
            cd $tmp
            ;;
        *)
            ret=1
            ;;
    esac
    return $ret
}

# build sensor
build_sensor()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean sensor"
            cd ../../platform/driver/ak_sensor
            make CHIP=$CONFIG_CHIP clean
            cd $tmp
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            cd ../../platform/driver/ak_sensor
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export install
            ret=$?
            cd $tmp
            ;;
        *)
            ret=1
            ;;
    esac
    return $ret
}

# build middle
build_middle()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean middle"
            cd ../../platform/middle
            make CHIP=$CONFIG_CHIP clean
            cd $tmp
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            cd ../../platform/middle
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export
            ret=$?
            cd $tmp
            ;;
        *)
            ret=1
            ;;
    esac
    return $ret
}

# build daemon
build_daemon()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean daemon"
            cd ../../platform/daemon
            make CHIP=$CONFIG_CHIP clean
            cd $tmp
            ;;
        build)
            echo "build daemon"
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            cd ../../platform/daemon
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export
            ret=$?
            cd $tmp
            ;;
        *)
            ret=1
            ;;
    esac
    return $ret
}

# build app
build_app()
{
    local ret=0
    case "$1" in
        clean)
            echo "clean app"
            make -f script_build_app.mk clean
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_CHIP=$CONFIG_CHIP"
            echo "CONFIG_OS=$CONFIG_OS"
            make -f script_build_app.mk ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS APP=$CONFIG_APP
            ret=$?
            ;;
        *)
            ret=1
            ;;
    esac
    return $ret
}

make_len_bin()
{
    echo "make_len_bin"
    ##head info file list Start mark
    echo 'S' > len.bin

    #ko装载顺序
    echo '[/fast/ak_i2c.ko]&' >> len.bin
    echo '0' >> len.bin

    echo '[/fast/ak_vi.ko mp_logic_open_num=1]&' >> len.bin
    echo '0' >> len.bin

    echo '[ak_vi.ko]&' >> len.bin
    echo '0' >> len.bin

    echo '[/fast/ak_vicap.ko]&' >> len.bin
    echo '0' >> len.bin

    echo '[/fast/ak_isp.ko]&' >> len.bin
    echo '0' >> len.bin

    echo '[/fast/ak_pp.ko]&' >> len.bin
    echo '0' >> len.bin

    if test $CONFIG_SENSOR_TYPE = "sc450ai"; then
        echo '[/fast/sensor_sc450ai.ko]&' >> len.bin
    elif test $CONFIG_SENSOR_TYPE = "sc200ai"; then
        echo '[/fast/sensor_sc200ai.ko]&' >> len.bin
    else
        echo '[/fast/sensor_sc450ai.ko]&' >> len.bin
    fi
    echo '0' >> len.bin

    echo '[/fast/ak_venc_adapter.ko]&' >> len.bin
    echo '0' >> len.bin

    echo '[/fast/ak_venc_bridge.ko]&' >> len.bin
    echo '0' >> len.bin

    if test $CONFIG_SENSOR_TYPE = "sc450ai"; then
        echo '[/fast/ak_quick_start.ko g_pcIspConfPath="/fast/isp_sc450ai_mipi_2lane_av200.conf"]&' >> len.bin
    elif test $CONFIG_SENSOR_TYPE = "sc200ai"; then
        echo '[/fast/ak_quick_start.ko g_pcIspConfPath="/fast/isp_sc200ai_mipi_2lane_av200.conf"]&' >> len.bin
    else
        echo '[/fast/ak_quick_start.ko g_pcIspConfPath="/fast/isp_sc450ai_mipi_2lane_av200.conf"]&' >> len.bin
    fi
    echo '0' >> len.bin

    ##file list end mark
    echo 'E' >> len.bin
}

# build board config
build_board()
{
    local ret=0
    local tmp=`pwd`
    case "$1" in
        clean)
            echo "clean board config"
            if [ "$CONFIG_CHIP" != "ak3918av130" ]; then
                cd ../../platform/board/dss
                make -f dsc clean
                cd $tmp
            fi

            cd ../../platform/board
            make OS=$CONFIG_OS clean
            cd $tmp
            ;;
        build)
            echo "CONFIG_ARCH=$CONFIG_ARCH"
            echo "CONFIG_MARCH=$CONFIG_MARCH"
            echo "CONFIG_BOARD_DSS=$CONFIG_BOARD_DSS"
            if [ -d $tmp/export ]; then
                cd $tmp/export
                rm -f *.bin
                cd $tmp
            fi
            if [ "$CONFIG_CHIP" != "ak3918av130" ]; then
                cd ../../platform/board/dss
                make -f dsc ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH DSS_OBJ=$CONFIG_BOARD_DSS PATH_INSTALL=$tmp/export
                ret=$?
                if [ $ret -ne 0 ]; then
                    exit 1
                fi
                truncate -s 4K $tmp/export/dss*.bin
                #make_len_bin
                #cat len.bin >> $tmp/export/dss*.bin
                cd $tmp
            fi

            cd ../../platform/board
            make ARCH=$CONFIG_ARCH MARCH=$CONFIG_MARCH CHIP=$CONFIG_CHIP OS=$CONFIG_OS PATH_INSTALL=$tmp/export
            ret=$?
            if [ $ret -ne 0 ]; then
                exit 1
            fi
            cd $tmp
            ;;
        install)
            if [ "$CONFIG_CHIP" != "ak3918av130" ]; then
                local link_addr=0
                if [ "$CONFIG_ARCH" = "riscv" ]; then
                    $mkimage_dir/mkimage -A riscv -T standalone -C none -O OpenRTOS -a $link_addr -e $link_addr -n "dss" -d $tmp/export/dss*.bin $tmp/export/dss.img
                else
                    $mkimage_dir/mkimage -A arm -T standalone -C none -O OpenRTOS -a $link_addr -e $link_addr -n "dss" -d $tmp/export/dss*.bin $tmp/export/dss.img
                fi
                cp $tmp/export/dss.img $install_dir
                #cp $tmp/export/dss*.bin $install_dir
            fi
            ;;
        *)
            ret=1
            ;;
    esac
    return $ret
}

build_all()
{
    # 拷贝fastsys_defconfig
    if [ "$CONFIG_CHIP" = "ak3918av130" ]; then
        if [ -f ${FASTSYS_DIR}/platform/driver/core/${CONFIG_CHIP}/include/${CONFIG_FASTSYS_DEFCONFIG} ]; then
            cp -a ${FASTSYS_DIR}/platform/driver/core/${CONFIG_CHIP}/include/${CONFIG_FASTSYS_DEFCONFIG} ${FASTSYS_DIR}/platform/driver/core/${CONFIG_CHIP}/include/autoconf.h
            generate_autoconf ${FASTSYS_DIR}/platform/driver/core/${CONFIG_CHIP}/include/autoconf.h
        fi
    fi

    build_board     build
    if [ $? -ne 0 ]; then
        exit 1
    fi
    if [ "$IS_RELEASE" = "false" ]; then
        build_component build
        if [ $? -ne 0 ]; then
            exit 1
        fi
        build_kernel    build
        if [ $? -ne 0 ]; then
            exit 1
        fi
        build_driver    build
        if [ $? -ne 0 ]; then
            exit 1
        fi
        build_middle    build
        if [ $? -ne 0 ]; then
            exit 1
        fi
        build_daemon    build
        if [ $? -ne 0 ]; then
            exit 1
        fi
    else
        build_sensor    build
        if [ $? -ne 0 ]; then
            exit 1
        fi
    fi
    build_app       build
    if [ $? -ne 0 ]; then
        exit 1
    fi
}

install_image()
{
    if [ "$CONFIG_ARCH" = "riscv" ]; then
        OBJDUMP=riscv64-anyka-linux-musl-objdump
    else
        #OBJDUMP=arm-none-eabi-objdump
        OBJDUMP=arm-anycloud-linux-uclibcgnueabi-objdump
    fi
    cd bd
    link_addr=$($OBJDUMP -f fastsys.elf | grep "start address" | sed s/"start address"//g)
    if [ -z "$link_addr" ]; then
        echo "link_addr is empty"
        echo "install_image wrong"
        exit 1
    fi

    if [ "$CONFIG_ARCH" = "riscv" ]; then
        $mkimage_dir/mkimage -A riscv -T kernel -C none -O OpenRTOS -a $link_addr -e $link_addr -n "fastsys kernel" -d ./fastsys.bin ./fastsys_uImage
    else
        $mkimage_dir/mkimage -A arm -T kernel -C none -O OpenRTOS -a $link_addr -e $link_addr -n "fastsys kernel" -d ./fastsys.bin ./fastsys_uImage
    fi

    if [ $? -ne 0 ]; then
        exit 1
    fi
    cp ./fastsys_uImage $install_dir
    cd -

    build_board install
    if [ $? -ne 0 ]; then
        exit 1
    fi
}

release_fastsys()
{
    local tmp=`pwd`
    local TOP=${tmp}/../../..

    rm -rf ${TOP}/fastsys_release
    rm -rf ${TOP}/fastsys_tmp
    rm -rf fastsys.tar.gz
    rm -rf fastsys

    mkdir ${TOP}/fastsys_tmp
    #cp -a export ${TOP}/fastsys_tmp

    #platform
    mkdir ${TOP}/fastsys_tmp/platform

    #platform/component
    local COMPONENT_INC=platform/component/include
    mkdir -p ${TOP}/fastsys_tmp/${COMPONENT_INC}
    cp -a ../../${COMPONENT_INC}/list.h ${TOP}/fastsys_tmp/${COMPONENT_INC}/
    cp -a ../../${COMPONENT_INC}/videodev2.h ${TOP}/fastsys_tmp/${COMPONENT_INC}/
    cp -a ../../${COMPONENT_INC}/ioctl_compat.h ${TOP}/fastsys_tmp/${COMPONENT_INC}/

    #platform/daemon
    local DAEMON_INC=platform/daemon/include
    mkdir -p ${TOP}/fastsys_tmp/${DAEMON_INC}
    cp -a ../../${DAEMON_INC}/*.h ${TOP}/fastsys_tmp/${DAEMON_INC}
    rm -rf ${TOP}/fastsys_tmp/${DAEMON_INC}/ipi_*

    #platform/driver
    local DRIVER_PATH=platform/driver
    local DRIVER_INC=${DRIVER_PATH}/include
    mkdir -p ${TOP}/fastsys_tmp/${DRIVER_INC}
    cp -a ../../${DRIVER_INC}/ak_types.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak_print.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak3918av130_pinctrl.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak_param.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak_video_priv_cmd.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak_sensor.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak_i2c.h ${TOP}/fastsys_tmp/${DRIVER_INC}/
    cp -a ../../${DRIVER_INC}/ak_saradc.h ${TOP}/fastsys_tmp/${DRIVER_INC}/

    mkdir -p ${TOP}/fastsys_tmp/${DRIVER_INC}/mach
    cp -a ../../${DRIVER_INC}/mach/av130 ${TOP}/fastsys_tmp/${DRIVER_INC}/mach/

    local DRIVER_INC_IN=${DRIVER_PATH}/include_internal
    mkdir -p ${TOP}/fastsys_tmp/${DRIVER_INC_IN}
    cp -a ../../${DRIVER_INC_IN}/ak_video_priv_cmd_internal.h ${TOP}/fastsys_tmp/${DRIVER_INC_IN}/

    #platform/driver/
    cp -a ../../${DRIVER_PATH}/config.mk ${TOP}/fastsys_tmp/${DRIVER_PATH}/
    cp -a ../../${DRIVER_PATH}/rules.mk ${TOP}/fastsys_tmp/${DRIVER_PATH}/
    cp -a ../../${DRIVER_PATH}/Makefile ${TOP}/fastsys_tmp/${DRIVER_PATH}/
    cp -a ../../${DRIVER_PATH}/ak_sensor ${TOP}/fastsys_tmp/${DRIVER_PATH}/

    #platform/core
    local CORE_CHIP_INC=${DRIVER_PATH}/core/ak3918av130/include
    mkdir -p ${TOP}/fastsys_tmp/${CORE_CHIP_INC}
    cp -a ../../${CORE_CHIP_INC}/types.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/ak_pinctrl.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/ak_time.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/cpu_config.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/core_driver.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/ak_irq.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/ak_ahbhant.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/
    cp -a ../../${CORE_CHIP_INC}/*_defconfig.h ${TOP}/fastsys_tmp/${CORE_CHIP_INC}/

    #platform/os
    local OS_INC=platform/os
    mkdir -p ${TOP}/fastsys_tmp/${OS_INC}
    cp -a ../../${OS_INC}/cmsis_os2.h ${TOP}/fastsys_tmp/${OS_INC}/
    cp -a ../../${OS_INC}/cmsis_cfg.h ${TOP}/fastsys_tmp/${OS_INC}/

    local BSP_PATH=platform/os/rtthread/os/bsp/ak3918av130
    mkdir -p ${TOP}/fastsys_tmp/${BSP_PATH}
    cp -a ../../${BSP_PATH}/rtconfig.h ${TOP}/fastsys_tmp/${BSP_PATH}/

    local OS_PATH_INC=platform/os/rtthread/os/include
    mkdir -p ${TOP}/fastsys_tmp/${OS_PATH_INC}
    cp -a ../../${OS_PATH_INC}/*.h ${TOP}/fastsys_tmp/${OS_PATH_INC}/

    local OS_PATH_INC_LIBC=platform/os/rtthread/os/include/libc
    mkdir -p ${TOP}/fastsys_tmp/${OS_PATH_INC_LIBC}
    cp -a ../../${OS_PATH_INC_LIBC}/*.h ${TOP}/fastsys_tmp/${OS_PATH_INC_LIBC}/

    #platform/board
    local BOARD_PATH=platform/board
    mkdir -p ${TOP}/fastsys_tmp/${BOARD_PATH}
    cp -a ../../${BOARD_PATH}/dss_new ${TOP}/fastsys_tmp/${BOARD_PATH}/
    #rm -rf ${TOP}/fastsys_tmp/${BOARD_PATH}/dss/build_*

    cp -a ../../${BOARD_PATH}/bds_av130 ${TOP}/fastsys_tmp/${BOARD_PATH}/
    cp -a ../../${BOARD_PATH}/Makefile ${TOP}/fastsys_tmp/${BOARD_PATH}/
    cp -a ../../${BOARD_PATH}/rules.mk ${TOP}/fastsys_tmp/${BOARD_PATH}/

    #platform/middle/openamp
    local OPENAMP_PATH=platform/middle/openamp
    local OPENAMP_H_LIST=$(find ../../${OPENAMP_PATH} -name "*.h")
    for h_file in ${OPENAMP_H_LIST[@]}; do
        #echo "OPENAMP_H_LIST: "${h_file:6}
        #echo "OPENAMP_H_LIST: "${h_file%/*}
        local openamp_tmp_path=${h_file%/*}
        openamp_tmp_path=${openamp_tmp_path:6}
        #echo "openamp_tmp_path: "${openamp_tmp_path}
        # 如果目录不存在，则创建
        if [ ! -d "${TOP}/fastsys_tmp/${openamp_tmp_path}" ]; then
            mkdir -p "${TOP}/fastsys_tmp/${openamp_tmp_path}"
        fi
        cp -a ${h_file} ${TOP}/fastsys_tmp/${openamp_tmp_path}/
    done

    #project
    #local PROJECT_INC=project
    #mkdir -p ${TOP}/fastsys_tmp/${PROJECT_INC}
    cp -a ../../project ${TOP}/fastsys_tmp/
    rm -rf ${TOP}/fastsys_tmp/project/applications/bd
    #rm -rf ${TOP}/fastsys_tmp/project/applications/fastsys_tmp

    #applications
    mkdir ${TOP}/fastsys_tmp/applications
    for config_mk in ${CONFIG_MK_LIST[@]}; do
        echo "CONFIG_MK_LIST: "${config_mk:0:-3}
        source ./${config_mk}
        cp -a ../../applications/${CONFIG_APP} ${TOP}/fastsys_tmp/applications/
    done

    #生成标识文件
    touch ${TOP}/fastsys_tmp/project/applications/.release_fastsys

    #
    cd ${TOP}/fastsys_tmp/project/applications
    #./build_tool.sh clean ak3918av130
    cd $tmp

    cp -a ${TOP}/fastsys_tmp fastsys
    tar -czf fastsys.tar.gz fastsys
    rm -rf fastsys
}

check_release()
{
    local tmp=`pwd`
    local TOP=${tmp}/../../..
    local fastsys_path=${TOP}/"fastsys_check"

    echo "================ CHECK_RELEASE ================"

    rm -rf ${fastsys_path}
    mkdir -p ${fastsys_path}

    tar -xzvf fastsys.tar.gz -C ${fastsys_path}

    cd ${fastsys_path}/fastsys/project/applications

    for config_mk in ${CONFIG_MK_LIST[@]}; do
        echo "CONFIG_MK_LIST: "${config_mk:0:-3}
        ./build_tool.sh build ${CONFIG_CHIP_SERIES} -c ${config_mk:0:-3}
        if [ $? -ne 0 ]; then
            exit 1
        fi
    done

    cd $tmp
    rm -rf ${fastsys_path}
}

generate_autoconf() {

    FILE="$1"
    MACRO="$2"
    VALUE="${3:-1}"  # 默认值为 1
    TEMP_FILE=${FILE}_tmp

    # 检查文件是否存在
    if [ ! -f "$FILE" ]; then
        echo "错误: 文件不存在: $FILE"
        exit 1
    fi

    # 查找最后一个 #endif 的行号
    # 匹配格式：#endif 或 # endif 或 #endif /* comments */
    ENDIF_LINE=$(grep -nE '^[[:space:]]*#[[:space:]]*endif' "$FILE" | tail -1 | cut -d: -f1)

    if [[ -z "$ENDIF_LINE" ]]; then
        echo -e "${RED}错误: 在文件中未找到 #endif${NC}"
        exit 1
    fi

    # 计算插入位置 (在 #endif 上一行)
    INSERT_LINE=$((ENDIF_LINE))

    # 1. 保存 #endif 之前的所有内容
    head -n $((INSERT_LINE - 1)) "$FILE" > "$TEMP_FILE"

    # 2. 插入新的宏定义
    # 构建宏定义行
    #MACRO_LINE="#define ${MACRO} ${VALUE}"

    MACRO_LINE="#define CONFIG_CONSOLE_UART ${CONFIG_CONSOLE_UART}"

    echo "$MACRO_LINE" >> "$TEMP_FILE"

    # 3. 添加 #endif 及其后的内容
    tail -n +${INSERT_LINE} "$FILE" >> "$TEMP_FILE"

    # 4. 覆盖原文件
    mv "$TEMP_FILE" "$FILE"

    # 显示修改后的文件末尾
    echo ""
    echo "=== 文件末尾内容 ==="
    tail -n 5 "$FILE"
}

#
# main
#
# cmd handler
echo "$1"

case "$1" in
    # clean
    clean)
        echo "$0 load ${CONFIG_MK}"
        source ./${CONFIG_MK}
        if [ $? -ne 0 ]; then
            exit 1
        fi

        build_board     clean
        if [ "$IS_RELEASE" = "false" ]; then
            build_component clean
            build_kernel    clean
            build_driver    clean
            build_middle    clean
            build_daemon    clean
        else
            build_sensor    clean
        fi
        build_app       clean

        if [ "$IS_RELEASE" = "false" ]; then
            rm -rf export/*.a export/*.h export/*.bin
        else
            rm -rf export/*.bin
        fi
        ;;
    # build
    build)
        echo "$0 load ${CONFIG_MK}"
        source ./${CONFIG_MK}
        if [ $? -ne 0 ]; then
            exit 1
        fi

        build_all
        ;;
    install)
        export mkimage_dir=$3
        export install_dir=$4
        
        echo "install_dir $install_dir"
        echo "mkimage_dir $mkimage_dir"

        echo "$0 load ${CONFIG_MK}"
        source ./${CONFIG_MK}
        if [ $? -ne 0 ]; then
            exit 1
        fi

        install_image
        if [ $? -ne 0 ]; then
            exit 1
        fi
        ;;
    release)
        echo "CONFIG_MK_LIST: "${CONFIG_MK_LIST}
        echo "$0 load ${CONFIG_MK}"
        source ./${CONFIG_MK}
        if [ $? -ne 0 ]; then
            exit 1
        fi

        build_all

        release_fastsys

        check_release

        if [ $? -ne 0 ]; then
            exit 1
        fi
        ;;
    # default
    *)
        usage
        ;;
esac
exit 0
