# Cross Tools and Libs
#CROSS_PATH					?= /opt/gcc-arm-none-eabi
#CROSS_PATH					?= /opt/arm-alios-eabi
#CROSS_PREFIX				?= $(CROSS_PATH)/bin/arm-none-eabi-
#LIBC_PATH					?= $(CROSS_PATH)/arm-none-eabi/lib
#LIBC_V5TE_SOFTFP_PATH		?= $(CROSS_PATH)/arm-none-eabi/lib/arm/v5te/softfp
#LIBC_V5TE_HARD_PATH			?= $(CROSS_PATH)/arm-none-eabi/lib/arm/v5te/hard
#LIBGCC_PATH					?= $(CROSS_PATH)/lib/gcc/arm-none-eabi/9.2.1
#LIBGCC_V5TE_SOFTFP_PATH		?= $(CROSS_PATH)/lib/gcc/arm-none-eabi/9.2.1/arm/v5te/softfp
#LIBCGC_V5TE_HARD_PATH		?= $(CROSS_PATH)/lib/gcc/arm-none-eabi/9.2.1/arm/v5te/hard

GCC_VERSION = 5.5.0
CROSS_TOOLCHAIN ?= arm-anycloud-linux-uclibcgnueabi
CROSS_PATH      ?= /opt/$(CROSS_TOOLCHAIN)/
CROSS_PREFIX	?= $(CROSS_PATH)/bin/arm-anycloud-linux-uclibcgnueabi-
LIBC_PATH		?= $(CROSS_PATH)/$(CROSS_TOOLCHAIN)/sysroot/usr/lib
LIBGCC_PATH 	?= $(CROSS_PATH)/lib/gcc/$(CROSS_TOOLCHAIN)/$(GCC_VERSION)

# Tools
CC           				= $(CROSS_PREFIX)gcc
CXX          				= $(CROSS_PREFIX)g++
AS           				= $(CROSS_PREFIX)as
AR           				= $(CROSS_PREFIX)ar
LD           				= $(CROSS_PREFIX)ld
OBJDUMP      				= $(CROSS_PREFIX)objdump
OBJCOPY	     				= $(CROSS_PREFIX)objcopy
STRIP	     				= $(CROSS_PREFIX)strip
SIZE         				= $(CROSS_PREFIX)size

# lib
DEFAULT_CLIB				+=	$(LIBC_PATH)/libstdc++.a \
								$(LIBC_PATH)/libc.a \
								$(LIBC_PATH)/libm.a \
								$(LIBGCC_PATH)/libgcc.a


#-nostdlib -fno-exceptions \
#-mfpu=auto \
# param
DEFAULT_CFLAGS 				+= 	-mlittle-endian \
								-marm \
								-mcpu=arm926ej-s \
								-mfloat-abi=soft \
								-mthumb-interwork \
								-Wl,--gc-sections -Wl,--wrap=printf,--wrap=sprintf,--wrap=snprintf \
					   			-fno-stack-protector \
					   			-fno-builtin \
								-fno-short-enums \
					   			-O1 \
					   			-g \
					   			-Werror
DEFAULT_ASFLAGS				+= 	-x assembler-with-cpp
DEFAULT_LDFLAGS 			+= 	-static \
					   			-Wl,--gc-sections \
					   			-nostartfiles \
					   			-Wl,--check-sections
DEFAULT_DEFINE				+=
