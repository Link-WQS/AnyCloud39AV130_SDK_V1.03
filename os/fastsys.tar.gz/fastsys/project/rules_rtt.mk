# OS source
# 1: os path
# 2: arch
# 3: chip
# 4: os
OS_SOURCE 	=	$(1)/rtthread/os/src \
				$(1)/rtthread/os/libcpu/$(2) \
				$(1)/rtthread/os/bsp/$(3) \
				$(1)/rtthread

# OS include
# 1: os path
# 2: arch
# 3: chip
# 4: os
OS_INCLUDE	=	-I$(1)/rtthread/os/bsp/$(3) \
				-I$(1)/rtthread/os/include \
				-I$(1)/rtthread/os/include/libc \
				-I$(1)/rtthread/os/libcpu/$(2)