# Cross Tools and Libs
CROSS_PATH			?= /opt/riscv64-anyka-linux-musl
CROSS_PREFIX		?= $(CROSS_PATH)/bin/riscv64-anyka-linux-musl-
LIBC_PATH			?= $(CROSS_PATH)/riscv64-anyka-linux-musl/sysroot/lib
LIBGCC_PATH			?= $(CROSS_PATH)/lib/gcc/riscv64-anyka-linux-musl/12.2.0

# Tools
CC           		= $(CROSS_PREFIX)gcc
CXX          		= $(CROSS_PREFIX)g++
AS           		= $(CROSS_PREFIX)as
AR           		= $(CROSS_PREFIX)ar
LD           		= $(CROSS_PREFIX)ld
OBJDUMP      		= $(CROSS_PREFIX)objdump
OBJCOPY	     		= $(CROSS_PREFIX)objcopy
STRIP	     		= $(CROSS_PREFIX)strip
SIZE         		= $(CROSS_PREFIX)size

# arch bus and module
RISCV_ARCH			= rv64imafdc_zba_zbb
RISCV_ABI			= lp64d
RISCV_CMODEL		= medany

# lib
DEFAULT_CLIB		+=	$(LIBC_PATH)/libc.a \
						$(LIBC_PATH)/libm.a \
						$(LIBGCC_PATH)/libgcc.a

# param
DEFAULT_CFLAGS 		+= 	-mcmodel=$(RISCV_CMODEL) \
						-march=$(RISCV_ARCH) \
						-mabi=$(RISCV_ABI) \
						-Wl,--gc-sections -Wl,--wrap=printf,--wrap=sprintf,--wrap=snprintf \
					   	-fno-stack-protector \
					   	-fno-builtin \
					   	-O1 \
					   	-g \
					   	-Werror
DEFAULT_ASFLAGS		+= 	-x assembler-with-cpp
DEFAULT_LDFLAGS 	+= 	-static \
					   	-Wl,-no-warn-rwx-segments \
					   	-Wl,--gc-sections \
					   	-nostartfiles \
					   	-Wl,--check-sections
DEFAULT_DEFINE		+=
					   
